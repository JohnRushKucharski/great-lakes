window.MANIFEST = {
  "entries": [
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17877",
      "component_name": "base",
      "save_point_id": 1968,
      "magnitude_ft": 587.0,
      "elevation_ft": 587.0,
      "runup_ft": 0.0,
      "baseline_ari": 1000.5001,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17877_base_1968",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                1000.5000833333622,
                null,
                null,
                null,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                null,
                null,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                873.5316915105041,
                36.38814964107283,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                37.588074504264085
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                268.0379247378038
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_587d00_0d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_587d00_0d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                586.55784,
                null,
                null,
                null,
                null
              ],
              [
                585.1470100000001,
                586.7547000000001,
                null,
                null,
                null
              ],
              [
                583.7689900000001,
                585.3438700000002,
                587.0499900000001,
                588.8217300000002,
                null
              ],
              [
                581.8988200000001,
                583.4737000000001,
                585.0485800000001,
                586.8531300000001,
                588.6248700000002
              ],
              [
                580.0286500000002,
                582.03006,
                583.6049400000002,
                585.5079200000001,
                587.5421400000001
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_587d00_0d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_587d00_0d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                -0.4421599999998307,
                null,
                null,
                null,
                null
              ],
              [
                -1.8529899999997497,
                -0.2452999999998155,
                null,
                null,
                null
              ],
              [
                -3.231009999999742,
                -1.6561299999997343,
                0.0499900000002071,
                1.8217300000003436,
                null
              ],
              [
                -5.101179999999772,
                -3.5262999999997646,
                -1.9514199999997568,
                -0.146869999999808,
                1.6248700000003282
              ],
              [
                -6.971349999999688,
                -4.969939999999838,
                -3.3950599999997166,
                -1.4920799999997598,
                0.542140000000245
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_587d00_0d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_587d00_0d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1955200000002,
                585.96726,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1448950000001,
                584.0314700000001,
                585.9016400000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17877",
      "component_name": "run2",
      "save_point_id": 1968,
      "magnitude_ft": 585.0,
      "elevation_ft": 587.0,
      "runup_ft": 2.0,
      "baseline_ari": 41.984,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17877_run2_1968",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                41.983981741510334,
                null,
                null,
                null,
                null
              ],
              [
                680.4539693808459,
                38.81378743417575,
                null,
                null,
                null
              ],
              [
                1000.5000833333622,
                378.3007802711424,
                32.21424011891176,
                5.176187871354827,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                894.7396542981375,
                35.21401301369157,
                5.832197196721089
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                296.4826594262892,
                27.725765248874385
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_587d00_2d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_587d00_2d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                585.0,
                null,
                null,
                null,
                null
              ],
              [
                583.55636,
                585.173365882353,
                null,
                null,
                null
              ],
              [
                582.1362141176471,
                583.75322,
                585.534275882353,
                587.3060158823529,
                null
              ],
              [
                580.20974,
                581.85024,
                583.49074,
                585.3702258823529,
                587.240395882353
              ],
              [
                578.2974441176472,
                580.2988541176471,
                581.8737341176471,
                583.7767141176471,
                585.8109341176471
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_587d00_2d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_587d00_2d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.4436399999999594,
                0.1733658823529822,
                null,
                null,
                null
              ],
              [
                -2.863785882352886,
                -1.2467799999999445,
                0.5342758823529721,
                2.306015882352881,
                null
              ],
              [
                -4.790259999999989,
                -3.1497600000000148,
                -1.5092600000000402,
                0.3702258823528837,
                2.2403958823530274
              ],
              [
                -6.70255588235284,
                -4.701145882352876,
                -3.126265882352868,
                -1.2232858823529114,
                0.8109341176470934
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_587d00_2d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_587d00_2d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1955200000002,
                585.96726,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1448950000001,
                584.0314700000001,
                585.9016400000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17877",
      "component_name": "run25",
      "save_point_id": 1968,
      "magnitude_ft": 584.5,
      "elevation_ft": 587.0,
      "runup_ft": 2.5,
      "baseline_ari": 33.0203,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17877_run25_1968",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                33.0202670962731,
                null,
                null,
                null,
                null
              ],
              [
                159.168275553235,
                29.67091546929427,
                null,
                null,
                null
              ],
              [
                1000.5000833333622,
                96.50140988929604,
                23.07175093235656,
                2.28207884322574,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                208.9033258034596,
                26.071317710628858,
                2.600315575805411
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                86.90145215477288,
                17.78491976573462
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_587d00_2d50_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_587d00_2d50_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                584.5000000000001,
                null,
                null,
                null,
                null
              ],
              [
                583.05636,
                584.6831698039216,
                null,
                null,
                null
              ],
              [
                581.6264101960785,
                583.2532199999999,
                585.0440798039216,
                586.8158198039215,
                null
              ],
              [
                579.70974,
                581.3502400000001,
                582.9907400000001,
                584.8800298039215,
                586.7501998039216
              ],
              [
                577.7876401960785,
                579.7890501960785,
                581.3639301960785,
                583.2669101960785,
                585.3011301960785
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_587d00_2d50_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_587d00_2d50_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.443640000000073,
                0.183169803921487,
                null,
                null,
                null
              ],
              [
                -2.873589803921618,
                -1.2467800000001716,
                0.5440798039214769,
                2.3158198039213858,
                null
              ],
              [
                -4.790260000000103,
                -3.1497600000000148,
                -1.5092600000000402,
                0.3800298039213885,
                2.2501998039215323
              ],
              [
                -6.712359803921572,
                -4.710949803921608,
                -3.1360698039216004,
                -1.2330898039216436,
                0.8011301960783612
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_587d00_2d50_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_587d00_2d50_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1955200000002,
                585.96726,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1448950000001,
                584.0314700000001,
                585.9016400000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17877",
      "component_name": "run3",
      "save_point_id": 1968,
      "magnitude_ft": 584.0,
      "elevation_ft": 587.0,
      "runup_ft": 3.0,
      "baseline_ari": 24.057,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17877_run3_1968",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                24.056973952005094,
                null,
                null,
                null,
                null
              ],
              [
                49.93747462211457,
                20.528666118967458,
                null,
                null,
                null
              ],
              [
                1000.5000833333622,
                46.40819245502311,
                10.2999965340185,
                1.5010903486136369,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                57.006732324753855,
                14.546775772261974,
                1.5667722890280522
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                45.91001280997219,
                8.779822522509344
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_587d00_3d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_587d00_3d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                584.0000000000001,
                null,
                null,
                null,
                null
              ],
              [
                582.5563600000002,
                584.1929737254903,
                null,
                null,
                null
              ],
              [
                581.1166062745099,
                582.75322,
                584.5538837254903,
                586.3256237254902,
                null
              ],
              [
                579.2097400000001,
                580.8502400000001,
                582.4907400000001,
                584.3898337254902,
                586.2600037254904
              ],
              [
                577.2778362745099,
                579.2792462745099,
                580.8541262745099,
                582.7571062745099,
                584.7913262745099
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_587d00_3d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_587d00_3d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.4436399999999594,
                0.1929737254902193,
                null,
                null,
                null
              ],
              [
                -2.8833937254902366,
                -1.246780000000058,
                0.5538837254902091,
                2.325623725490118,
                null
              ],
              [
                -4.790259999999989,
                -3.1497600000000148,
                -1.5092600000000402,
                0.3898337254901207,
                2.2600037254902645
              ],
              [
                -6.722163725490191,
                -4.720753725490226,
                -3.145873725490219,
                -1.242893725490262,
                0.7913262745097427
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_587d00_3d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_587d00_3d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1955200000002,
                585.96726,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1448950000001,
                584.0314700000001,
                585.9016400000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17862",
      "component_name": "base",
      "save_point_id": 1968,
      "magnitude_ft": 586.5,
      "elevation_ft": 586.5,
      "runup_ft": 0.0,
      "baseline_ari": 874.5803,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17862_base_1968",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                874.5802973670694,
                null,
                null,
                null,
                null
              ],
              [
                1000.5000833333622,
                447.6138712326772,
                null,
                null,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                180.9129377753881,
                27.245389789271968,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                341.73767182257257,
                28.44525597240612
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                81.6866405938406
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_586d50_0d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_586d50_0d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                586.5,
                null,
                null,
                null,
                null
              ],
              [
                585.0891700000001,
                586.7051228571428,
                null,
                null,
                null
              ],
              [
                583.7028871428572,
                585.2942928571429,
                587.0004128571428,
                588.7721528571429,
                null
              ],
              [
                581.8327171428571,
                583.41586,
                584.9907400000001,
                586.8035528571428,
                588.5835557142858
              ],
              [
                579.9625471428571,
                581.9639571428571,
                583.5388371428571,
                585.4418171428572,
                587.4760371428572
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_586d50_0d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_586d50_0d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.410829999999919,
                0.2051228571427827,
                null,
                null,
                null
              ],
              [
                -2.797112857142793,
                -1.2057071428571362,
                0.5004128571428055,
                2.2721528571429417,
                null
              ],
              [
                -4.667282857142936,
                -3.084140000000048,
                -1.5092599999999263,
                0.3035528571427903,
                2.083555714285808
              ],
              [
                -6.537452857142853,
                -4.536042857142888,
                -2.961162857142881,
                -1.0581828571428105,
                0.9760371428571945
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_586d50_0d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_586d50_0d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1955200000002,
                585.96726,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1448950000001,
                584.0314700000001,
                585.9016400000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17862",
      "component_name": "run2",
      "save_point_id": 1968,
      "magnitude_ft": 584.5,
      "elevation_ft": 586.5,
      "runup_ft": 2.0,
      "baseline_ari": 33.0203,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17862_run2_1968",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                33.0202670962731,
                null,
                null,
                null,
                null
              ],
              [
                159.168275553235,
                29.67091546929427,
                null,
                null,
                null
              ],
              [
                1000.5000833333622,
                96.50140988929604,
                23.07175093235656,
                2.28207884322574,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                208.9033258034596,
                26.071317710628858,
                2.600315575805411
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                86.90145215477288,
                17.78491976573462
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_586d50_2d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_586d50_2d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                584.5000000000001,
                null,
                null,
                null,
                null
              ],
              [
                583.05636,
                584.6831698039216,
                null,
                null,
                null
              ],
              [
                581.6264101960785,
                583.2532199999999,
                585.0440798039216,
                586.8158198039215,
                null
              ],
              [
                579.70974,
                581.3502400000001,
                582.9907400000001,
                584.8800298039215,
                586.7501998039216
              ],
              [
                577.7876401960785,
                579.7890501960785,
                581.3639301960785,
                583.2669101960785,
                585.3011301960785
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_586d50_2d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_586d50_2d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.443640000000073,
                0.183169803921487,
                null,
                null,
                null
              ],
              [
                -2.873589803921618,
                -1.2467800000001716,
                0.5440798039214769,
                2.3158198039213858,
                null
              ],
              [
                -4.790260000000103,
                -3.1497600000000148,
                -1.5092600000000402,
                0.3800298039213885,
                2.2501998039215323
              ],
              [
                -6.712359803921572,
                -4.710949803921608,
                -3.1360698039216004,
                -1.2330898039216436,
                0.8011301960783612
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_586d50_2d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_586d50_2d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1955200000002,
                585.96726,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1448950000001,
                584.0314700000001,
                585.9016400000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17862",
      "component_name": "run25",
      "save_point_id": 1968,
      "magnitude_ft": 584.0,
      "elevation_ft": 586.5,
      "runup_ft": 2.5,
      "baseline_ari": 24.057,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17862_run25_1968",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                24.056973952005094,
                null,
                null,
                null,
                null
              ],
              [
                49.93747462211457,
                20.528666118967458,
                null,
                null,
                null
              ],
              [
                1000.5000833333622,
                46.40819245502311,
                10.2999965340185,
                1.5010903486136369,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                57.006732324753855,
                14.546775772261974,
                1.5667722890280522
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                45.91001280997219,
                8.779822522509344
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_586d50_2d50_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_586d50_2d50_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                584.0000000000001,
                null,
                null,
                null,
                null
              ],
              [
                582.5563600000002,
                584.1929737254903,
                null,
                null,
                null
              ],
              [
                581.1166062745099,
                582.75322,
                584.5538837254903,
                586.3256237254902,
                null
              ],
              [
                579.2097400000001,
                580.8502400000001,
                582.4907400000001,
                584.3898337254902,
                586.2600037254904
              ],
              [
                577.2778362745099,
                579.2792462745099,
                580.8541262745099,
                582.7571062745099,
                584.7913262745099
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_586d50_2d50_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_586d50_2d50_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.4436399999999594,
                0.1929737254902193,
                null,
                null,
                null
              ],
              [
                -2.8833937254902366,
                -1.246780000000058,
                0.5538837254902091,
                2.325623725490118,
                null
              ],
              [
                -4.790259999999989,
                -3.1497600000000148,
                -1.5092600000000402,
                0.3898337254901207,
                2.2600037254902645
              ],
              [
                -6.722163725490191,
                -4.720753725490226,
                -3.145873725490219,
                -1.242893725490262,
                0.7913262745097427
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_586d50_2d50_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_586d50_2d50_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1955200000002,
                585.96726,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1448950000001,
                584.0314700000001,
                585.9016400000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17862",
      "component_name": "run3",
      "save_point_id": 1968,
      "magnitude_ft": 583.5,
      "elevation_ft": 586.5,
      "runup_ft": 3.0,
      "baseline_ari": 10.4633,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17862_run3_1968",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                10.46327532981882,
                null,
                null,
                null,
                null
              ],
              [
                40.97357955935377,
                9.327989779984494,
                null,
                null,
                null
              ],
              [
                494.5477151544534,
                37.444364508669175,
                6.991463155076583,
                1.2646385945773313,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                42.149991985050015,
                8.177862867205413,
                1.332794838112259
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                800.5991593199152,
                37.118574796006754,
                5.477105609251001
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_586d50_3d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_586d50_3d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.5000000000002,
                null,
                null,
                null,
                null
              ],
              [
                582.0563600000002,
                583.6640500000001,
                null,
                null,
                null
              ],
              [
                580.6124240909093,
                582.2204100000001,
                584.0246640909093,
                585.7964040909092,
                null
              ],
              [
                578.6766340909093,
                580.3171340909092,
                581.9904440909093,
                583.8603181818183,
                585.7304881818183
              ],
              [
                576.7408440909093,
                578.7422540909092,
                580.3171340909092,
                582.2201140909092,
                584.2543340909092
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_586d50_3d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_586d50_3d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.443640000000073,
                0.164049999999861,
                null,
                null,
                null
              ],
              [
                -2.8875759090909696,
                -1.2795900000000984,
                0.5246640909090274,
                2.2964040909089363,
                null
              ],
              [
                -4.823365909090967,
                -3.1828659090909923,
                -1.5095559090909774,
                0.3603181818181156,
                2.230488181818032
              ],
              [
                -6.759155909090964,
                -4.757745909091,
                -3.1828659090909923,
                -1.2798859090910355,
                0.7543340909089693
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_586d50_3d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_586d50_3d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1955200000002,
                585.96726,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1448950000001,
                584.0314700000001,
                585.9016400000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17847",
      "component_name": "base",
      "save_point_id": 1968,
      "magnitude_ft": 586.0,
      "elevation_ft": 586.0,
      "runup_ft": 0.0,
      "baseline_ari": 189.3656,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17847_base_1968",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                189.36562461066205,
                null,
                null,
                null,
                null
              ],
              [
                1000.5000833333622,
                122.69919866204523,
                null,
                null,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                50.5003866006927,
                16.5030751928468,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                81.73769145748334,
                18.50249644432713
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                45.30832128004341
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_586d00_0d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_586d00_0d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                586.0,
                null,
                null,
                null,
                null
              ],
              [
                584.5891700000001,
                586.19686,
                null,
                null,
                null
              ],
              [
                583.1455300000001,
                584.7568733333334,
                586.52496,
                588.2967000000001,
                null
              ],
              [
                581.27536,
                582.8538933333334,
                584.4615833333334,
                586.3317533333334,
                588.1727666666667
              ],
              [
                579.37238,
                581.37379,
                582.9486700000001,
                584.8516500000001,
                586.8858700000001
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_586d00_0d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_586d00_0d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.410829999999919,
                0.1968600000000151,
                null,
                null,
                null
              ],
              [
                -2.8544699999998784,
                -1.243126666666626,
                0.5249599999999646,
                2.2967000000001008,
                null
              ],
              [
                -4.724640000000022,
                -3.146106666666583,
                -1.5384166666666488,
                0.3317533333333813,
                2.172766666666689
              ],
              [
                -6.627619999999979,
                -4.626210000000015,
                -3.051329999999893,
                -1.1483499999999367,
                0.8858700000000681
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_586d00_0d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_586d00_0d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1955200000002,
                585.96726,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1448950000001,
                584.0314700000001,
                585.9016400000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17847",
      "component_name": "run2",
      "save_point_id": 1968,
      "magnitude_ft": 584.0,
      "elevation_ft": 586.0,
      "runup_ft": 2.0,
      "baseline_ari": 24.057,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17847_run2_1968",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                24.056973952005094,
                null,
                null,
                null,
                null
              ],
              [
                49.93747462211457,
                20.528666118967458,
                null,
                null,
                null
              ],
              [
                1000.5000833333622,
                46.40819245502311,
                10.2999965340185,
                1.5010903486136369,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                57.006732324753855,
                14.546775772261974,
                1.5667722890280522
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                45.91001280997219,
                8.779822522509344
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_586d00_2d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_586d00_2d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                584.0000000000001,
                null,
                null,
                null,
                null
              ],
              [
                582.5563600000002,
                584.1929737254903,
                null,
                null,
                null
              ],
              [
                581.1166062745099,
                582.75322,
                584.5538837254903,
                586.3256237254902,
                null
              ],
              [
                579.2097400000001,
                580.8502400000001,
                582.4907400000001,
                584.3898337254902,
                586.2600037254904
              ],
              [
                577.2778362745099,
                579.2792462745099,
                580.8541262745099,
                582.7571062745099,
                584.7913262745099
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_586d00_2d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_586d00_2d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.4436399999999594,
                0.1929737254902193,
                null,
                null,
                null
              ],
              [
                -2.8833937254902366,
                -1.246780000000058,
                0.5538837254902091,
                2.325623725490118,
                null
              ],
              [
                -4.790259999999989,
                -3.1497600000000148,
                -1.5092600000000402,
                0.3898337254901207,
                2.2600037254902645
              ],
              [
                -6.722163725490191,
                -4.720753725490226,
                -3.145873725490219,
                -1.242893725490262,
                0.7913262745097427
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_586d00_2d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_586d00_2d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1955200000002,
                585.96726,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1448950000001,
                584.0314700000001,
                585.9016400000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17847",
      "component_name": "run25",
      "save_point_id": 1968,
      "magnitude_ft": 583.5,
      "elevation_ft": 586.0,
      "runup_ft": 2.5,
      "baseline_ari": 10.4633,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17847_run25_1968",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                10.46327532981882,
                null,
                null,
                null,
                null
              ],
              [
                40.97357955935377,
                9.327989779984494,
                null,
                null,
                null
              ],
              [
                494.5477151544534,
                37.444364508669175,
                6.991463155076583,
                1.2646385945773313,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                42.149991985050015,
                8.177862867205413,
                1.332794838112259
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                800.5991593199152,
                37.118574796006754,
                5.477105609251001
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_586d00_2d50_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_586d00_2d50_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.5000000000002,
                null,
                null,
                null,
                null
              ],
              [
                582.0563600000002,
                583.6640500000001,
                null,
                null,
                null
              ],
              [
                580.6124240909093,
                582.2204100000001,
                584.0246640909093,
                585.7964040909092,
                null
              ],
              [
                578.6766340909093,
                580.3171340909092,
                581.9904440909093,
                583.8603181818183,
                585.7304881818183
              ],
              [
                576.7408440909093,
                578.7422540909092,
                580.3171340909092,
                582.2201140909092,
                584.2543340909092
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_586d00_2d50_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_586d00_2d50_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.443640000000073,
                0.164049999999861,
                null,
                null,
                null
              ],
              [
                -2.8875759090909696,
                -1.2795900000000984,
                0.5246640909090274,
                2.2964040909089363,
                null
              ],
              [
                -4.823365909090967,
                -3.1828659090909923,
                -1.5095559090909774,
                0.3603181818181156,
                2.230488181818032
              ],
              [
                -6.759155909090964,
                -4.757745909091,
                -3.1828659090909923,
                -1.2798859090910355,
                0.7543340909089693
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_586d00_2d50_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_586d00_2d50_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1955200000002,
                585.96726,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1448950000001,
                584.0314700000001,
                585.9016400000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17847",
      "component_name": "run3",
      "save_point_id": 1968,
      "magnitude_ft": 583.0,
      "elevation_ft": 586.0,
      "runup_ft": 3.0,
      "baseline_ari": 7.0043,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17847_run3_1968",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                7.004270656204618,
                null,
                null,
                null,
                null
              ],
              [
                32.009896942472764,
                5.870627198912554,
                null,
                null,
                null
              ],
              [
                140.0820254487798,
                28.48081881277908,
                3.5800933029902584,
                1.1310800448045506,
                null
              ],
              [
                1000.5000833333622,
                297.654695665757,
                33.18627233076584,
                4.956224070767818,
                1.1484297420032183
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                215.83662040136005,
                28.3274152287085,
                2.5129251154926835
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_586d00_3d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_586d00_3d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.0,
                null,
                null,
                null,
                null
              ],
              [
                581.5563599999999,
                583.1640499999999,
                null,
                null,
                null
              ],
              [
                580.0896968181817,
                581.7204099999999,
                583.5019368181817,
                585.2736768181818,
                null
              ],
              [
                578.1539068181817,
                579.7944068181818,
                581.4677168181818,
                583.3148636363636,
                585.1850336363635
              ],
              [
                576.2181168181817,
                578.2195268181817,
                579.7944068181818,
                581.6973868181817,
                583.7316068181817
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_586d00_3d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_586d00_3d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.443640000000073,
                0.164049999999861,
                null,
                null,
                null
              ],
              [
                -2.910303181818336,
                -1.2795900000000984,
                0.5019368181816617,
                2.273676818181798,
                null
              ],
              [
                -4.846093181818333,
                -3.2055931818182444,
                -1.5322831818182294,
                0.3148636363636115,
                2.185033636363528
              ],
              [
                -6.78188318181833,
                -4.780473181818252,
                -3.2055931818182444,
                -1.3026131818182876,
                0.7316068181817172
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_586d00_3d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_586d00_3d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1955200000002,
                585.96726,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1448950000001,
                584.0314700000001,
                585.9016400000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17832",
      "component_name": "base",
      "save_point_id": 1968,
      "magnitude_ft": 585.5,
      "elevation_ft": 585.5,
      "runup_ft": 0.0,
      "baseline_ari": 55.2428,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17832_base_1968",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                55.24283592695366,
                null,
                null,
                null,
                null
              ],
              [
                1000.5000833333622,
                47.95692213833989,
                null,
                null,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                41.35720581325166,
                8.501427887898926,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                44.35706628565106,
                9.001188730393745
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                985.4132208487472,
                36.51689664383365
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_585d50_0d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_585d50_0d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                585.5000000000001,
                null,
                null,
                null,
                null
              ],
              [
                584.0594712500001,
                585.66716125,
                null,
                null,
                null
              ],
              [
                582.64553,
                584.2563312500001,
                586.0249600000001,
                587.7967,
                null
              ],
              [
                580.7159625,
                582.3533512500001,
                583.9907400000001,
                585.86091,
                587.7310800000001
              ],
              [
                578.8129825000001,
                580.8143925,
                582.3892725000001,
                584.2922525,
                586.3264725
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_585d50_0d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_585d50_0d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.4405287499999986,
                0.1671612499999355,
                null,
                null,
                null
              ],
              [
                -2.8544700000001058,
                -1.2436687499999834,
                0.5249599999999646,
                2.2966999999998734,
                null
              ],
              [
                -4.784037500000068,
                -3.146648750000054,
                -1.5092600000000402,
                0.3609099999998761,
                2.23108000000002
              ],
              [
                -6.6870175000000245,
                -4.68560750000006,
                -3.1107275000000527,
                -1.207747500000096,
                0.8264724999999089
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_585d50_0d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_585d50_0d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1955200000002,
                585.96726,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1448950000001,
                584.0314700000001,
                585.9016400000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17832",
      "component_name": "run2",
      "save_point_id": 1968,
      "magnitude_ft": 583.5,
      "elevation_ft": 585.5,
      "runup_ft": 2.0,
      "baseline_ari": 10.4633,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17832_run2_1968",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                10.46327532981882,
                null,
                null,
                null,
                null
              ],
              [
                40.97357955935377,
                9.327989779984494,
                null,
                null,
                null
              ],
              [
                494.5477151544534,
                37.444364508669175,
                6.991463155076583,
                1.2646385945773313,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                42.149991985050015,
                8.177862867205413,
                1.332794838112259
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                800.5991593199152,
                37.118574796006754,
                5.477105609251001
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_585d50_2d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_585d50_2d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.5000000000002,
                null,
                null,
                null,
                null
              ],
              [
                582.0563600000002,
                583.6640500000001,
                null,
                null,
                null
              ],
              [
                580.6124240909093,
                582.2204100000001,
                584.0246640909093,
                585.7964040909092,
                null
              ],
              [
                578.6766340909093,
                580.3171340909092,
                581.9904440909093,
                583.8603181818183,
                585.7304881818183
              ],
              [
                576.7408440909093,
                578.7422540909092,
                580.3171340909092,
                582.2201140909092,
                584.2543340909092
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_585d50_2d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_585d50_2d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.443640000000073,
                0.164049999999861,
                null,
                null,
                null
              ],
              [
                -2.8875759090909696,
                -1.2795900000000984,
                0.5246640909090274,
                2.2964040909089363,
                null
              ],
              [
                -4.823365909090967,
                -3.1828659090909923,
                -1.5095559090909774,
                0.3603181818181156,
                2.230488181818032
              ],
              [
                -6.759155909090964,
                -4.757745909091,
                -3.1828659090909923,
                -1.2798859090910355,
                0.7543340909089693
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_585d50_2d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_585d50_2d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1955200000002,
                585.96726,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1448950000001,
                584.0314700000001,
                585.9016400000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17832",
      "component_name": "run25",
      "save_point_id": 1968,
      "magnitude_ft": 583.0,
      "elevation_ft": 585.5,
      "runup_ft": 2.5,
      "baseline_ari": 7.0043,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17832_run25_1968",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                7.004270656204618,
                null,
                null,
                null,
                null
              ],
              [
                32.009896942472764,
                5.870627198912554,
                null,
                null,
                null
              ],
              [
                140.0820254487798,
                28.48081881277908,
                3.5800933029902584,
                1.1310800448045506,
                null
              ],
              [
                1000.5000833333622,
                297.654695665757,
                33.18627233076584,
                4.956224070767818,
                1.1484297420032183
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                215.83662040136005,
                28.3274152287085,
                2.5129251154926835
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_585d50_2d50_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_585d50_2d50_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.0,
                null,
                null,
                null,
                null
              ],
              [
                581.5563599999999,
                583.1640499999999,
                null,
                null,
                null
              ],
              [
                580.0896968181817,
                581.7204099999999,
                583.5019368181817,
                585.2736768181818,
                null
              ],
              [
                578.1539068181817,
                579.7944068181818,
                581.4677168181818,
                583.3148636363636,
                585.1850336363635
              ],
              [
                576.2181168181817,
                578.2195268181817,
                579.7944068181818,
                581.6973868181817,
                583.7316068181817
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_585d50_2d50_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_585d50_2d50_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.443640000000073,
                0.164049999999861,
                null,
                null,
                null
              ],
              [
                -2.910303181818336,
                -1.2795900000000984,
                0.5019368181816617,
                2.273676818181798,
                null
              ],
              [
                -4.846093181818333,
                -3.2055931818182444,
                -1.5322831818182294,
                0.3148636363636115,
                2.185033636363528
              ],
              [
                -6.78188318181833,
                -4.780473181818252,
                -3.2055931818182444,
                -1.3026131818182876,
                0.7316068181817172
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_585d50_2d50_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_585d50_2d50_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1955200000002,
                585.96726,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1448950000001,
                584.0314700000001,
                585.9016400000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17832",
      "component_name": "run3",
      "save_point_id": 1968,
      "magnitude_ft": 582.5,
      "elevation_ft": 585.5,
      "runup_ft": 3.0,
      "baseline_ari": 3.5254,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17832_run3_1968",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                3.5253803484545223,
                null,
                null,
                null,
                null
              ],
              [
                23.04668018756305,
                2.490522381281896,
                null,
                null,
                null
              ],
              [
                48.38043601668874,
                18.82762000835909,
                1.8039879581827296,
                1.0835720297012998,
                null
              ],
              [
                1000.5000833333622,
                80.07367078121361,
                24.22296744176476,
                2.2156578867003063,
                1.1008752337913468
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                72.1165247902927,
                18.82762000835909,
                1.571599257356843
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_585d50_3d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_585d50_3d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                582.5,
                null,
                null,
                null,
                null
              ],
              [
                581.0344607692307,
                582.66405,
                null,
                null,
                null
              ],
              [
                579.5580107692307,
                581.2204099999999,
                582.9921499999999,
                584.76389,
                null
              ],
              [
                577.6222207692307,
                579.2846199999999,
                580.9579299999999,
                582.7952899999999,
                584.6435607692307
              ],
              [
                575.6645315384615,
                577.6659415384614,
                579.2408215384614,
                581.1438015384614,
                583.1780215384614
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_585d50_3d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_585d50_3d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.4655392307693091,
                0.1640499999999747,
                null,
                null,
                null
              ],
              [
                -2.941989230769309,
                -1.2795900000000984,
                0.4921499999999241,
                2.2638899999999467,
                null
              ],
              [
                -4.877779230769306,
                -3.215380000000096,
                -1.5420700000000809,
                0.295289999999909,
                2.143560769230703
              ],
              [
                -6.83546846153854,
                -4.834058461538575,
                -3.259178461538568,
                -1.356198461538611,
                0.6780215384613939
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_585d50_3d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_585d50_3d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1955200000002,
                585.96726,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1448950000001,
                584.0314700000001,
                585.9016400000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17817",
      "component_name": "base",
      "save_point_id": 1968,
      "magnitude_ft": 585.0,
      "elevation_ft": 585.0,
      "runup_ft": 0.0,
      "baseline_ari": 41.984,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17817_base_1968",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                41.983981741510334,
                null,
                null,
                null,
                null
              ],
              [
                680.4539693808459,
                38.81378743417575,
                null,
                null,
                null
              ],
              [
                1000.5000833333622,
                378.3007802711424,
                32.21424011891176,
                5.176187871354827,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                894.7396542981375,
                35.21401301369157,
                5.832197196721089
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                296.4826594262892,
                27.725765248874385
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_585d00_0d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_585d00_0d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                585.0,
                null,
                null,
                null,
                null
              ],
              [
                583.55636,
                585.173365882353,
                null,
                null,
                null
              ],
              [
                582.1362141176471,
                583.75322,
                585.534275882353,
                587.3060158823529,
                null
              ],
              [
                580.20974,
                581.85024,
                583.49074,
                585.3702258823529,
                587.240395882353
              ],
              [
                578.2974441176472,
                580.2988541176471,
                581.8737341176471,
                583.7767141176471,
                585.8109341176471
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_585d00_0d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_585d00_0d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.4436399999999594,
                0.1733658823529822,
                null,
                null,
                null
              ],
              [
                -2.863785882352886,
                -1.2467799999999445,
                0.5342758823529721,
                2.306015882352881,
                null
              ],
              [
                -4.790259999999989,
                -3.1497600000000148,
                -1.5092600000000402,
                0.3702258823528837,
                2.2403958823530274
              ],
              [
                -6.70255588235284,
                -4.701145882352876,
                -3.126265882352868,
                -1.2232858823529114,
                0.8109341176470934
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_585d00_0d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_585d00_0d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1955200000002,
                585.96726,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1448950000001,
                584.0314700000001,
                585.9016400000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17817",
      "component_name": "run2",
      "save_point_id": 1968,
      "magnitude_ft": 583.0,
      "elevation_ft": 585.0,
      "runup_ft": 2.0,
      "baseline_ari": 7.0043,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17817_run2_1968",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                7.004270656204618,
                null,
                null,
                null,
                null
              ],
              [
                32.009896942472764,
                5.870627198912554,
                null,
                null,
                null
              ],
              [
                140.0820254487798,
                28.48081881277908,
                3.5800933029902584,
                1.1310800448045506,
                null
              ],
              [
                1000.5000833333622,
                297.654695665757,
                33.18627233076584,
                4.956224070767818,
                1.1484297420032183
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                215.83662040136005,
                28.3274152287085,
                2.5129251154926835
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_585d00_2d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_585d00_2d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.0,
                null,
                null,
                null,
                null
              ],
              [
                581.5563599999999,
                583.1640499999999,
                null,
                null,
                null
              ],
              [
                580.0896968181817,
                581.7204099999999,
                583.5019368181817,
                585.2736768181818,
                null
              ],
              [
                578.1539068181817,
                579.7944068181818,
                581.4677168181818,
                583.3148636363636,
                585.1850336363635
              ],
              [
                576.2181168181817,
                578.2195268181817,
                579.7944068181818,
                581.6973868181817,
                583.7316068181817
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_585d00_2d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_585d00_2d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.443640000000073,
                0.164049999999861,
                null,
                null,
                null
              ],
              [
                -2.910303181818336,
                -1.2795900000000984,
                0.5019368181816617,
                2.273676818181798,
                null
              ],
              [
                -4.846093181818333,
                -3.2055931818182444,
                -1.5322831818182294,
                0.3148636363636115,
                2.185033636363528
              ],
              [
                -6.78188318181833,
                -4.780473181818252,
                -3.2055931818182444,
                -1.3026131818182876,
                0.7316068181817172
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_585d00_2d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_585d00_2d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1955200000002,
                585.96726,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1448950000001,
                584.0314700000001,
                585.9016400000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17817",
      "component_name": "run25",
      "save_point_id": 1968,
      "magnitude_ft": 582.5,
      "elevation_ft": 585.0,
      "runup_ft": 2.5,
      "baseline_ari": 3.5254,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17817_run25_1968",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                3.5253803484545223,
                null,
                null,
                null,
                null
              ],
              [
                23.04668018756305,
                2.490522381281896,
                null,
                null,
                null
              ],
              [
                48.38043601668874,
                18.82762000835909,
                1.8039879581827296,
                1.0835720297012998,
                null
              ],
              [
                1000.5000833333622,
                80.07367078121361,
                24.22296744176476,
                2.2156578867003063,
                1.1008752337913468
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                72.1165247902927,
                18.82762000835909,
                1.571599257356843
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_585d00_2d50_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_585d00_2d50_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                582.5,
                null,
                null,
                null,
                null
              ],
              [
                581.0344607692307,
                582.66405,
                null,
                null,
                null
              ],
              [
                579.5580107692307,
                581.2204099999999,
                582.9921499999999,
                584.76389,
                null
              ],
              [
                577.6222207692307,
                579.2846199999999,
                580.9579299999999,
                582.7952899999999,
                584.6435607692307
              ],
              [
                575.6645315384615,
                577.6659415384614,
                579.2408215384614,
                581.1438015384614,
                583.1780215384614
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_585d00_2d50_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_585d00_2d50_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.4655392307693091,
                0.1640499999999747,
                null,
                null,
                null
              ],
              [
                -2.941989230769309,
                -1.2795900000000984,
                0.4921499999999241,
                2.2638899999999467,
                null
              ],
              [
                -4.877779230769306,
                -3.215380000000096,
                -1.5420700000000809,
                0.295289999999909,
                2.143560769230703
              ],
              [
                -6.83546846153854,
                -4.834058461538575,
                -3.259178461538568,
                -1.356198461538611,
                0.6780215384613939
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_585d00_2d50_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_585d00_2d50_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1955200000002,
                585.96726,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1448950000001,
                584.0314700000001,
                585.9016400000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17817",
      "component_name": "run3",
      "save_point_id": 1968,
      "magnitude_ft": 582.0,
      "elevation_ft": 585.0,
      "runup_ft": 3.0,
      "baseline_ari": 1.7312,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17817_run3_1968",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                1.7312407488633237,
                null,
                null,
                null,
                null
              ],
              [
                10.073214800271067,
                1.532488990247557,
                null,
                null,
                null
              ],
              [
                39.588948853904206,
                8.938025172137348,
                1.3903280559494389,
                1.0443418901775965,
                null
              ],
              [
                1000.5000833333622,
                44.66883729937153,
                10.601383880252634,
                1.4889329178729296,
                1.0599218151400236
              ],
              [
                1000.5000833333622,
                943.2385827562924,
                44.20410831497598,
                9.006287437122669,
                1.3447964488287838
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_585d00_3d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_585d00_3d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                582.0,
                null,
                null,
                null,
                null
              ],
              [
                580.5235500000001,
                582.1640500000001,
                null,
                null,
                null
              ],
              [
                579.0471000000001,
                580.6928592307694,
                582.4645992307693,
                584.2363392307693,
                null
              ],
              [
                577.0562084615385,
                578.7295184615385,
                580.4303792307693,
                582.2677392307693,
                584.1050992307694
              ],
              [
                575.0876084615386,
                577.0890184615386,
                578.6638984615386,
                580.5668784615385,
                582.6010984615385
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_585d00_3d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_585d00_3d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.476449999999886,
                0.1640500000000884,
                null,
                null,
                null
              ],
              [
                -2.952899999999886,
                -1.3071407692306138,
                0.464599230769295,
                2.236339230769317,
                null
              ],
              [
                -4.943791538461483,
                -3.270481538461468,
                -1.5696207692307098,
                0.2677392307692798,
                2.105099230769383
              ],
              [
                -6.912391538461407,
                -4.910981538461442,
                -3.3361015384614348,
                -1.433121538461478,
                0.6010984615385269
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_585d00_3d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_585d00_3d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1955200000002,
                585.96726,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1448950000001,
                584.0314700000001,
                585.9016400000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17801",
      "component_name": "base",
      "save_point_id": 1968,
      "magnitude_ft": 584.5,
      "elevation_ft": 584.5,
      "runup_ft": 0.0,
      "baseline_ari": 33.0203,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17801_base_1968",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                33.0202670962731,
                null,
                null,
                null,
                null
              ],
              [
                159.168275553235,
                29.67091546929427,
                null,
                null,
                null
              ],
              [
                1000.5000833333622,
                96.50140988929604,
                23.07175093235656,
                2.28207884322574,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                208.9033258034596,
                26.071317710628858,
                2.600315575805411
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                86.90145215477288,
                17.78491976573462
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_584d50_0d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_584d50_0d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                584.5000000000001,
                null,
                null,
                null,
                null
              ],
              [
                583.05636,
                584.6831698039216,
                null,
                null,
                null
              ],
              [
                581.6264101960785,
                583.2532199999999,
                585.0440798039216,
                586.8158198039215,
                null
              ],
              [
                579.70974,
                581.3502400000001,
                582.9907400000001,
                584.8800298039215,
                586.7501998039216
              ],
              [
                577.7876401960785,
                579.7890501960785,
                581.3639301960785,
                583.2669101960785,
                585.3011301960785
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_584d50_0d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_584d50_0d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.443640000000073,
                0.183169803921487,
                null,
                null,
                null
              ],
              [
                -2.873589803921618,
                -1.2467800000001716,
                0.5440798039214769,
                2.3158198039213858,
                null
              ],
              [
                -4.790260000000103,
                -3.1497600000000148,
                -1.5092600000000402,
                0.3800298039213885,
                2.2501998039215323
              ],
              [
                -6.712359803921572,
                -4.710949803921608,
                -3.1360698039216004,
                -1.2330898039216436,
                0.8011301960783612
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_584d50_0d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_584d50_0d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1955200000002,
                585.96726,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1448950000001,
                584.0314700000001,
                585.9016400000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17801",
      "component_name": "run2",
      "save_point_id": 1968,
      "magnitude_ft": 582.5,
      "elevation_ft": 584.5,
      "runup_ft": 2.0,
      "baseline_ari": 3.5254,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17801_run2_1968",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                3.5253803484545223,
                null,
                null,
                null,
                null
              ],
              [
                23.04668018756305,
                2.490522381281896,
                null,
                null,
                null
              ],
              [
                48.38043601668874,
                18.82762000835909,
                1.8039879581827296,
                1.0835720297012998,
                null
              ],
              [
                1000.5000833333622,
                80.07367078121361,
                24.22296744176476,
                2.2156578867003063,
                1.1008752337913468
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                72.1165247902927,
                18.82762000835909,
                1.571599257356843
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_584d50_2d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_584d50_2d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                582.5,
                null,
                null,
                null,
                null
              ],
              [
                581.0344607692307,
                582.66405,
                null,
                null,
                null
              ],
              [
                579.5580107692307,
                581.2204099999999,
                582.9921499999999,
                584.76389,
                null
              ],
              [
                577.6222207692307,
                579.2846199999999,
                580.9579299999999,
                582.7952899999999,
                584.6435607692307
              ],
              [
                575.6645315384615,
                577.6659415384614,
                579.2408215384614,
                581.1438015384614,
                583.1780215384614
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_584d50_2d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_584d50_2d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.4655392307693091,
                0.1640499999999747,
                null,
                null,
                null
              ],
              [
                -2.941989230769309,
                -1.2795900000000984,
                0.4921499999999241,
                2.2638899999999467,
                null
              ],
              [
                -4.877779230769306,
                -3.215380000000096,
                -1.5420700000000809,
                0.295289999999909,
                2.143560769230703
              ],
              [
                -6.83546846153854,
                -4.834058461538575,
                -3.259178461538568,
                -1.356198461538611,
                0.6780215384613939
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_584d50_2d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_584d50_2d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1955200000002,
                585.96726,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1448950000001,
                584.0314700000001,
                585.9016400000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17801",
      "component_name": "run25",
      "save_point_id": 1968,
      "magnitude_ft": 582.0,
      "elevation_ft": 584.5,
      "runup_ft": 2.5,
      "baseline_ari": 1.7312,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17801_run25_1968",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                1.7312407488633237,
                null,
                null,
                null,
                null
              ],
              [
                10.073214800271067,
                1.532488990247557,
                null,
                null,
                null
              ],
              [
                39.588948853904206,
                8.938025172137348,
                1.3903280559494389,
                1.0443418901775965,
                null
              ],
              [
                1000.5000833333622,
                44.66883729937153,
                10.601383880252634,
                1.4889329178729296,
                1.0599218151400236
              ],
              [
                1000.5000833333622,
                943.2385827562924,
                44.20410831497598,
                9.006287437122669,
                1.3447964488287838
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_584d50_2d50_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_584d50_2d50_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                582.0,
                null,
                null,
                null,
                null
              ],
              [
                580.5235500000001,
                582.1640500000001,
                null,
                null,
                null
              ],
              [
                579.0471000000001,
                580.6928592307694,
                582.4645992307693,
                584.2363392307693,
                null
              ],
              [
                577.0562084615385,
                578.7295184615385,
                580.4303792307693,
                582.2677392307693,
                584.1050992307694
              ],
              [
                575.0876084615386,
                577.0890184615386,
                578.6638984615386,
                580.5668784615385,
                582.6010984615385
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_584d50_2d50_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_584d50_2d50_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.476449999999886,
                0.1640500000000884,
                null,
                null,
                null
              ],
              [
                -2.952899999999886,
                -1.3071407692306138,
                0.464599230769295,
                2.236339230769317,
                null
              ],
              [
                -4.943791538461483,
                -3.270481538461468,
                -1.5696207692307098,
                0.2677392307692798,
                2.105099230769383
              ],
              [
                -6.912391538461407,
                -4.910981538461442,
                -3.3361015384614348,
                -1.433121538461478,
                0.6010984615385269
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_584d50_2d50_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_584d50_2d50_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1955200000002,
                585.96726,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1448950000001,
                584.0314700000001,
                585.9016400000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17801",
      "component_name": "run3",
      "save_point_id": 1968,
      "magnitude_ft": 581.5,
      "elevation_ft": 584.5,
      "runup_ft": 3.0,
      "baseline_ari": 1.3635,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17801_run3_1968",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                1.3634729421675025,
                null,
                null,
                null,
                null
              ],
              [
                6.614689039302702,
                1.284824295376844,
                null,
                null,
                null
              ],
              [
                30.79768890700058,
                5.480904892576822,
                1.167538335209925,
                1.0165349338336969,
                null
              ],
              [
                375.8370095875605,
                35.70504932114278,
                7.217762343397074,
                1.2613158845765444,
                1.0280786848488543
              ],
              [
                1000.5000833333622,
                278.07919800101143,
                35.412709873678416,
                5.699666290546883,
                1.1533494276095264
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_584d50_3d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_584d50_3d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                581.5000000000001,
                null,
                null,
                null,
                null
              ],
              [
                580.0075637037038,
                581.6640500000001,
                null,
                null,
                null
              ],
              [
                578.5151274074075,
                580.1716137037038,
                581.9433537037038,
                583.7150937037037,
                null
              ],
              [
                576.5137174074075,
                578.1870274074074,
                579.8931474074075,
                581.7305074074075,
                583.5678674074074
              ],
              [
                574.5291311111113,
                576.5305411111112,
                578.1054211111112,
                580.0084011111112,
                582.0426211111112
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_584d50_3d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_584d50_3d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.492436296296319,
                0.1640499999999747,
                null,
                null,
                null
              ],
              [
                -2.9848725925926374,
                -1.328386296296344,
                0.4433537037036785,
                2.2150937037035874,
                null
              ],
              [
                -4.986282592592602,
                -3.3129725925927005,
                -1.6068525925926451,
                0.2305074074073445,
                2.067867407407334
              ],
              [
                -6.970868888888845,
                -4.96945888888888,
                -3.394578888888873,
                -1.491598888888916,
                0.5426211111110888
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_584d50_3d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_584d50_3d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1955200000002,
                585.96726,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1448950000001,
                584.0314700000001,
                585.9016400000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17786",
      "component_name": "base",
      "save_point_id": 1968,
      "magnitude_ft": 584.0,
      "elevation_ft": 584.0,
      "runup_ft": 0.0,
      "baseline_ari": 24.057,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17786_base_1968",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                24.056973952005094,
                null,
                null,
                null,
                null
              ],
              [
                49.93747462211457,
                20.528666118967458,
                null,
                null,
                null
              ],
              [
                1000.5000833333622,
                46.40819245502311,
                10.2999965340185,
                1.5010903486136369,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                57.006732324753855,
                14.546775772261974,
                1.5667722890280522
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                45.91001280997219,
                8.779822522509344
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_584d00_0d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_584d00_0d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                584.0000000000001,
                null,
                null,
                null,
                null
              ],
              [
                582.5563600000002,
                584.1929737254903,
                null,
                null,
                null
              ],
              [
                581.1166062745099,
                582.75322,
                584.5538837254903,
                586.3256237254902,
                null
              ],
              [
                579.2097400000001,
                580.8502400000001,
                582.4907400000001,
                584.3898337254902,
                586.2600037254904
              ],
              [
                577.2778362745099,
                579.2792462745099,
                580.8541262745099,
                582.7571062745099,
                584.7913262745099
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_584d00_0d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_584d00_0d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.4436399999999594,
                0.1929737254902193,
                null,
                null,
                null
              ],
              [
                -2.8833937254902366,
                -1.246780000000058,
                0.5538837254902091,
                2.325623725490118,
                null
              ],
              [
                -4.790259999999989,
                -3.1497600000000148,
                -1.5092600000000402,
                0.3898337254901207,
                2.2600037254902645
              ],
              [
                -6.722163725490191,
                -4.720753725490226,
                -3.145873725490219,
                -1.242893725490262,
                0.7913262745097427
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_584d00_0d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_584d00_0d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1955200000002,
                585.96726,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1448950000001,
                584.0314700000001,
                585.9016400000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17786",
      "component_name": "run2",
      "save_point_id": 1968,
      "magnitude_ft": 582.0,
      "elevation_ft": 584.0,
      "runup_ft": 2.0,
      "baseline_ari": 1.7312,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17786_run2_1968",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                1.7312407488633237,
                null,
                null,
                null,
                null
              ],
              [
                10.073214800271067,
                1.532488990247557,
                null,
                null,
                null
              ],
              [
                39.588948853904206,
                8.938025172137348,
                1.3903280559494389,
                1.0443418901775965,
                null
              ],
              [
                1000.5000833333622,
                44.66883729937153,
                10.601383880252634,
                1.4889329178729296,
                1.0599218151400236
              ],
              [
                1000.5000833333622,
                943.2385827562924,
                44.20410831497598,
                9.006287437122669,
                1.3447964488287838
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_584d00_2d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_584d00_2d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                582.0,
                null,
                null,
                null,
                null
              ],
              [
                580.5235500000001,
                582.1640500000001,
                null,
                null,
                null
              ],
              [
                579.0471000000001,
                580.6928592307694,
                582.4645992307693,
                584.2363392307693,
                null
              ],
              [
                577.0562084615385,
                578.7295184615385,
                580.4303792307693,
                582.2677392307693,
                584.1050992307694
              ],
              [
                575.0876084615386,
                577.0890184615386,
                578.6638984615386,
                580.5668784615385,
                582.6010984615385
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_584d00_2d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_584d00_2d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.476449999999886,
                0.1640500000000884,
                null,
                null,
                null
              ],
              [
                -2.952899999999886,
                -1.3071407692306138,
                0.464599230769295,
                2.236339230769317,
                null
              ],
              [
                -4.943791538461483,
                -3.270481538461468,
                -1.5696207692307098,
                0.2677392307692798,
                2.105099230769383
              ],
              [
                -6.912391538461407,
                -4.910981538461442,
                -3.3361015384614348,
                -1.433121538461478,
                0.6010984615385269
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_584d00_2d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_584d00_2d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1955200000002,
                585.96726,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1448950000001,
                584.0314700000001,
                585.9016400000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17786",
      "component_name": "run25",
      "save_point_id": 1968,
      "magnitude_ft": 581.5,
      "elevation_ft": 584.0,
      "runup_ft": 2.5,
      "baseline_ari": 1.3635,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17786_run25_1968",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                1.3634729421675025,
                null,
                null,
                null,
                null
              ],
              [
                6.614689039302702,
                1.284824295376844,
                null,
                null,
                null
              ],
              [
                30.79768890700058,
                5.480904892576822,
                1.167538335209925,
                1.0165349338336969,
                null
              ],
              [
                375.8370095875605,
                35.70504932114278,
                7.217762343397074,
                1.2613158845765444,
                1.0280786848488543
              ],
              [
                1000.5000833333622,
                278.07919800101143,
                35.412709873678416,
                5.699666290546883,
                1.1533494276095264
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_584d00_2d50_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_584d00_2d50_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                581.5000000000001,
                null,
                null,
                null,
                null
              ],
              [
                580.0075637037038,
                581.6640500000001,
                null,
                null,
                null
              ],
              [
                578.5151274074075,
                580.1716137037038,
                581.9433537037038,
                583.7150937037037,
                null
              ],
              [
                576.5137174074075,
                578.1870274074074,
                579.8931474074075,
                581.7305074074075,
                583.5678674074074
              ],
              [
                574.5291311111113,
                576.5305411111112,
                578.1054211111112,
                580.0084011111112,
                582.0426211111112
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_584d00_2d50_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_584d00_2d50_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.492436296296319,
                0.1640499999999747,
                null,
                null,
                null
              ],
              [
                -2.9848725925926374,
                -1.328386296296344,
                0.4433537037036785,
                2.2150937037035874,
                null
              ],
              [
                -4.986282592592602,
                -3.3129725925927005,
                -1.6068525925926451,
                0.2305074074073445,
                2.067867407407334
              ],
              [
                -6.970868888888845,
                -4.96945888888888,
                -3.394578888888873,
                -1.491598888888916,
                0.5426211111110888
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_584d00_2d50_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_584d00_2d50_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1955200000002,
                585.96726,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1448950000001,
                584.0314700000001,
                585.9016400000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17786",
      "component_name": "run3",
      "save_point_id": 1968,
      "magnitude_ft": 581.0,
      "elevation_ft": 584.0,
      "runup_ft": 3.0,
      "baseline_ari": 1.1514,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17786_run3_1968",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                1.1514058737555488,
                null,
                null,
                null,
                null
              ],
              [
                3.3025564235593228,
                1.1342168548843787,
                null,
                null,
                null
              ],
              [
                22.00693485158549,
                2.374288295826097,
                1.1085376934942812,
                1.005764384178229,
                null
              ],
              [
                98.527366414656,
                26.741589611185685,
                3.8187948519863193,
                1.1323622615948237,
                1.0081210063023822
              ],
              [
                1000.5000833333622,
                83.5275199989944,
                26.621634704516676,
                2.660204389354396,
                1.1133747311484905
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_584d00_3d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_584d00_3d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                581.0000000000001,
                null,
                null,
                null,
                null
              ],
              [
                579.4876376271188,
                581.1624988135594,
                null,
                null,
                null
              ],
              [
                577.9752752542373,
                579.6509120338985,
                581.4242032203391,
                583.195943220339,
                null
              ],
              [
                575.9692116949153,
                577.6456240677967,
                579.3548464406781,
                581.1922064406781,
                583.0295664406781
              ],
              [
                573.9631481355933,
                575.9645581355934,
                577.5394381355934,
                579.4424181355934,
                581.4766381355934
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_584d00_3d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_584d00_3d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.5123623728812845,
                0.1624988135592957,
                null,
                null,
                null
              ],
              [
                -3.0247247457627964,
                -1.3490879661015924,
                0.4242032203389954,
                2.195943220338904,
                null
              ],
              [
                -5.030788305084798,
                -3.354375932203425,
                -1.6451535593220117,
                0.1922064406779782,
                2.029566440677968
              ],
              [
                -7.036851864406799,
                -5.035441864406721,
                -3.460561864406713,
                -1.5575818644067567,
                0.4766381355932481
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_584d00_3d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_584d00_3d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1955200000002,
                585.96726,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1448950000001,
                584.0314700000001,
                585.9016400000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17771",
      "component_name": "base",
      "save_point_id": 1968,
      "magnitude_ft": 583.5,
      "elevation_ft": 583.5,
      "runup_ft": 0.0,
      "baseline_ari": 10.4633,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17771_base_1968",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                10.46327532981882,
                null,
                null,
                null,
                null
              ],
              [
                40.97357955935377,
                9.327989779984494,
                null,
                null,
                null
              ],
              [
                494.5477151544534,
                37.444364508669175,
                6.991463155076583,
                1.2646385945773313,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                42.149991985050015,
                8.177862867205413,
                1.332794838112259
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                800.5991593199152,
                37.118574796006754,
                5.477105609251001
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_583d50_0d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_583d50_0d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.5000000000002,
                null,
                null,
                null,
                null
              ],
              [
                582.0563600000002,
                583.6640500000001,
                null,
                null,
                null
              ],
              [
                580.6124240909093,
                582.2204100000001,
                584.0246640909093,
                585.7964040909092,
                null
              ],
              [
                578.6766340909093,
                580.3171340909092,
                581.9904440909093,
                583.8603181818183,
                585.7304881818183
              ],
              [
                576.7408440909093,
                578.7422540909092,
                580.3171340909092,
                582.2201140909092,
                584.2543340909092
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_583d50_0d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_583d50_0d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.443640000000073,
                0.164049999999861,
                null,
                null,
                null
              ],
              [
                -2.8875759090909696,
                -1.2795900000000984,
                0.5246640909090274,
                2.2964040909089363,
                null
              ],
              [
                -4.823365909090967,
                -3.1828659090909923,
                -1.5095559090909774,
                0.3603181818181156,
                2.230488181818032
              ],
              [
                -6.759155909090964,
                -4.757745909091,
                -3.1828659090909923,
                -1.2798859090910355,
                0.7543340909089693
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_583d50_0d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_583d50_0d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1955200000002,
                585.96726,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1448950000001,
                584.0314700000001,
                585.9016400000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17771",
      "component_name": "run2",
      "save_point_id": 1968,
      "magnitude_ft": 581.5,
      "elevation_ft": 583.5,
      "runup_ft": 2.0,
      "baseline_ari": 1.3635,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17771_run2_1968",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                1.3634729421675025,
                null,
                null,
                null,
                null
              ],
              [
                6.614689039302702,
                1.284824295376844,
                null,
                null,
                null
              ],
              [
                30.79768890700058,
                5.480904892576822,
                1.167538335209925,
                1.0165349338336969,
                null
              ],
              [
                375.8370095875605,
                35.70504932114278,
                7.217762343397074,
                1.2613158845765444,
                1.0280786848488543
              ],
              [
                1000.5000833333622,
                278.07919800101143,
                35.412709873678416,
                5.699666290546883,
                1.1533494276095264
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_583d50_2d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_583d50_2d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                581.5000000000001,
                null,
                null,
                null,
                null
              ],
              [
                580.0075637037038,
                581.6640500000001,
                null,
                null,
                null
              ],
              [
                578.5151274074075,
                580.1716137037038,
                581.9433537037038,
                583.7150937037037,
                null
              ],
              [
                576.5137174074075,
                578.1870274074074,
                579.8931474074075,
                581.7305074074075,
                583.5678674074074
              ],
              [
                574.5291311111113,
                576.5305411111112,
                578.1054211111112,
                580.0084011111112,
                582.0426211111112
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_583d50_2d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_583d50_2d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.492436296296319,
                0.1640499999999747,
                null,
                null,
                null
              ],
              [
                -2.9848725925926374,
                -1.328386296296344,
                0.4433537037036785,
                2.2150937037035874,
                null
              ],
              [
                -4.986282592592602,
                -3.3129725925927005,
                -1.6068525925926451,
                0.2305074074073445,
                2.067867407407334
              ],
              [
                -6.970868888888845,
                -4.96945888888888,
                -3.394578888888873,
                -1.491598888888916,
                0.5426211111110888
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_583d50_2d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_583d50_2d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1955200000002,
                585.96726,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1448950000001,
                584.0314700000001,
                585.9016400000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17771",
      "component_name": "run25",
      "save_point_id": 1968,
      "magnitude_ft": 581.0,
      "elevation_ft": 583.5,
      "runup_ft": 2.5,
      "baseline_ari": 1.1514,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17771_run25_1968",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                1.1514058737555488,
                null,
                null,
                null,
                null
              ],
              [
                3.3025564235593228,
                1.1342168548843787,
                null,
                null,
                null
              ],
              [
                22.00693485158549,
                2.374288295826097,
                1.1085376934942812,
                1.005764384178229,
                null
              ],
              [
                98.527366414656,
                26.741589611185685,
                3.8187948519863193,
                1.1323622615948237,
                1.0081210063023822
              ],
              [
                1000.5000833333622,
                83.5275199989944,
                26.621634704516676,
                2.660204389354396,
                1.1133747311484905
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_583d50_2d50_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_583d50_2d50_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                581.0000000000001,
                null,
                null,
                null,
                null
              ],
              [
                579.4876376271188,
                581.1624988135594,
                null,
                null,
                null
              ],
              [
                577.9752752542373,
                579.6509120338985,
                581.4242032203391,
                583.195943220339,
                null
              ],
              [
                575.9692116949153,
                577.6456240677967,
                579.3548464406781,
                581.1922064406781,
                583.0295664406781
              ],
              [
                573.9631481355933,
                575.9645581355934,
                577.5394381355934,
                579.4424181355934,
                581.4766381355934
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_583d50_2d50_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_583d50_2d50_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.5123623728812845,
                0.1624988135592957,
                null,
                null,
                null
              ],
              [
                -3.0247247457627964,
                -1.3490879661015924,
                0.4242032203389954,
                2.195943220338904,
                null
              ],
              [
                -5.030788305084798,
                -3.354375932203425,
                -1.6451535593220117,
                0.1922064406779782,
                2.029566440677968
              ],
              [
                -7.036851864406799,
                -5.035441864406721,
                -3.460561864406713,
                -1.5575818644067567,
                0.4766381355932481
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_583d50_2d50_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_583d50_2d50_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1955200000002,
                585.96726,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1448950000001,
                584.0314700000001,
                585.9016400000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17771",
      "component_name": "run3",
      "save_point_id": 1968,
      "magnitude_ft": 580.5,
      "elevation_ft": 583.5,
      "runup_ft": 3.0,
      "baseline_ari": 1.099,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17771_run3_1968",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                1.098982278271753,
                null,
                null,
                null,
                null
              ],
              [
                1.67948031529807,
                1.0855605224166684,
                null,
                null,
                null
              ],
              [
                9.71905655241662,
                1.522570648308757,
                1.0644595497442282,
                1.0037372091493786,
                null
              ],
              [
                47.187694927477104,
                15.871469766346411,
                1.874776715870524,
                1.0867216303497027,
                1.0048013094367123
              ],
              [
                1000.5000833333622,
                45.52072429311094,
                15.871469766346411,
                1.60448796645884,
                1.077470672608223
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_583d50_3d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_583d50_3d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                580.5000000000001,
                null,
                null,
                null,
                null
              ],
              [
                578.953739322034,
                580.645549661017,
                null,
                null,
                null
              ],
              [
                577.4074786440679,
                579.1085391525424,
                580.8987794915255,
                582.6705194915254,
                null
              ],
              [
                575.3505676271187,
                577.0608783050848,
                578.803998983051,
                580.641358983051,
                582.478718983051
              ],
              [
                573.2936566101696,
                575.2950666101696,
                576.8699466101696,
                578.7729266101695,
                580.8071466101695
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_583d50_3d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_583d50_3d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.5462606779660746,
                0.1455496610168438,
                null,
                null,
                null
              ],
              [
                -3.092521355932263,
                -1.3914608474576653,
                0.3987794915253744,
                2.1705194915252832,
                null
              ],
              [
                -5.149432372881392,
                -3.439121694915343,
                -1.6960010169491395,
                0.1413589830508499,
                1.97871898305084
              ],
              [
                -7.206343389830522,
                -5.204933389830558,
                -3.6300533898305503,
                -1.7270733898305934,
                0.3071466101694113
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_583d50_3d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_583d50_3d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1955200000002,
                585.96726,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1448950000001,
                584.0314700000001,
                585.9016400000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17756",
      "component_name": "base",
      "save_point_id": 1968,
      "magnitude_ft": 583.0,
      "elevation_ft": 583.0,
      "runup_ft": 0.0,
      "baseline_ari": 7.0043,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17756_base_1968",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                7.004270656204618,
                null,
                null,
                null,
                null
              ],
              [
                32.009896942472764,
                5.870627198912554,
                null,
                null,
                null
              ],
              [
                140.0820254487798,
                28.48081881277908,
                3.5800933029902584,
                1.1310800448045506,
                null
              ],
              [
                1000.5000833333622,
                297.654695665757,
                33.18627233076584,
                4.956224070767818,
                1.1484297420032183
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                215.83662040136005,
                28.3274152287085,
                2.5129251154926835
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_583d00_0d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_583d00_0d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.0,
                null,
                null,
                null,
                null
              ],
              [
                581.5563599999999,
                583.1640499999999,
                null,
                null,
                null
              ],
              [
                580.0896968181817,
                581.7204099999999,
                583.5019368181817,
                585.2736768181818,
                null
              ],
              [
                578.1539068181817,
                579.7944068181818,
                581.4677168181818,
                583.3148636363636,
                585.1850336363635
              ],
              [
                576.2181168181817,
                578.2195268181817,
                579.7944068181818,
                581.6973868181817,
                583.7316068181817
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_583d00_0d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_583d00_0d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.443640000000073,
                0.164049999999861,
                null,
                null,
                null
              ],
              [
                -2.910303181818336,
                -1.2795900000000984,
                0.5019368181816617,
                2.273676818181798,
                null
              ],
              [
                -4.846093181818333,
                -3.2055931818182444,
                -1.5322831818182294,
                0.3148636363636115,
                2.185033636363528
              ],
              [
                -6.78188318181833,
                -4.780473181818252,
                -3.2055931818182444,
                -1.3026131818182876,
                0.7316068181817172
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_583d00_0d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_583d00_0d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1955200000002,
                585.96726,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1448950000001,
                584.0314700000001,
                585.9016400000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17756",
      "component_name": "run2",
      "save_point_id": 1968,
      "magnitude_ft": 581.0,
      "elevation_ft": 583.0,
      "runup_ft": 2.0,
      "baseline_ari": 1.1514,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17756_run2_1968",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                1.1514058737555488,
                null,
                null,
                null,
                null
              ],
              [
                3.3025564235593228,
                1.1342168548843787,
                null,
                null,
                null
              ],
              [
                22.00693485158549,
                2.374288295826097,
                1.1085376934942812,
                1.005764384178229,
                null
              ],
              [
                98.527366414656,
                26.741589611185685,
                3.8187948519863193,
                1.1323622615948237,
                1.0081210063023822
              ],
              [
                1000.5000833333622,
                83.5275199989944,
                26.621634704516676,
                2.660204389354396,
                1.1133747311484905
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_583d00_2d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_583d00_2d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                581.0000000000001,
                null,
                null,
                null,
                null
              ],
              [
                579.4876376271188,
                581.1624988135594,
                null,
                null,
                null
              ],
              [
                577.9752752542373,
                579.6509120338985,
                581.4242032203391,
                583.195943220339,
                null
              ],
              [
                575.9692116949153,
                577.6456240677967,
                579.3548464406781,
                581.1922064406781,
                583.0295664406781
              ],
              [
                573.9631481355933,
                575.9645581355934,
                577.5394381355934,
                579.4424181355934,
                581.4766381355934
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_583d00_2d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_583d00_2d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.5123623728812845,
                0.1624988135592957,
                null,
                null,
                null
              ],
              [
                -3.0247247457627964,
                -1.3490879661015924,
                0.4242032203389954,
                2.195943220338904,
                null
              ],
              [
                -5.030788305084798,
                -3.354375932203425,
                -1.6451535593220117,
                0.1922064406779782,
                2.029566440677968
              ],
              [
                -7.036851864406799,
                -5.035441864406721,
                -3.460561864406713,
                -1.5575818644067567,
                0.4766381355932481
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_583d00_2d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_583d00_2d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1955200000002,
                585.96726,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1448950000001,
                584.0314700000001,
                585.9016400000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17756",
      "component_name": "run25",
      "save_point_id": 1968,
      "magnitude_ft": 580.5,
      "elevation_ft": 583.0,
      "runup_ft": 2.5,
      "baseline_ari": 1.099,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17756_run25_1968",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                1.098982278271753,
                null,
                null,
                null,
                null
              ],
              [
                1.67948031529807,
                1.0855605224166684,
                null,
                null,
                null
              ],
              [
                9.71905655241662,
                1.522570648308757,
                1.0644595497442282,
                1.0037372091493786,
                null
              ],
              [
                47.187694927477104,
                15.871469766346411,
                1.874776715870524,
                1.0867216303497027,
                1.0048013094367123
              ],
              [
                1000.5000833333622,
                45.52072429311094,
                15.871469766346411,
                1.60448796645884,
                1.077470672608223
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_583d00_2d50_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_583d00_2d50_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                580.5000000000001,
                null,
                null,
                null,
                null
              ],
              [
                578.953739322034,
                580.645549661017,
                null,
                null,
                null
              ],
              [
                577.4074786440679,
                579.1085391525424,
                580.8987794915255,
                582.6705194915254,
                null
              ],
              [
                575.3505676271187,
                577.0608783050848,
                578.803998983051,
                580.641358983051,
                582.478718983051
              ],
              [
                573.2936566101696,
                575.2950666101696,
                576.8699466101696,
                578.7729266101695,
                580.8071466101695
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_583d00_2d50_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_583d00_2d50_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.5462606779660746,
                0.1455496610168438,
                null,
                null,
                null
              ],
              [
                -3.092521355932263,
                -1.3914608474576653,
                0.3987794915253744,
                2.1705194915252832,
                null
              ],
              [
                -5.149432372881392,
                -3.439121694915343,
                -1.6960010169491395,
                0.1413589830508499,
                1.97871898305084
              ],
              [
                -7.206343389830522,
                -5.204933389830558,
                -3.6300533898305503,
                -1.7270733898305934,
                0.3071466101694113
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_583d00_2d50_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_583d00_2d50_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1955200000002,
                585.96726,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1448950000001,
                584.0314700000001,
                585.9016400000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17756",
      "component_name": "run3",
      "save_point_id": 1968,
      "magnitude_ft": 580.0,
      "elevation_ft": 583.0,
      "runup_ft": 3.0,
      "baseline_ari": 1.0547,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17756_run3_1968",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                1.054698847149397,
                null,
                null,
                null,
                null
              ],
              [
                1.3599097312266497,
                1.0453272471051946,
                null,
                null,
                null
              ],
              [
                6.411252797840353,
                1.2841519245043995,
                1.0300291670143082,
                1.0022408221485035,
                null
              ],
              [
                38.22385067604155,
                8.36425804451728,
                1.4125919507684672,
                1.0484251404650913,
                1.0030724759625147
              ],
              [
                945.9245014325082,
                36.72929486541654,
                8.36425804451728,
                1.3597791868048887,
                1.0468992879299694
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_583d00_3d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_583d00_3d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                580.0000000000001,
                null,
                null,
                null,
                null
              ],
              [
                578.4198410169494,
                580.1286005084747,
                null,
                null,
                null
              ],
              [
                576.8396820338984,
                578.5661662711866,
                580.3733557627121,
                582.145095762712,
                null
              ],
              [
                574.7319235593221,
                576.4761325423731,
                578.2531515254238,
                580.0905115254238,
                581.9278715254238
              ],
              [
                572.624165084746,
                574.6255750847458,
                576.200455084746,
                578.1034350847459,
                580.1376550847459
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_583d00_3d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_583d00_3d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.580158983050751,
                0.1286005084746193,
                null,
                null,
                null
              ],
              [
                -3.1603179661017293,
                -1.4338337288135108,
                0.3733557627119808,
                2.1450957627118896,
                null
              ],
              [
                -5.268076440677987,
                -3.523867457627034,
                -1.746848474576268,
                0.0905115254237216,
                1.9278715254237115
              ],
              [
                -7.375834915254131,
                -5.374424915254281,
                -3.79954491525416,
                -1.8965649152542028,
                0.137655084745802
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_583d00_3d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_583d00_3d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1955200000002,
                585.96726,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1448950000001,
                584.0314700000001,
                585.9016400000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17740",
      "component_name": "base",
      "save_point_id": 1968,
      "magnitude_ft": 582.5,
      "elevation_ft": 582.5,
      "runup_ft": 0.0,
      "baseline_ari": 3.5254,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17740_base_1968",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                3.5253803484545223,
                null,
                null,
                null,
                null
              ],
              [
                23.04668018756305,
                2.490522381281896,
                null,
                null,
                null
              ],
              [
                48.38043601668874,
                18.82762000835909,
                1.8039879581827296,
                1.0835720297012998,
                null
              ],
              [
                1000.5000833333622,
                80.07367078121361,
                24.22296744176476,
                2.2156578867003063,
                1.1008752337913468
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                72.1165247902927,
                18.82762000835909,
                1.571599257356843
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_582d50_0d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_582d50_0d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                582.5,
                null,
                null,
                null,
                null
              ],
              [
                581.0344607692307,
                582.66405,
                null,
                null,
                null
              ],
              [
                579.5580107692307,
                581.2204099999999,
                582.9921499999999,
                584.76389,
                null
              ],
              [
                577.6222207692307,
                579.2846199999999,
                580.9579299999999,
                582.7952899999999,
                584.6435607692307
              ],
              [
                575.6645315384615,
                577.6659415384614,
                579.2408215384614,
                581.1438015384614,
                583.1780215384614
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_582d50_0d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_582d50_0d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.4655392307693091,
                0.1640499999999747,
                null,
                null,
                null
              ],
              [
                -2.941989230769309,
                -1.2795900000000984,
                0.4921499999999241,
                2.2638899999999467,
                null
              ],
              [
                -4.877779230769306,
                -3.215380000000096,
                -1.5420700000000809,
                0.295289999999909,
                2.143560769230703
              ],
              [
                -6.83546846153854,
                -4.834058461538575,
                -3.259178461538568,
                -1.356198461538611,
                0.6780215384613939
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_582d50_0d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_582d50_0d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1955200000002,
                585.96726,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1448950000001,
                584.0314700000001,
                585.9016400000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17740",
      "component_name": "run2",
      "save_point_id": 1968,
      "magnitude_ft": 580.5,
      "elevation_ft": 582.5,
      "runup_ft": 2.0,
      "baseline_ari": 1.099,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17740_run2_1968",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                1.098982278271753,
                null,
                null,
                null,
                null
              ],
              [
                1.67948031529807,
                1.0855605224166684,
                null,
                null,
                null
              ],
              [
                9.71905655241662,
                1.522570648308757,
                1.0644595497442282,
                1.0037372091493786,
                null
              ],
              [
                47.187694927477104,
                15.871469766346411,
                1.874776715870524,
                1.0867216303497027,
                1.0048013094367123
              ],
              [
                1000.5000833333622,
                45.52072429311094,
                15.871469766346411,
                1.60448796645884,
                1.077470672608223
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_582d50_2d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_582d50_2d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                580.5000000000001,
                null,
                null,
                null,
                null
              ],
              [
                578.953739322034,
                580.645549661017,
                null,
                null,
                null
              ],
              [
                577.4074786440679,
                579.1085391525424,
                580.8987794915255,
                582.6705194915254,
                null
              ],
              [
                575.3505676271187,
                577.0608783050848,
                578.803998983051,
                580.641358983051,
                582.478718983051
              ],
              [
                573.2936566101696,
                575.2950666101696,
                576.8699466101696,
                578.7729266101695,
                580.8071466101695
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_582d50_2d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_582d50_2d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.5462606779660746,
                0.1455496610168438,
                null,
                null,
                null
              ],
              [
                -3.092521355932263,
                -1.3914608474576653,
                0.3987794915253744,
                2.1705194915252832,
                null
              ],
              [
                -5.149432372881392,
                -3.439121694915343,
                -1.6960010169491395,
                0.1413589830508499,
                1.97871898305084
              ],
              [
                -7.206343389830522,
                -5.204933389830558,
                -3.6300533898305503,
                -1.7270733898305934,
                0.3071466101694113
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_582d50_2d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_582d50_2d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1955200000002,
                585.96726,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1448950000001,
                584.0314700000001,
                585.9016400000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17740",
      "component_name": "run25",
      "save_point_id": 1968,
      "magnitude_ft": 580.0,
      "elevation_ft": 582.5,
      "runup_ft": 2.5,
      "baseline_ari": 1.0547,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17740_run25_1968",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                1.054698847149397,
                null,
                null,
                null,
                null
              ],
              [
                1.3599097312266497,
                1.0453272471051946,
                null,
                null,
                null
              ],
              [
                6.411252797840353,
                1.2841519245043995,
                1.0300291670143082,
                1.0022408221485035,
                null
              ],
              [
                38.22385067604155,
                8.36425804451728,
                1.4125919507684672,
                1.0484251404650913,
                1.0030724759625147
              ],
              [
                945.9245014325082,
                36.72929486541654,
                8.36425804451728,
                1.3597791868048887,
                1.0468992879299694
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_582d50_2d50_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_582d50_2d50_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                580.0000000000001,
                null,
                null,
                null,
                null
              ],
              [
                578.4198410169494,
                580.1286005084747,
                null,
                null,
                null
              ],
              [
                576.8396820338984,
                578.5661662711866,
                580.3733557627121,
                582.145095762712,
                null
              ],
              [
                574.7319235593221,
                576.4761325423731,
                578.2531515254238,
                580.0905115254238,
                581.9278715254238
              ],
              [
                572.624165084746,
                574.6255750847458,
                576.200455084746,
                578.1034350847459,
                580.1376550847459
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_582d50_2d50_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_582d50_2d50_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.580158983050751,
                0.1286005084746193,
                null,
                null,
                null
              ],
              [
                -3.1603179661017293,
                -1.4338337288135108,
                0.3733557627119808,
                2.1450957627118896,
                null
              ],
              [
                -5.268076440677987,
                -3.523867457627034,
                -1.746848474576268,
                0.0905115254237216,
                1.9278715254237115
              ],
              [
                -7.375834915254131,
                -5.374424915254281,
                -3.79954491525416,
                -1.8965649152542028,
                0.137655084745802
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_582d50_2d50_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_582d50_2d50_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1955200000002,
                585.96726,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1448950000001,
                584.0314700000001,
                585.9016400000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17740",
      "component_name": "run3",
      "save_point_id": 1968,
      "magnitude_ft": 579.5,
      "elevation_ft": 582.5,
      "runup_ft": 3.0,
      "baseline_ari": 1.022,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17740_run3_1968",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                1.021975133232912,
                null,
                null,
                null,
                null
              ],
              [
                1.1526947815276154,
                1.016796338958725,
                null,
                null,
                null
              ],
              [
                3.1505019876651925,
                1.1361604994000412,
                1.008453089366712,
                1.0012134564393638,
                null
              ],
              [
                29.260270859941897,
                5.030960003453853,
                1.1936098118220309,
                1.0201677513441765,
                1.001814514012106
              ],
              [
                279.25123408859594,
                27.938153338011308,
                5.09569735459433,
                1.1562084896271652,
                1.0232123887271083
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_582d50_3d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_582d50_3d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                579.4999999999999,
                null,
                null,
                null,
                null
              ],
              [
                577.8859427118642,
                579.6116513559322,
                null,
                null,
                null
              ],
              [
                576.2718854237287,
                578.0237933898303,
                579.8479320338982,
                581.6196720338982,
                null
              ],
              [
                574.1132794915252,
                575.8913867796609,
                577.7023040677965,
                579.5396640677965,
                581.3770240677965
              ],
              [
                571.9546735593219,
                573.9560835593219,
                575.5309635593219,
                577.4339435593218,
                579.4681635593219
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_582d50_3d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_582d50_3d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.6140572881356547,
                0.1116513559322811,
                null,
                null,
                null
              ],
              [
                -3.228114576271196,
                -1.4762066101695837,
                0.3479320338983598,
                2.1196720338982686,
                null
              ],
              [
                -5.386720508474696,
                -3.608613220338953,
                -1.7976959322033963,
                0.0396640677965933,
                1.877024067796583
              ],
              [
                -7.545326440677968,
                -5.543916440678004,
                -3.969036440677996,
                -2.0660564406780395,
                -0.0318364406780347
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_582d50_3d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_582d50_3d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1955200000002,
                585.96726,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1448950000001,
                584.0314700000001,
                585.9016400000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17725",
      "component_name": "base",
      "save_point_id": 1968,
      "magnitude_ft": 582.0,
      "elevation_ft": 582.0,
      "runup_ft": 0.0,
      "baseline_ari": 1.7312,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17725_base_1968",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                1.7312407488633237,
                null,
                null,
                null,
                null
              ],
              [
                10.073214800271067,
                1.532488990247557,
                null,
                null,
                null
              ],
              [
                39.588948853904206,
                8.938025172137348,
                1.3903280559494389,
                1.0443418901775965,
                null
              ],
              [
                1000.5000833333622,
                44.66883729937153,
                10.601383880252634,
                1.4889329178729296,
                1.0599218151400236
              ],
              [
                1000.5000833333622,
                943.2385827562924,
                44.20410831497598,
                9.006287437122669,
                1.3447964488287838
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_582d00_0d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_582d00_0d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                582.0,
                null,
                null,
                null,
                null
              ],
              [
                580.5235500000001,
                582.1640500000001,
                null,
                null,
                null
              ],
              [
                579.0471000000001,
                580.6928592307694,
                582.4645992307693,
                584.2363392307693,
                null
              ],
              [
                577.0562084615385,
                578.7295184615385,
                580.4303792307693,
                582.2677392307693,
                584.1050992307694
              ],
              [
                575.0876084615386,
                577.0890184615386,
                578.6638984615386,
                580.5668784615385,
                582.6010984615385
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_582d00_0d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_582d00_0d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.476449999999886,
                0.1640500000000884,
                null,
                null,
                null
              ],
              [
                -2.952899999999886,
                -1.3071407692306138,
                0.464599230769295,
                2.236339230769317,
                null
              ],
              [
                -4.943791538461483,
                -3.270481538461468,
                -1.5696207692307098,
                0.2677392307692798,
                2.105099230769383
              ],
              [
                -6.912391538461407,
                -4.910981538461442,
                -3.3361015384614348,
                -1.433121538461478,
                0.6010984615385269
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_582d00_0d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_582d00_0d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1955200000002,
                585.96726,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1448950000001,
                584.0314700000001,
                585.9016400000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17725",
      "component_name": "run2",
      "save_point_id": 1968,
      "magnitude_ft": 580.0,
      "elevation_ft": 582.0,
      "runup_ft": 2.0,
      "baseline_ari": 1.0547,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17725_run2_1968",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                1.054698847149397,
                null,
                null,
                null,
                null
              ],
              [
                1.3599097312266497,
                1.0453272471051946,
                null,
                null,
                null
              ],
              [
                6.411252797840353,
                1.2841519245043995,
                1.0300291670143082,
                1.0022408221485035,
                null
              ],
              [
                38.22385067604155,
                8.36425804451728,
                1.4125919507684672,
                1.0484251404650913,
                1.0030724759625147
              ],
              [
                945.9245014325082,
                36.72929486541654,
                8.36425804451728,
                1.3597791868048887,
                1.0468992879299694
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_582d00_2d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_582d00_2d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                580.0000000000001,
                null,
                null,
                null,
                null
              ],
              [
                578.4198410169494,
                580.1286005084747,
                null,
                null,
                null
              ],
              [
                576.8396820338984,
                578.5661662711866,
                580.3733557627121,
                582.145095762712,
                null
              ],
              [
                574.7319235593221,
                576.4761325423731,
                578.2531515254238,
                580.0905115254238,
                581.9278715254238
              ],
              [
                572.624165084746,
                574.6255750847458,
                576.200455084746,
                578.1034350847459,
                580.1376550847459
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_582d00_2d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_582d00_2d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.580158983050751,
                0.1286005084746193,
                null,
                null,
                null
              ],
              [
                -3.1603179661017293,
                -1.4338337288135108,
                0.3733557627119808,
                2.1450957627118896,
                null
              ],
              [
                -5.268076440677987,
                -3.523867457627034,
                -1.746848474576268,
                0.0905115254237216,
                1.9278715254237115
              ],
              [
                -7.375834915254131,
                -5.374424915254281,
                -3.79954491525416,
                -1.8965649152542028,
                0.137655084745802
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_582d00_2d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_582d00_2d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1955200000002,
                585.96726,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1448950000001,
                584.0314700000001,
                585.9016400000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17725",
      "component_name": "run25",
      "save_point_id": 1968,
      "magnitude_ft": 579.5,
      "elevation_ft": 582.0,
      "runup_ft": 2.5,
      "baseline_ari": 1.022,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17725_run25_1968",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                1.021975133232912,
                null,
                null,
                null,
                null
              ],
              [
                1.1526947815276154,
                1.016796338958725,
                null,
                null,
                null
              ],
              [
                3.1505019876651925,
                1.1361604994000412,
                1.008453089366712,
                1.0012134564393638,
                null
              ],
              [
                29.260270859941897,
                5.030960003453853,
                1.1936098118220309,
                1.0201677513441765,
                1.001814514012106
              ],
              [
                279.25123408859594,
                27.938153338011308,
                5.09569735459433,
                1.1562084896271652,
                1.0232123887271083
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_582d00_2d50_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_582d00_2d50_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                579.4999999999999,
                null,
                null,
                null,
                null
              ],
              [
                577.8859427118642,
                579.6116513559322,
                null,
                null,
                null
              ],
              [
                576.2718854237287,
                578.0237933898303,
                579.8479320338982,
                581.6196720338982,
                null
              ],
              [
                574.1132794915252,
                575.8913867796609,
                577.7023040677965,
                579.5396640677965,
                581.3770240677965
              ],
              [
                571.9546735593219,
                573.9560835593219,
                575.5309635593219,
                577.4339435593218,
                579.4681635593219
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_582d00_2d50_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_582d00_2d50_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.6140572881356547,
                0.1116513559322811,
                null,
                null,
                null
              ],
              [
                -3.228114576271196,
                -1.4762066101695837,
                0.3479320338983598,
                2.1196720338982686,
                null
              ],
              [
                -5.386720508474696,
                -3.608613220338953,
                -1.7976959322033963,
                0.0396640677965933,
                1.877024067796583
              ],
              [
                -7.545326440677968,
                -5.543916440678004,
                -3.969036440677996,
                -2.0660564406780395,
                -0.0318364406780347
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_582d00_2d50_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_582d00_2d50_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1955200000002,
                585.96726,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1448950000001,
                584.0314700000001,
                585.9016400000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17725",
      "component_name": "run3",
      "save_point_id": 1968,
      "magnitude_ft": 579.0,
      "elevation_ft": 582.0,
      "runup_ft": 3.0,
      "baseline_ari": 1.0062,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17725_run3_1968",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                1.006197503459065,
                null,
                null,
                null,
                null
              ],
              [
                1.103244312807061,
                1.0057316877029878,
                null,
                null,
                null
              ],
              [
                1.6280677518307975,
                1.0893730106683646,
                1.0047700061887823,
                1.0005734466216036,
                null
              ],
              [
                20.15251903472671,
                2.2583458343069838,
                1.1168499475512006,
                1.0062519316706875,
                1.0009652696650173
              ],
              [
                83.74239092228282,
                18.152999607386924,
                2.3882090587205367,
                1.115993239156289,
                1.0079039412059687
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_582d00_3d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_582d00_3d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                579.0,
                null,
                null,
                null,
                null
              ],
              [
                577.350239368421,
                579.0949572631579,
                null,
                null,
                null
              ],
              [
                575.6993211578947,
                577.4791642105262,
                579.3199969473684,
                581.0917369473683,
                null
              ],
              [
                573.4894753684209,
                575.303286,
                577.1510642105262,
                578.9884242105262,
                580.8246266315789
              ],
              [
                571.2784719999999,
                573.2798819999998,
                574.8547619999998,
                576.7577419999998,
                578.7919619999998
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_582d00_3d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_582d00_3d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.6497606315790565,
                0.0949572631578803,
                null,
                null,
                null
              ],
              [
                -3.300678842105299,
                -1.5208357894738356,
                0.319996947368395,
                2.091736947368304,
                null
              ],
              [
                -5.510524631579074,
                -3.6967140000000422,
                -1.848935789473785,
                -0.0115757894737953,
                1.8246266315788944
              ],
              [
                -7.721528000000148,
                -5.720118000000184,
                -4.145238000000177,
                -2.24225800000022,
                -0.2080380000002151
              ]
            ]
          },
          "path": "batch_twl_output/baseline/1968_582d00_3d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/1968_582d00_3d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1955200000002,
                585.96726,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1448950000001,
                584.0314700000001,
                585.9016400000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint1968_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17877",
      "component_name": "base",
      "save_point_id": 4997,
      "magnitude_ft": 587.0,
      "elevation_ft": 587.0,
      "runup_ft": 0.0,
      "baseline_ari": 1000.5001,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17877_base_4997",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                1000.5000833333622,
                null,
                null,
                null,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                null,
                null,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                873.5316915105041,
                36.98811145488898,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                38.18803873018834
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                287.4097692688405
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_587d00_0d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_587d00_0d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                586.5906500000001,
                null,
                null,
                null,
                null
              ],
              [
                585.1798200000002,
                586.7875100000001,
                null,
                null,
                null
              ],
              [
                583.7689900000001,
                585.3766800000002,
                587.0499900000001,
                588.8217300000002,
                null
              ],
              [
                581.8988200000001,
                583.4737000000001,
                585.0157700000001,
                586.8203200000002,
                588.6248700000002
              ],
              [
                580.0286500000002,
                582.03006,
                583.6049400000002,
                585.5079200000001,
                587.5421400000001
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_587d00_0d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_587d00_0d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                -0.4093499999997902,
                null,
                null,
                null,
                null
              ],
              [
                -1.8201799999997093,
                -0.2124899999997751,
                null,
                null,
                null
              ],
              [
                -3.231009999999742,
                -1.623319999999694,
                0.0499900000002071,
                1.8217300000003436,
                null
              ],
              [
                -5.101179999999772,
                -3.5262999999997646,
                -1.9842299999997977,
                -0.1796799999997347,
                1.6248700000003282
              ],
              [
                -6.971349999999688,
                -4.969939999999838,
                -3.3950599999997166,
                -1.4920799999997598,
                0.542140000000245
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_587d00_0d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_587d00_0d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8182050000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1627100000002,
                585.9344500000001,
                null
              ],
              [
                578.8474900000002,
                580.4715850000002,
                582.1284900000002,
                583.9986600000002,
                585.8688300000001
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17877",
      "component_name": "run2",
      "save_point_id": 4997,
      "magnitude_ft": 585.0,
      "elevation_ft": 587.0,
      "runup_ft": 2.0,
      "baseline_ari": 42.4136,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17877_run2_4997",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                42.413600605774576,
                null,
                null,
                null,
                null
              ],
              [
                609.02541233797,
                39.04295857232975,
                null,
                null,
                null
              ],
              [
                1000.5000833333622,
                378.3007802711424,
                32.814191324300545,
                5.176187871354827,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                960.4462414379184,
                35.81397222310425,
                5.845919061602015
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                313.4841126425738,
                27.86737105707066
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_587d00_2d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_587d00_2d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                585.0,
                null,
                null,
                null,
                null
              ],
              [
                583.55636,
                585.1880140000001,
                null,
                null,
                null
              ],
              [
                582.1366840000001,
                583.7532199999999,
                585.52496,
                587.2967,
                null
              ],
              [
                580.20974,
                581.841394,
                583.49074,
                585.36091,
                587.2310799999999
              ],
              [
                578.297914,
                580.299324,
                581.874204,
                583.777184,
                585.811404
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_587d00_2d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_587d00_2d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.4436399999999594,
                0.1880140000000665,
                null,
                null,
                null
              ],
              [
                -2.8633159999999407,
                -1.246780000000058,
                0.5249599999999646,
                2.296699999999987,
                null
              ],
              [
                -4.790259999999989,
                -3.1586059999999634,
                -1.5092600000000402,
                0.3609099999999898,
                2.2310799999999062
              ],
              [
                -6.702086000000008,
                -4.700676000000044,
                -3.1257960000000367,
                -1.2228159999999662,
                0.8114040000000386
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_587d00_2d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_587d00_2d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8182050000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1627100000002,
                585.9344500000001,
                null
              ],
              [
                578.8474900000002,
                580.4715850000002,
                582.1284900000002,
                583.9986600000002,
                585.8688300000001
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17877",
      "component_name": "run25",
      "save_point_id": 4997,
      "magnitude_ft": 584.5,
      "elevation_ft": 587.0,
      "runup_ft": 2.5,
      "baseline_ari": 33.2706,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17877_run25_4997",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                33.27060160623789,
                null,
                null,
                null,
                null
              ],
              [
                166.50172114452798,
                30.0793454554318,
                null,
                null,
                null
              ],
              [
                1000.5000833333622,
                96.90135210393171,
                23.67165531326204,
                2.28207884322574,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                208.9033258034596,
                26.671242985221188,
                2.600315575805411
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                91.90139939276231,
                17.78491976573462
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_587d00_2d50_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_587d00_2d50_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                584.5000000000001,
                null,
                null,
                null,
                null
              ],
              [
                583.05636,
                584.678014,
                null,
                null,
                null
              ],
              [
                581.626684,
                583.2532199999999,
                585.0249600000001,
                586.7967,
                null
              ],
              [
                579.70974,
                581.331394,
                582.9907400000001,
                584.86091,
                586.73108
              ],
              [
                577.787914,
                579.7893240000001,
                581.3642040000001,
                583.2671839999999,
                585.301404
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_587d00_2d50_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_587d00_2d50_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.443640000000073,
                0.1780139999998482,
                null,
                null,
                null
              ],
              [
                -2.873316000000159,
                -1.2467800000001716,
                0.5249599999999646,
                2.2966999999998734,
                null
              ],
              [
                -4.790260000000103,
                -3.168606000000068,
                -1.5092600000000402,
                0.3609099999998761,
                2.2310799999999062
              ],
              [
                -6.712086000000113,
                -4.710676000000035,
                -3.135796000000028,
                -1.2328160000001844,
                0.8014039999999341
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_587d00_2d50_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_587d00_2d50_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8182050000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1627100000002,
                585.9344500000001,
                null
              ],
              [
                578.8474900000002,
                580.4715850000002,
                582.1284900000002,
                583.9986600000002,
                585.8688300000001
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17877",
      "component_name": "run3",
      "save_point_id": 4997,
      "magnitude_ft": 584.0,
      "elevation_ft": 587.0,
      "runup_ft": 3.0,
      "baseline_ari": 24.128,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17877_run3_4997",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                24.128032029646075,
                null,
                null,
                null,
                null
              ],
              [
                50.70586591124777,
                21.116302276332917,
                null,
                null,
                null
              ],
              [
                1000.5000833333622,
                46.92629973931165,
                10.549139272690889,
                1.4981216558913604,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                61.83936529138348,
                15.546381269068569,
                1.5662300621833565
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                46.40819245502311,
                8.701271391407191
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_587d00_3d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_587d00_3d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                584.0000000000001,
                null,
                null,
                null,
                null
              ],
              [
                582.5563600000002,
                584.1680140000001,
                null,
                null,
                null
              ],
              [
                581.1166840000001,
                582.75322,
                584.5249600000001,
                586.2967000000001,
                null
              ],
              [
                579.2097400000001,
                580.8213940000002,
                582.4907400000001,
                584.3609100000001,
                586.23108
              ],
              [
                577.2779140000001,
                579.2793240000001,
                580.8542040000001,
                582.757184,
                584.791404
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_587d00_3d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_587d00_3d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.4436399999999594,
                0.168013999999971,
                null,
                null,
                null
              ],
              [
                -2.883316000000036,
                -1.246780000000058,
                0.5249599999999646,
                2.296699999999987,
                null
              ],
              [
                -4.790259999999989,
                -3.178605999999945,
                -1.5092600000000402,
                0.3609099999999898,
                2.2310799999999062
              ],
              [
                -6.72208599999999,
                -4.720676000000026,
                -3.1457960000000185,
                -1.2428160000000616,
                0.7914039999999432
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_587d00_3d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_587d00_3d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8182050000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1627100000002,
                585.9344500000001,
                null
              ],
              [
                578.8474900000002,
                580.4715850000002,
                582.1284900000002,
                583.9986600000002,
                585.8688300000001
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17862",
      "component_name": "base",
      "save_point_id": 4997,
      "magnitude_ft": 586.5,
      "elevation_ft": 586.5,
      "runup_ft": 0.0,
      "baseline_ari": 803.1517,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17862_base_4997",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                803.1517344225526,
                null,
                null,
                null,
                null
              ],
              [
                1000.5000833333622,
                452.42171608148186,
                null,
                null,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                190.9644728827347,
                27.84532141269581,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                341.73767182257257,
                29.045193283245226
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                86.68658104520398
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_586d50_0d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_586d50_0d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                586.5,
                null,
                null,
                null,
                null
              ],
              [
                585.08917,
                586.69686,
                null,
                null,
                null
              ],
              [
                583.6783399999999,
                585.28603,
                586.9722899999999,
                588.7440300000001,
                null
              ],
              [
                581.7952199999999,
                583.3830499999999,
                584.9380699999999,
                586.7555699999999,
                588.56012
              ],
              [
                579.9250499999999,
                581.9264599999999,
                583.5013399999999,
                585.4043199999999,
                587.4385399999999
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_586d50_0d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_586d50_0d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.410830000000033,
                0.1968600000000151,
                null,
                null,
                null
              ],
              [
                -2.8216600000000653,
                -1.2139700000000175,
                0.4722899999999299,
                2.244030000000066,
                null
              ],
              [
                -4.704780000000142,
                -3.116950000000088,
                -1.5619300000000749,
                0.2555699999999206,
                2.0601199999999835
              ],
              [
                -6.574950000000058,
                -4.573540000000094,
                -2.9986600000000863,
                -1.0956800000001294,
                0.9385399999998754
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_586d50_0d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_586d50_0d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8182050000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1627100000002,
                585.9344500000001,
                null
              ],
              [
                578.8474900000002,
                580.4715850000002,
                582.1284900000002,
                583.9986600000002,
                585.8688300000001
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17862",
      "component_name": "run2",
      "save_point_id": 4997,
      "magnitude_ft": 584.5,
      "elevation_ft": 586.5,
      "runup_ft": 2.0,
      "baseline_ari": 33.2706,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17862_run2_4997",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                33.27060160623789,
                null,
                null,
                null,
                null
              ],
              [
                166.50172114452798,
                30.0793454554318,
                null,
                null,
                null
              ],
              [
                1000.5000833333622,
                96.90135210393171,
                23.67165531326204,
                2.28207884322574,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                208.9033258034596,
                26.671242985221188,
                2.600315575805411
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                91.90139939276231,
                17.78491976573462
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_586d50_2d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_586d50_2d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                584.5000000000001,
                null,
                null,
                null,
                null
              ],
              [
                583.05636,
                584.678014,
                null,
                null,
                null
              ],
              [
                581.626684,
                583.2532199999999,
                585.0249600000001,
                586.7967,
                null
              ],
              [
                579.70974,
                581.331394,
                582.9907400000001,
                584.86091,
                586.73108
              ],
              [
                577.787914,
                579.7893240000001,
                581.3642040000001,
                583.2671839999999,
                585.301404
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_586d50_2d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_586d50_2d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.443640000000073,
                0.1780139999998482,
                null,
                null,
                null
              ],
              [
                -2.873316000000159,
                -1.2467800000001716,
                0.5249599999999646,
                2.2966999999998734,
                null
              ],
              [
                -4.790260000000103,
                -3.168606000000068,
                -1.5092600000000402,
                0.3609099999998761,
                2.2310799999999062
              ],
              [
                -6.712086000000113,
                -4.710676000000035,
                -3.135796000000028,
                -1.2328160000001844,
                0.8014039999999341
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_586d50_2d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_586d50_2d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8182050000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1627100000002,
                585.9344500000001,
                null
              ],
              [
                578.8474900000002,
                580.4715850000002,
                582.1284900000002,
                583.9986600000002,
                585.8688300000001
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17862",
      "component_name": "run25",
      "save_point_id": 4997,
      "magnitude_ft": 584.0,
      "elevation_ft": 586.5,
      "runup_ft": 2.5,
      "baseline_ari": 24.128,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17862_run25_4997",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                24.128032029646075,
                null,
                null,
                null,
                null
              ],
              [
                50.70586591124777,
                21.116302276332917,
                null,
                null,
                null
              ],
              [
                1000.5000833333622,
                46.92629973931165,
                10.549139272690889,
                1.4981216558913604,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                61.83936529138348,
                15.546381269068569,
                1.5662300621833565
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                46.40819245502311,
                8.701271391407191
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_586d50_2d50_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_586d50_2d50_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                584.0000000000001,
                null,
                null,
                null,
                null
              ],
              [
                582.5563600000002,
                584.1680140000001,
                null,
                null,
                null
              ],
              [
                581.1166840000001,
                582.75322,
                584.5249600000001,
                586.2967000000001,
                null
              ],
              [
                579.2097400000001,
                580.8213940000002,
                582.4907400000001,
                584.3609100000001,
                586.23108
              ],
              [
                577.2779140000001,
                579.2793240000001,
                580.8542040000001,
                582.757184,
                584.791404
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_586d50_2d50_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_586d50_2d50_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.4436399999999594,
                0.168013999999971,
                null,
                null,
                null
              ],
              [
                -2.883316000000036,
                -1.246780000000058,
                0.5249599999999646,
                2.296699999999987,
                null
              ],
              [
                -4.790259999999989,
                -3.178605999999945,
                -1.5092600000000402,
                0.3609099999999898,
                2.2310799999999062
              ],
              [
                -6.72208599999999,
                -4.720676000000026,
                -3.1457960000000185,
                -1.2428160000000616,
                0.7914039999999432
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_586d50_2d50_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_586d50_2d50_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8182050000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1627100000002,
                585.9344500000001,
                null
              ],
              [
                578.8474900000002,
                580.4715850000002,
                582.1284900000002,
                583.9986600000002,
                585.8688300000001
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17862",
      "component_name": "run3",
      "save_point_id": 4997,
      "magnitude_ft": 583.5,
      "elevation_ft": 586.5,
      "runup_ft": 3.0,
      "baseline_ari": 10.4633,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17862_run3_4997",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                10.46327532981882,
                null,
                null,
                null,
                null
              ],
              [
                41.38298934847683,
                9.327989779984494,
                null,
                null,
                null
              ],
              [
                467.8161296685657,
                37.783186181969846,
                7.0585405777560535,
                1.2537457313683718,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                42.5829312210852,
                8.293657451506158,
                1.3242961929004993
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                800.5991593199152,
                37.444364508669175,
                5.277809951727623
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_586d50_3d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_586d50_3d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.5000000000002,
                null,
                null,
                null,
                null
              ],
              [
                582.0563600000002,
                583.6640500000001,
                null,
                null,
                null
              ],
              [
                580.6127200000002,
                582.2204100000001,
                583.9921500000002,
                585.7638900000002,
                null
              ],
              [
                578.6769300000002,
                580.3174300000002,
                581.9579300000001,
                583.8278040909092,
                585.6979740909092
              ],
              [
                576.7411400000002,
                578.7425500000002,
                580.3174300000002,
                582.2204100000001,
                584.2546300000001
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_586d50_3d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_586d50_3d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.443640000000073,
                0.164049999999861,
                null,
                null,
                null
              ],
              [
                -2.8872800000000325,
                -1.2795900000000984,
                0.4921499999999241,
                2.2638899999999467,
                null
              ],
              [
                -4.82307000000003,
                -3.182570000000055,
                -1.5420700000000809,
                0.3278040909090123,
                2.1979740909089287
              ],
              [
                -6.758860000000027,
                -4.757450000000063,
                -3.182570000000055,
                -1.2795900000000984,
                0.7546299999999064
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_586d50_3d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_586d50_3d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8182050000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1627100000002,
                585.9344500000001,
                null
              ],
              [
                578.8474900000002,
                580.4715850000002,
                582.1284900000002,
                583.9986600000002,
                585.8688300000001
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17847",
      "component_name": "base",
      "save_point_id": 4997,
      "magnitude_ft": 586.0,
      "elevation_ft": 586.0,
      "runup_ft": 0.0,
      "baseline_ari": 189.3656,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17847_base_4997",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                189.36562461066205,
                null,
                null,
                null,
                null
              ],
              [
                1000.5000833333622,
                125.47399810961852,
                null,
                null,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                56.04520311260036,
                17.50276879738751,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                83.82248071824804,
                19.502252759030117
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                45.7947025123477
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_586d00_0d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_586d00_0d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                586.0,
                null,
                null,
                null,
                null
              ],
              [
                584.5600133333334,
                586.1677033333334,
                null,
                null,
                null
              ],
              [
                583.1455300000001,
                584.7568733333334,
                586.4958033333334,
                588.2675433333334,
                null
              ],
              [
                581.24255,
                582.8538933333334,
                584.4615833333334,
                586.3317533333334,
                588.1691133333334
              ],
              [
                579.33957,
                581.3409800000001,
                582.9158600000001,
                584.81884,
                586.85306
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_586d00_0d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_586d00_0d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.4399866666666412,
                0.1677033333334066,
                null,
                null,
                null
              ],
              [
                -2.8544699999998784,
                -1.243126666666626,
                0.495803333333356,
                2.2675433333333785,
                null
              ],
              [
                -4.757449999999949,
                -3.146106666666583,
                -1.5384166666666488,
                0.3317533333333813,
                2.169113333333371
              ],
              [
                -6.660430000000019,
                -4.659019999999941,
                -3.084139999999934,
                -1.1811599999999771,
                0.8530600000000277
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_586d00_0d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_586d00_0d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8182050000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1627100000002,
                585.9344500000001,
                null
              ],
              [
                578.8474900000002,
                580.4715850000002,
                582.1284900000002,
                583.9986600000002,
                585.8688300000001
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17847",
      "component_name": "run2",
      "save_point_id": 4997,
      "magnitude_ft": 584.0,
      "elevation_ft": 586.0,
      "runup_ft": 2.0,
      "baseline_ari": 24.128,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17847_run2_4997",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                24.128032029646075,
                null,
                null,
                null,
                null
              ],
              [
                50.70586591124777,
                21.116302276332917,
                null,
                null,
                null
              ],
              [
                1000.5000833333622,
                46.92629973931165,
                10.549139272690889,
                1.4981216558913604,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                61.83936529138348,
                15.546381269068569,
                1.5662300621833565
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                46.40819245502311,
                8.701271391407191
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_586d00_2d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_586d00_2d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                584.0000000000001,
                null,
                null,
                null,
                null
              ],
              [
                582.5563600000002,
                584.1680140000001,
                null,
                null,
                null
              ],
              [
                581.1166840000001,
                582.75322,
                584.5249600000001,
                586.2967000000001,
                null
              ],
              [
                579.2097400000001,
                580.8213940000002,
                582.4907400000001,
                584.3609100000001,
                586.23108
              ],
              [
                577.2779140000001,
                579.2793240000001,
                580.8542040000001,
                582.757184,
                584.791404
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_586d00_2d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_586d00_2d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.4436399999999594,
                0.168013999999971,
                null,
                null,
                null
              ],
              [
                -2.883316000000036,
                -1.246780000000058,
                0.5249599999999646,
                2.296699999999987,
                null
              ],
              [
                -4.790259999999989,
                -3.178605999999945,
                -1.5092600000000402,
                0.3609099999999898,
                2.2310799999999062
              ],
              [
                -6.72208599999999,
                -4.720676000000026,
                -3.1457960000000185,
                -1.2428160000000616,
                0.7914039999999432
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_586d00_2d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_586d00_2d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8182050000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1627100000002,
                585.9344500000001,
                null
              ],
              [
                578.8474900000002,
                580.4715850000002,
                582.1284900000002,
                583.9986600000002,
                585.8688300000001
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17847",
      "component_name": "run25",
      "save_point_id": 4997,
      "magnitude_ft": 583.5,
      "elevation_ft": 586.0,
      "runup_ft": 2.5,
      "baseline_ari": 10.4633,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17847_run25_4997",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                10.46327532981882,
                null,
                null,
                null,
                null
              ],
              [
                41.38298934847683,
                9.327989779984494,
                null,
                null,
                null
              ],
              [
                467.8161296685657,
                37.783186181969846,
                7.0585405777560535,
                1.2537457313683718,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                42.5829312210852,
                8.293657451506158,
                1.3242961929004993
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                800.5991593199152,
                37.444364508669175,
                5.277809951727623
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_586d00_2d50_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_586d00_2d50_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.5000000000002,
                null,
                null,
                null,
                null
              ],
              [
                582.0563600000002,
                583.6640500000001,
                null,
                null,
                null
              ],
              [
                580.6127200000002,
                582.2204100000001,
                583.9921500000002,
                585.7638900000002,
                null
              ],
              [
                578.6769300000002,
                580.3174300000002,
                581.9579300000001,
                583.8278040909092,
                585.6979740909092
              ],
              [
                576.7411400000002,
                578.7425500000002,
                580.3174300000002,
                582.2204100000001,
                584.2546300000001
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_586d00_2d50_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_586d00_2d50_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.443640000000073,
                0.164049999999861,
                null,
                null,
                null
              ],
              [
                -2.8872800000000325,
                -1.2795900000000984,
                0.4921499999999241,
                2.2638899999999467,
                null
              ],
              [
                -4.82307000000003,
                -3.182570000000055,
                -1.5420700000000809,
                0.3278040909090123,
                2.1979740909089287
              ],
              [
                -6.758860000000027,
                -4.757450000000063,
                -3.182570000000055,
                -1.2795900000000984,
                0.7546299999999064
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_586d00_2d50_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_586d00_2d50_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8182050000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1627100000002,
                585.9344500000001,
                null
              ],
              [
                578.8474900000002,
                580.4715850000002,
                582.1284900000002,
                583.9986600000002,
                585.8688300000001
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17847",
      "component_name": "run3",
      "save_point_id": 4997,
      "magnitude_ft": 583.0,
      "elevation_ft": 586.0,
      "runup_ft": 3.0,
      "baseline_ari": 7.0043,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17847_run3_4997",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                7.004270656204618,
                null,
                null,
                null,
                null
              ],
              [
                32.240022805738874,
                5.870627198912554,
                null,
                null,
                null
              ],
              [
                140.0820254487798,
                28.64035873017482,
                3.5800933029902584,
                1.1282037655087171,
                null
              ],
              [
                1000.5000833333622,
                297.654695665757,
                33.43992714832558,
                4.909545769316608,
                1.145316953401041
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                239.55856254906053,
                28.48081881277908,
                2.4477193193060285
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_586d00_3d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_586d00_3d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.0,
                null,
                null,
                null,
                null
              ],
              [
                581.5563599999999,
                583.1640499999999,
                null,
                null,
                null
              ],
              [
                580.11272,
                581.7204099999999,
                583.4921499999999,
                585.26389,
                null
              ],
              [
                578.17693,
                579.81743,
                581.4579299999999,
                583.3050768181818,
                585.1752468181818
              ],
              [
                576.24114,
                578.2425499999999,
                579.81743,
                581.7204099999999,
                583.7546299999999
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_586d00_3d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_586d00_3d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.443640000000073,
                0.164049999999861,
                null,
                null,
                null
              ],
              [
                -2.8872800000000325,
                -1.2795900000000984,
                0.4921499999999241,
                2.2638899999999467,
                null
              ],
              [
                -4.82307000000003,
                -3.182570000000055,
                -1.5420700000000809,
                0.3050768181817602,
                2.1752468181817903
              ],
              [
                -6.758860000000027,
                -4.757450000000063,
                -3.182570000000055,
                -1.2795900000000984,
                0.7546299999999064
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_586d00_3d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_586d00_3d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8182050000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1627100000002,
                585.9344500000001,
                null
              ],
              [
                578.8474900000002,
                580.4715850000002,
                582.1284900000002,
                583.9986600000002,
                585.8688300000001
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17832",
      "component_name": "base",
      "save_point_id": 4997,
      "magnitude_ft": 585.5,
      "elevation_ft": 585.5,
      "runup_ft": 0.0,
      "baseline_ari": 60.2715,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17832_base_4997",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                60.27145078018571,
                null,
                null,
                null,
                null
              ],
              [
                1000.5000833333622,
                48.00681899762254,
                null,
                null,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                41.95717629221885,
                8.637208213117399,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                44.95704063987329,
                9.152815493136142
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                985.4132208487472,
                36.83088807163813
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_585d50_0d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_585d50_0d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                585.5000000000001,
                null,
                null,
                null,
                null
              ],
              [
                584.0627711111111,
                585.6968600000001,
                null,
                null,
                null
              ],
              [
                582.64553,
                584.259631111111,
                586.0249600000001,
                587.7967,
                null
              ],
              [
                580.7161511111111,
                582.3566511111112,
                583.9907400000001,
                585.86091,
                587.7246688888889
              ],
              [
                578.8131711111112,
                580.8145811111111,
                582.3894611111111,
                584.2924411111112,
                586.3266611111112
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_585d50_0d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_585d50_0d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.437228888888967,
                0.1968600000000151,
                null,
                null,
                null
              ],
              [
                -2.8544700000001058,
                -1.2403688888890656,
                0.5249599999999646,
                2.2966999999998734,
                null
              ],
              [
                -4.783848888888997,
                -3.1433488888889087,
                -1.5092600000000402,
                0.3609099999998761,
                2.2246688888888
              ],
              [
                -6.686828888888954,
                -4.685418888888989,
                -3.110538888888982,
                -1.2075588888889115,
                0.8266611111110933
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_585d50_0d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_585d50_0d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8182050000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1627100000002,
                585.9344500000001,
                null
              ],
              [
                578.8474900000002,
                580.4715850000002,
                582.1284900000002,
                583.9986600000002,
                585.8688300000001
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17832",
      "component_name": "run2",
      "save_point_id": 4997,
      "magnitude_ft": 583.5,
      "elevation_ft": 585.5,
      "runup_ft": 2.0,
      "baseline_ari": 10.4633,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17832_run2_4997",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                10.46327532981882,
                null,
                null,
                null,
                null
              ],
              [
                41.38298934847683,
                9.327989779984494,
                null,
                null,
                null
              ],
              [
                467.8161296685657,
                37.783186181969846,
                7.0585405777560535,
                1.2537457313683718,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                42.5829312210852,
                8.293657451506158,
                1.3242961929004993
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                800.5991593199152,
                37.444364508669175,
                5.277809951727623
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_585d50_2d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_585d50_2d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.5000000000002,
                null,
                null,
                null,
                null
              ],
              [
                582.0563600000002,
                583.6640500000001,
                null,
                null,
                null
              ],
              [
                580.6127200000002,
                582.2204100000001,
                583.9921500000002,
                585.7638900000002,
                null
              ],
              [
                578.6769300000002,
                580.3174300000002,
                581.9579300000001,
                583.8278040909092,
                585.6979740909092
              ],
              [
                576.7411400000002,
                578.7425500000002,
                580.3174300000002,
                582.2204100000001,
                584.2546300000001
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_585d50_2d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_585d50_2d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.443640000000073,
                0.164049999999861,
                null,
                null,
                null
              ],
              [
                -2.8872800000000325,
                -1.2795900000000984,
                0.4921499999999241,
                2.2638899999999467,
                null
              ],
              [
                -4.82307000000003,
                -3.182570000000055,
                -1.5420700000000809,
                0.3278040909090123,
                2.1979740909089287
              ],
              [
                -6.758860000000027,
                -4.757450000000063,
                -3.182570000000055,
                -1.2795900000000984,
                0.7546299999999064
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_585d50_2d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_585d50_2d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8182050000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1627100000002,
                585.9344500000001,
                null
              ],
              [
                578.8474900000002,
                580.4715850000002,
                582.1284900000002,
                583.9986600000002,
                585.8688300000001
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17832",
      "component_name": "run25",
      "save_point_id": 4997,
      "magnitude_ft": 583.0,
      "elevation_ft": 585.5,
      "runup_ft": 2.5,
      "baseline_ari": 7.0043,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17832_run25_4997",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                7.004270656204618,
                null,
                null,
                null,
                null
              ],
              [
                32.240022805738874,
                5.870627198912554,
                null,
                null,
                null
              ],
              [
                140.0820254487798,
                28.64035873017482,
                3.5800933029902584,
                1.1282037655087171,
                null
              ],
              [
                1000.5000833333622,
                297.654695665757,
                33.43992714832558,
                4.909545769316608,
                1.145316953401041
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                239.55856254906053,
                28.48081881277908,
                2.4477193193060285
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_585d50_2d50_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_585d50_2d50_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.0,
                null,
                null,
                null,
                null
              ],
              [
                581.5563599999999,
                583.1640499999999,
                null,
                null,
                null
              ],
              [
                580.11272,
                581.7204099999999,
                583.4921499999999,
                585.26389,
                null
              ],
              [
                578.17693,
                579.81743,
                581.4579299999999,
                583.3050768181818,
                585.1752468181818
              ],
              [
                576.24114,
                578.2425499999999,
                579.81743,
                581.7204099999999,
                583.7546299999999
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_585d50_2d50_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_585d50_2d50_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.443640000000073,
                0.164049999999861,
                null,
                null,
                null
              ],
              [
                -2.8872800000000325,
                -1.2795900000000984,
                0.4921499999999241,
                2.2638899999999467,
                null
              ],
              [
                -4.82307000000003,
                -3.182570000000055,
                -1.5420700000000809,
                0.3050768181817602,
                2.1752468181817903
              ],
              [
                -6.758860000000027,
                -4.757450000000063,
                -3.182570000000055,
                -1.2795900000000984,
                0.7546299999999064
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_585d50_2d50_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_585d50_2d50_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8182050000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1627100000002,
                585.9344500000001,
                null
              ],
              [
                578.8474900000002,
                580.4715850000002,
                582.1284900000002,
                583.9986600000002,
                585.8688300000001
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17832",
      "component_name": "run3",
      "save_point_id": 4997,
      "magnitude_ft": 582.5,
      "elevation_ft": 585.5,
      "runup_ft": 3.0,
      "baseline_ari": 3.5254,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17832_run3_4997",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                3.5253803484545223,
                null,
                null,
                null,
                null
              ],
              [
                23.097531540428896,
                2.424332960614084,
                null,
                null,
                null
              ],
              [
                48.92705745828836,
                18.82762000835909,
                1.8039879581827296,
                1.081783308658708,
                null
              ],
              [
                1000.5000833333622,
                82.11638221741748,
                24.29734554389109,
                2.1726068539727352,
                1.0987833456191751
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                77.11644885167266,
                18.82762000835909,
                1.5563055239274124
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_585d50_3d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_585d50_3d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                582.5,
                null,
                null,
                null,
                null
              ],
              [
                581.0344607692307,
                582.6859492307692,
                null,
                null,
                null
              ],
              [
                579.5908207692307,
                581.2423092307691,
                582.9921499999999,
                584.76389,
                null
              ],
              [
                577.6331315384615,
                579.31743,
                580.9798292307693,
                582.8171892307693,
                584.6435607692307
              ],
              [
                575.6973415384614,
                577.6987515384614,
                579.2736315384615,
                581.1766115384614,
                583.2108315384614
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_585d50_3d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_585d50_3d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.4655392307693091,
                0.1859492307692107,
                null,
                null,
                null
              ],
              [
                -2.9091792307692685,
                -1.2576907692308623,
                0.4921499999999241,
                2.2638899999999467,
                null
              ],
              [
                -4.866868461538502,
                -3.182570000000055,
                -1.520170769230731,
                0.3171892307692587,
                2.143560769230703
              ],
              [
                -6.802658461538613,
                -4.801248461538648,
                -3.2263684615385277,
                -1.3233884615385705,
                0.7108315384614343
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_585d50_3d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_585d50_3d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8182050000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1627100000002,
                585.9344500000001,
                null
              ],
              [
                578.8474900000002,
                580.4715850000002,
                582.1284900000002,
                583.9986600000002,
                585.8688300000001
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17817",
      "component_name": "base",
      "save_point_id": 4997,
      "magnitude_ft": 585.0,
      "elevation_ft": 585.0,
      "runup_ft": 0.0,
      "baseline_ari": 42.4136,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17817_base_4997",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                42.413600605774576,
                null,
                null,
                null,
                null
              ],
              [
                609.02541233797,
                39.04295857232975,
                null,
                null,
                null
              ],
              [
                1000.5000833333622,
                378.3007802711424,
                32.814191324300545,
                5.176187871354827,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                960.4462414379184,
                35.81397222310425,
                5.845919061602015
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                313.4841126425738,
                27.86737105707066
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_585d00_0d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_585d00_0d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                585.0,
                null,
                null,
                null,
                null
              ],
              [
                583.55636,
                585.1880140000001,
                null,
                null,
                null
              ],
              [
                582.1366840000001,
                583.7532199999999,
                585.52496,
                587.2967,
                null
              ],
              [
                580.20974,
                581.841394,
                583.49074,
                585.36091,
                587.2310799999999
              ],
              [
                578.297914,
                580.299324,
                581.874204,
                583.777184,
                585.811404
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_585d00_0d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_585d00_0d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.4436399999999594,
                0.1880140000000665,
                null,
                null,
                null
              ],
              [
                -2.8633159999999407,
                -1.246780000000058,
                0.5249599999999646,
                2.296699999999987,
                null
              ],
              [
                -4.790259999999989,
                -3.1586059999999634,
                -1.5092600000000402,
                0.3609099999999898,
                2.2310799999999062
              ],
              [
                -6.702086000000008,
                -4.700676000000044,
                -3.1257960000000367,
                -1.2228159999999662,
                0.8114040000000386
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_585d00_0d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_585d00_0d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8182050000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1627100000002,
                585.9344500000001,
                null
              ],
              [
                578.8474900000002,
                580.4715850000002,
                582.1284900000002,
                583.9986600000002,
                585.8688300000001
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17817",
      "component_name": "run2",
      "save_point_id": 4997,
      "magnitude_ft": 583.0,
      "elevation_ft": 585.0,
      "runup_ft": 2.0,
      "baseline_ari": 7.0043,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17817_run2_4997",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                7.004270656204618,
                null,
                null,
                null,
                null
              ],
              [
                32.240022805738874,
                5.870627198912554,
                null,
                null,
                null
              ],
              [
                140.0820254487798,
                28.64035873017482,
                3.5800933029902584,
                1.1282037655087171,
                null
              ],
              [
                1000.5000833333622,
                297.654695665757,
                33.43992714832558,
                4.909545769316608,
                1.145316953401041
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                239.55856254906053,
                28.48081881277908,
                2.4477193193060285
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_585d00_2d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_585d00_2d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.0,
                null,
                null,
                null,
                null
              ],
              [
                581.5563599999999,
                583.1640499999999,
                null,
                null,
                null
              ],
              [
                580.11272,
                581.7204099999999,
                583.4921499999999,
                585.26389,
                null
              ],
              [
                578.17693,
                579.81743,
                581.4579299999999,
                583.3050768181818,
                585.1752468181818
              ],
              [
                576.24114,
                578.2425499999999,
                579.81743,
                581.7204099999999,
                583.7546299999999
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_585d00_2d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_585d00_2d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.443640000000073,
                0.164049999999861,
                null,
                null,
                null
              ],
              [
                -2.8872800000000325,
                -1.2795900000000984,
                0.4921499999999241,
                2.2638899999999467,
                null
              ],
              [
                -4.82307000000003,
                -3.182570000000055,
                -1.5420700000000809,
                0.3050768181817602,
                2.1752468181817903
              ],
              [
                -6.758860000000027,
                -4.757450000000063,
                -3.182570000000055,
                -1.2795900000000984,
                0.7546299999999064
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_585d00_2d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_585d00_2d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8182050000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1627100000002,
                585.9344500000001,
                null
              ],
              [
                578.8474900000002,
                580.4715850000002,
                582.1284900000002,
                583.9986600000002,
                585.8688300000001
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17817",
      "component_name": "run25",
      "save_point_id": 4997,
      "magnitude_ft": 582.5,
      "elevation_ft": 585.0,
      "runup_ft": 2.5,
      "baseline_ari": 3.5254,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17817_run25_4997",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                3.5253803484545223,
                null,
                null,
                null,
                null
              ],
              [
                23.097531540428896,
                2.424332960614084,
                null,
                null,
                null
              ],
              [
                48.92705745828836,
                18.82762000835909,
                1.8039879581827296,
                1.081783308658708,
                null
              ],
              [
                1000.5000833333622,
                82.11638221741748,
                24.29734554389109,
                2.1726068539727352,
                1.0987833456191751
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                77.11644885167266,
                18.82762000835909,
                1.5563055239274124
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_585d00_2d50_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_585d00_2d50_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                582.5,
                null,
                null,
                null,
                null
              ],
              [
                581.0344607692307,
                582.6859492307692,
                null,
                null,
                null
              ],
              [
                579.5908207692307,
                581.2423092307691,
                582.9921499999999,
                584.76389,
                null
              ],
              [
                577.6331315384615,
                579.31743,
                580.9798292307693,
                582.8171892307693,
                584.6435607692307
              ],
              [
                575.6973415384614,
                577.6987515384614,
                579.2736315384615,
                581.1766115384614,
                583.2108315384614
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_585d00_2d50_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_585d00_2d50_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.4655392307693091,
                0.1859492307692107,
                null,
                null,
                null
              ],
              [
                -2.9091792307692685,
                -1.2576907692308623,
                0.4921499999999241,
                2.2638899999999467,
                null
              ],
              [
                -4.866868461538502,
                -3.182570000000055,
                -1.520170769230731,
                0.3171892307692587,
                2.143560769230703
              ],
              [
                -6.802658461538613,
                -4.801248461538648,
                -3.2263684615385277,
                -1.3233884615385705,
                0.7108315384614343
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_585d00_2d50_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_585d00_2d50_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8182050000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1627100000002,
                585.9344500000001,
                null
              ],
              [
                578.8474900000002,
                580.4715850000002,
                582.1284900000002,
                583.9986600000002,
                585.8688300000001
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17817",
      "component_name": "run3",
      "save_point_id": 4997,
      "magnitude_ft": 582.0,
      "elevation_ft": 585.0,
      "runup_ft": 3.0,
      "baseline_ari": 1.7312,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17817_run3_4997",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                1.7312407488633237,
                null,
                null,
                null,
                null
              ],
              [
                10.073214800271067,
                1.532488990247557,
                null,
                null,
                null
              ],
              [
                39.963179945672486,
                8.938025172137348,
                1.3834355825570457,
                1.0434905682635494,
                null
              ],
              [
                1000.5000833333622,
                45.25704779540806,
                11.591333359612012,
                1.4856455270204394,
                1.0587503214713525
              ],
              [
                1000.5000833333622,
                943.2385827562924,
                44.66883729937153,
                8.938025172137348,
                1.3305303988619317
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_585d00_3d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_585d00_3d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                582.0,
                null,
                null,
                null,
                null
              ],
              [
                580.5235500000001,
                582.1693092307693,
                null,
                null,
                null
              ],
              [
                579.0523592307694,
                580.6981184615386,
                582.4645992307693,
                584.2363392307693,
                null
              ],
              [
                577.0837592307693,
                578.7623284615386,
                580.4356384615386,
                582.2729984615386,
                584.1050992307694
              ],
              [
                575.1204184615385,
                577.1218284615386,
                578.6967084615385,
                580.5996884615386,
                582.6339084615385
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_585d00_3d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_585d00_3d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.476449999999886,
                0.1693092307692723,
                null,
                null,
                null
              ],
              [
                -2.9476407692305884,
                -1.30188153846143,
                0.464599230769295,
                2.236339230769317,
                null
              ],
              [
                -4.91624076923074,
                -3.237671538461427,
                -1.5643615384614122,
                0.2729984615385774,
                2.105099230769383
              ],
              [
                -6.87958153846148,
                -4.878171538461402,
                -3.303291538461508,
                -1.4003115384614375,
                0.6339084615384536
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_585d00_3d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_585d00_3d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8182050000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1627100000002,
                585.9344500000001,
                null
              ],
              [
                578.8474900000002,
                580.4715850000002,
                582.1284900000002,
                583.9986600000002,
                585.8688300000001
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17801",
      "component_name": "base",
      "save_point_id": 4997,
      "magnitude_ft": 584.5,
      "elevation_ft": 584.5,
      "runup_ft": 0.0,
      "baseline_ari": 33.2706,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17801_base_4997",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                33.27060160623789,
                null,
                null,
                null,
                null
              ],
              [
                166.50172114452798,
                30.0793454554318,
                null,
                null,
                null
              ],
              [
                1000.5000833333622,
                96.90135210393171,
                23.67165531326204,
                2.28207884322574,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                208.9033258034596,
                26.671242985221188,
                2.600315575805411
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                91.90139939276231,
                17.78491976573462
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_584d50_0d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_584d50_0d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                584.5000000000001,
                null,
                null,
                null,
                null
              ],
              [
                583.05636,
                584.678014,
                null,
                null,
                null
              ],
              [
                581.626684,
                583.2532199999999,
                585.0249600000001,
                586.7967,
                null
              ],
              [
                579.70974,
                581.331394,
                582.9907400000001,
                584.86091,
                586.73108
              ],
              [
                577.787914,
                579.7893240000001,
                581.3642040000001,
                583.2671839999999,
                585.301404
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_584d50_0d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_584d50_0d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.443640000000073,
                0.1780139999998482,
                null,
                null,
                null
              ],
              [
                -2.873316000000159,
                -1.2467800000001716,
                0.5249599999999646,
                2.2966999999998734,
                null
              ],
              [
                -4.790260000000103,
                -3.168606000000068,
                -1.5092600000000402,
                0.3609099999998761,
                2.2310799999999062
              ],
              [
                -6.712086000000113,
                -4.710676000000035,
                -3.135796000000028,
                -1.2328160000001844,
                0.8014039999999341
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_584d50_0d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_584d50_0d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8182050000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1627100000002,
                585.9344500000001,
                null
              ],
              [
                578.8474900000002,
                580.4715850000002,
                582.1284900000002,
                583.9986600000002,
                585.8688300000001
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17801",
      "component_name": "run2",
      "save_point_id": 4997,
      "magnitude_ft": 582.5,
      "elevation_ft": 584.5,
      "runup_ft": 2.0,
      "baseline_ari": 3.5254,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17801_run2_4997",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                3.5253803484545223,
                null,
                null,
                null,
                null
              ],
              [
                23.097531540428896,
                2.424332960614084,
                null,
                null,
                null
              ],
              [
                48.92705745828836,
                18.82762000835909,
                1.8039879581827296,
                1.081783308658708,
                null
              ],
              [
                1000.5000833333622,
                82.11638221741748,
                24.29734554389109,
                2.1726068539727352,
                1.0987833456191751
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                77.11644885167266,
                18.82762000835909,
                1.5563055239274124
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_584d50_2d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_584d50_2d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                582.5,
                null,
                null,
                null,
                null
              ],
              [
                581.0344607692307,
                582.6859492307692,
                null,
                null,
                null
              ],
              [
                579.5908207692307,
                581.2423092307691,
                582.9921499999999,
                584.76389,
                null
              ],
              [
                577.6331315384615,
                579.31743,
                580.9798292307693,
                582.8171892307693,
                584.6435607692307
              ],
              [
                575.6973415384614,
                577.6987515384614,
                579.2736315384615,
                581.1766115384614,
                583.2108315384614
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_584d50_2d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_584d50_2d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.4655392307693091,
                0.1859492307692107,
                null,
                null,
                null
              ],
              [
                -2.9091792307692685,
                -1.2576907692308623,
                0.4921499999999241,
                2.2638899999999467,
                null
              ],
              [
                -4.866868461538502,
                -3.182570000000055,
                -1.520170769230731,
                0.3171892307692587,
                2.143560769230703
              ],
              [
                -6.802658461538613,
                -4.801248461538648,
                -3.2263684615385277,
                -1.3233884615385705,
                0.7108315384614343
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_584d50_2d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_584d50_2d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8182050000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1627100000002,
                585.9344500000001,
                null
              ],
              [
                578.8474900000002,
                580.4715850000002,
                582.1284900000002,
                583.9986600000002,
                585.8688300000001
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17801",
      "component_name": "run25",
      "save_point_id": 4997,
      "magnitude_ft": 582.0,
      "elevation_ft": 584.5,
      "runup_ft": 2.5,
      "baseline_ari": 1.7312,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17801_run25_4997",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                1.7312407488633237,
                null,
                null,
                null,
                null
              ],
              [
                10.073214800271067,
                1.532488990247557,
                null,
                null,
                null
              ],
              [
                39.963179945672486,
                8.938025172137348,
                1.3834355825570457,
                1.0434905682635494,
                null
              ],
              [
                1000.5000833333622,
                45.25704779540806,
                11.591333359612012,
                1.4856455270204394,
                1.0587503214713525
              ],
              [
                1000.5000833333622,
                943.2385827562924,
                44.66883729937153,
                8.938025172137348,
                1.3305303988619317
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_584d50_2d50_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_584d50_2d50_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                582.0,
                null,
                null,
                null,
                null
              ],
              [
                580.5235500000001,
                582.1693092307693,
                null,
                null,
                null
              ],
              [
                579.0523592307694,
                580.6981184615386,
                582.4645992307693,
                584.2363392307693,
                null
              ],
              [
                577.0837592307693,
                578.7623284615386,
                580.4356384615386,
                582.2729984615386,
                584.1050992307694
              ],
              [
                575.1204184615385,
                577.1218284615386,
                578.6967084615385,
                580.5996884615386,
                582.6339084615385
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_584d50_2d50_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_584d50_2d50_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.476449999999886,
                0.1693092307692723,
                null,
                null,
                null
              ],
              [
                -2.9476407692305884,
                -1.30188153846143,
                0.464599230769295,
                2.236339230769317,
                null
              ],
              [
                -4.91624076923074,
                -3.237671538461427,
                -1.5643615384614122,
                0.2729984615385774,
                2.105099230769383
              ],
              [
                -6.87958153846148,
                -4.878171538461402,
                -3.303291538461508,
                -1.4003115384614375,
                0.6339084615384536
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_584d50_2d50_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_584d50_2d50_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8182050000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1627100000002,
                585.9344500000001,
                null
              ],
              [
                578.8474900000002,
                580.4715850000002,
                582.1284900000002,
                583.9986600000002,
                585.8688300000001
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17801",
      "component_name": "run3",
      "save_point_id": 4997,
      "magnitude_ft": 581.5,
      "elevation_ft": 584.5,
      "runup_ft": 3.0,
      "baseline_ari": 1.3554,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17801_run3_4997",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                1.3553707021079415,
                null,
                null,
                null,
                null
              ],
              [
                6.614689039302702,
                1.284824295376844,
                null,
                null,
                null
              ],
              [
                30.999532234356117,
                5.47792574807611,
                1.155981946415259,
                1.0163418555464894,
                null
              ],
              [
                387.1700223925206,
                36.29324571038607,
                7.295135882462185,
                1.250720106427955,
                1.02763957660113
              ],
              [
                1000.5000833333622,
                296.6142710603745,
                35.70504932114278,
                5.485671548988741,
                1.1506951039215496
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_584d50_3d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_584d50_3d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                581.5000000000001,
                null,
                null,
                null,
                null
              ],
              [
                580.0069488461539,
                581.6474488461539,
                null,
                null,
                null
              ],
              [
                578.5138976923079,
                580.1709988461539,
                581.9427388461539,
                583.714478846154,
                null
              ],
              [
                576.5286965384616,
                578.2020065384617,
                579.8919176923077,
                581.7292776923078,
                583.5666376923078
              ],
              [
                574.5434953846155,
                576.5449053846155,
                578.1197853846155,
                580.0227653846155,
                582.0569853846155
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_584d50_3d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_584d50_3d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.4930511538461817,
                0.147448846153793,
                null,
                null,
                null
              ],
              [
                -2.9861023076922493,
                -1.3290011538462068,
                0.4427388461538157,
                2.2144788461538383,
                null
              ],
              [
                -4.971303461538469,
                -3.2979934615384536,
                -1.6080823076923707,
                0.2292776923077326,
                2.0666376923077223
              ],
              [
                -6.956504615384574,
                -4.95509461538461,
                -3.3802146153846024,
                -1.4772346153846456,
                0.5569853846153592
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_584d50_3d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_584d50_3d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8182050000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1627100000002,
                585.9344500000001,
                null
              ],
              [
                578.8474900000002,
                580.4715850000002,
                582.1284900000002,
                583.9986600000002,
                585.8688300000001
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17786",
      "component_name": "base",
      "save_point_id": 4997,
      "magnitude_ft": 584.0,
      "elevation_ft": 584.0,
      "runup_ft": 0.0,
      "baseline_ari": 24.128,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17786_base_4997",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                24.128032029646075,
                null,
                null,
                null,
                null
              ],
              [
                50.70586591124777,
                21.116302276332917,
                null,
                null,
                null
              ],
              [
                1000.5000833333622,
                46.92629973931165,
                10.549139272690889,
                1.4981216558913604,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                61.83936529138348,
                15.546381269068569,
                1.5662300621833565
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                46.40819245502311,
                8.701271391407191
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_584d00_0d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_584d00_0d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                584.0000000000001,
                null,
                null,
                null,
                null
              ],
              [
                582.5563600000002,
                584.1680140000001,
                null,
                null,
                null
              ],
              [
                581.1166840000001,
                582.75322,
                584.5249600000001,
                586.2967000000001,
                null
              ],
              [
                579.2097400000001,
                580.8213940000002,
                582.4907400000001,
                584.3609100000001,
                586.23108
              ],
              [
                577.2779140000001,
                579.2793240000001,
                580.8542040000001,
                582.757184,
                584.791404
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_584d00_0d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_584d00_0d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.4436399999999594,
                0.168013999999971,
                null,
                null,
                null
              ],
              [
                -2.883316000000036,
                -1.246780000000058,
                0.5249599999999646,
                2.296699999999987,
                null
              ],
              [
                -4.790259999999989,
                -3.178605999999945,
                -1.5092600000000402,
                0.3609099999999898,
                2.2310799999999062
              ],
              [
                -6.72208599999999,
                -4.720676000000026,
                -3.1457960000000185,
                -1.2428160000000616,
                0.7914039999999432
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_584d00_0d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_584d00_0d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8182050000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1627100000002,
                585.9344500000001,
                null
              ],
              [
                578.8474900000002,
                580.4715850000002,
                582.1284900000002,
                583.9986600000002,
                585.8688300000001
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17786",
      "component_name": "run2",
      "save_point_id": 4997,
      "magnitude_ft": 582.0,
      "elevation_ft": 584.0,
      "runup_ft": 2.0,
      "baseline_ari": 1.7312,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17786_run2_4997",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                1.7312407488633237,
                null,
                null,
                null,
                null
              ],
              [
                10.073214800271067,
                1.532488990247557,
                null,
                null,
                null
              ],
              [
                39.963179945672486,
                8.938025172137348,
                1.3834355825570457,
                1.0434905682635494,
                null
              ],
              [
                1000.5000833333622,
                45.25704779540806,
                11.591333359612012,
                1.4856455270204394,
                1.0587503214713525
              ],
              [
                1000.5000833333622,
                943.2385827562924,
                44.66883729937153,
                8.938025172137348,
                1.3305303988619317
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_584d00_2d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_584d00_2d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                582.0,
                null,
                null,
                null,
                null
              ],
              [
                580.5235500000001,
                582.1693092307693,
                null,
                null,
                null
              ],
              [
                579.0523592307694,
                580.6981184615386,
                582.4645992307693,
                584.2363392307693,
                null
              ],
              [
                577.0837592307693,
                578.7623284615386,
                580.4356384615386,
                582.2729984615386,
                584.1050992307694
              ],
              [
                575.1204184615385,
                577.1218284615386,
                578.6967084615385,
                580.5996884615386,
                582.6339084615385
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_584d00_2d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_584d00_2d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.476449999999886,
                0.1693092307692723,
                null,
                null,
                null
              ],
              [
                -2.9476407692305884,
                -1.30188153846143,
                0.464599230769295,
                2.236339230769317,
                null
              ],
              [
                -4.91624076923074,
                -3.237671538461427,
                -1.5643615384614122,
                0.2729984615385774,
                2.105099230769383
              ],
              [
                -6.87958153846148,
                -4.878171538461402,
                -3.303291538461508,
                -1.4003115384614375,
                0.6339084615384536
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_584d00_2d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_584d00_2d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8182050000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1627100000002,
                585.9344500000001,
                null
              ],
              [
                578.8474900000002,
                580.4715850000002,
                582.1284900000002,
                583.9986600000002,
                585.8688300000001
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17786",
      "component_name": "run25",
      "save_point_id": 4997,
      "magnitude_ft": 581.5,
      "elevation_ft": 584.0,
      "runup_ft": 2.5,
      "baseline_ari": 1.3554,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17786_run25_4997",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                1.3553707021079415,
                null,
                null,
                null,
                null
              ],
              [
                6.614689039302702,
                1.284824295376844,
                null,
                null,
                null
              ],
              [
                30.999532234356117,
                5.47792574807611,
                1.155981946415259,
                1.0163418555464894,
                null
              ],
              [
                387.1700223925206,
                36.29324571038607,
                7.295135882462185,
                1.250720106427955,
                1.02763957660113
              ],
              [
                1000.5000833333622,
                296.6142710603745,
                35.70504932114278,
                5.485671548988741,
                1.1506951039215496
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_584d00_2d50_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_584d00_2d50_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                581.5000000000001,
                null,
                null,
                null,
                null
              ],
              [
                580.0069488461539,
                581.6474488461539,
                null,
                null,
                null
              ],
              [
                578.5138976923079,
                580.1709988461539,
                581.9427388461539,
                583.714478846154,
                null
              ],
              [
                576.5286965384616,
                578.2020065384617,
                579.8919176923077,
                581.7292776923078,
                583.5666376923078
              ],
              [
                574.5434953846155,
                576.5449053846155,
                578.1197853846155,
                580.0227653846155,
                582.0569853846155
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_584d00_2d50_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_584d00_2d50_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.4930511538461817,
                0.147448846153793,
                null,
                null,
                null
              ],
              [
                -2.9861023076922493,
                -1.3290011538462068,
                0.4427388461538157,
                2.2144788461538383,
                null
              ],
              [
                -4.971303461538469,
                -3.2979934615384536,
                -1.6080823076923707,
                0.2292776923077326,
                2.0666376923077223
              ],
              [
                -6.956504615384574,
                -4.95509461538461,
                -3.3802146153846024,
                -1.4772346153846456,
                0.5569853846153592
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_584d00_2d50_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_584d00_2d50_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8182050000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1627100000002,
                585.9344500000001,
                null
              ],
              [
                578.8474900000002,
                580.4715850000002,
                582.1284900000002,
                583.9986600000002,
                585.8688300000001
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17786",
      "component_name": "run3",
      "save_point_id": 4997,
      "magnitude_ft": 581.0,
      "elevation_ft": 584.0,
      "runup_ft": 3.0,
      "baseline_ari": 1.1479,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17786_run3_4997",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                1.1479142800144286,
                null,
                null,
                null,
                null
              ],
              [
                3.3025564235593228,
                1.1342168548843787,
                null,
                null,
                null
              ],
              [
                22.03640130419018,
                2.320422960438825,
                1.1061707056404777,
                1.0057737912533184,
                null
              ],
              [
                107.22637260864352,
                27.329755269116745,
                3.6777254377908135,
                1.1295889874595535,
                1.0080996588001057
              ],
              [
                1000.5000833333622,
                88.52746298841126,
                26.741589611185685,
                2.5157294983892537,
                1.1114224287795926
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_584d00_3d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_584d00_3d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                581.0000000000001,
                null,
                null,
                null,
                null
              ],
              [
                579.4855020000001,
                581.1299305000001,
                null,
                null,
                null
              ],
              [
                577.9710040000002,
                579.6482425000002,
                581.4226015000002,
                583.1943415000001,
                null
              ],
              [
                575.9617370000001,
                577.6402850000001,
                579.3516430000001,
                581.1890030000002,
                583.0263630000002
              ],
              [
                573.9524700000002,
                575.9538800000001,
                577.5287600000001,
                579.4317400000002,
                581.4659600000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_584d00_3d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_584d00_3d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.5144980000000032,
                0.1299305000000004,
                null,
                null,
                null
              ],
              [
                -3.0289959999998928,
                -1.3517574999999624,
                0.4226015000000416,
                2.1943414999999504,
                null
              ],
              [
                -5.038263000000029,
                -3.359715000000051,
                -1.6483570000000327,
                0.1890030000000706,
                2.0263630000000603
              ],
              [
                -7.047529999999938,
                -5.0461199999999735,
                -3.471239999999966,
                -1.5682599999998956,
                0.4659600000001092
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_584d00_3d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_584d00_3d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8182050000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1627100000002,
                585.9344500000001,
                null
              ],
              [
                578.8474900000002,
                580.4715850000002,
                582.1284900000002,
                583.9986600000002,
                585.8688300000001
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17771",
      "component_name": "base",
      "save_point_id": 4997,
      "magnitude_ft": 583.5,
      "elevation_ft": 583.5,
      "runup_ft": 0.0,
      "baseline_ari": 10.4633,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17771_base_4997",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                10.46327532981882,
                null,
                null,
                null,
                null
              ],
              [
                41.38298934847683,
                9.327989779984494,
                null,
                null,
                null
              ],
              [
                467.8161296685657,
                37.783186181969846,
                7.0585405777560535,
                1.2537457313683718,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                42.5829312210852,
                8.293657451506158,
                1.3242961929004993
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                800.5991593199152,
                37.444364508669175,
                5.277809951727623
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_583d50_0d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_583d50_0d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.5000000000002,
                null,
                null,
                null,
                null
              ],
              [
                582.0563600000002,
                583.6640500000001,
                null,
                null,
                null
              ],
              [
                580.6127200000002,
                582.2204100000001,
                583.9921500000002,
                585.7638900000002,
                null
              ],
              [
                578.6769300000002,
                580.3174300000002,
                581.9579300000001,
                583.8278040909092,
                585.6979740909092
              ],
              [
                576.7411400000002,
                578.7425500000002,
                580.3174300000002,
                582.2204100000001,
                584.2546300000001
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_583d50_0d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_583d50_0d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.443640000000073,
                0.164049999999861,
                null,
                null,
                null
              ],
              [
                -2.8872800000000325,
                -1.2795900000000984,
                0.4921499999999241,
                2.2638899999999467,
                null
              ],
              [
                -4.82307000000003,
                -3.182570000000055,
                -1.5420700000000809,
                0.3278040909090123,
                2.1979740909089287
              ],
              [
                -6.758860000000027,
                -4.757450000000063,
                -3.182570000000055,
                -1.2795900000000984,
                0.7546299999999064
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_583d50_0d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_583d50_0d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8182050000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1627100000002,
                585.9344500000001,
                null
              ],
              [
                578.8474900000002,
                580.4715850000002,
                582.1284900000002,
                583.9986600000002,
                585.8688300000001
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17771",
      "component_name": "run2",
      "save_point_id": 4997,
      "magnitude_ft": 581.5,
      "elevation_ft": 583.5,
      "runup_ft": 2.0,
      "baseline_ari": 1.3554,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17771_run2_4997",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                1.3553707021079415,
                null,
                null,
                null,
                null
              ],
              [
                6.614689039302702,
                1.284824295376844,
                null,
                null,
                null
              ],
              [
                30.999532234356117,
                5.47792574807611,
                1.155981946415259,
                1.0163418555464894,
                null
              ],
              [
                387.1700223925206,
                36.29324571038607,
                7.295135882462185,
                1.250720106427955,
                1.02763957660113
              ],
              [
                1000.5000833333622,
                296.6142710603745,
                35.70504932114278,
                5.485671548988741,
                1.1506951039215496
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_583d50_2d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_583d50_2d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                581.5000000000001,
                null,
                null,
                null,
                null
              ],
              [
                580.0069488461539,
                581.6474488461539,
                null,
                null,
                null
              ],
              [
                578.5138976923079,
                580.1709988461539,
                581.9427388461539,
                583.714478846154,
                null
              ],
              [
                576.5286965384616,
                578.2020065384617,
                579.8919176923077,
                581.7292776923078,
                583.5666376923078
              ],
              [
                574.5434953846155,
                576.5449053846155,
                578.1197853846155,
                580.0227653846155,
                582.0569853846155
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_583d50_2d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_583d50_2d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.4930511538461817,
                0.147448846153793,
                null,
                null,
                null
              ],
              [
                -2.9861023076922493,
                -1.3290011538462068,
                0.4427388461538157,
                2.2144788461538383,
                null
              ],
              [
                -4.971303461538469,
                -3.2979934615384536,
                -1.6080823076923707,
                0.2292776923077326,
                2.0666376923077223
              ],
              [
                -6.956504615384574,
                -4.95509461538461,
                -3.3802146153846024,
                -1.4772346153846456,
                0.5569853846153592
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_583d50_2d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_583d50_2d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8182050000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1627100000002,
                585.9344500000001,
                null
              ],
              [
                578.8474900000002,
                580.4715850000002,
                582.1284900000002,
                583.9986600000002,
                585.8688300000001
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17771",
      "component_name": "run25",
      "save_point_id": 4997,
      "magnitude_ft": 581.0,
      "elevation_ft": 583.5,
      "runup_ft": 2.5,
      "baseline_ari": 1.1479,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17771_run25_4997",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                1.1479142800144286,
                null,
                null,
                null,
                null
              ],
              [
                3.3025564235593228,
                1.1342168548843787,
                null,
                null,
                null
              ],
              [
                22.03640130419018,
                2.320422960438825,
                1.1061707056404777,
                1.0057737912533184,
                null
              ],
              [
                107.22637260864352,
                27.329755269116745,
                3.6777254377908135,
                1.1295889874595535,
                1.0080996588001057
              ],
              [
                1000.5000833333622,
                88.52746298841126,
                26.741589611185685,
                2.5157294983892537,
                1.1114224287795926
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_583d50_2d50_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_583d50_2d50_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                581.0000000000001,
                null,
                null,
                null,
                null
              ],
              [
                579.4855020000001,
                581.1299305000001,
                null,
                null,
                null
              ],
              [
                577.9710040000002,
                579.6482425000002,
                581.4226015000002,
                583.1943415000001,
                null
              ],
              [
                575.9617370000001,
                577.6402850000001,
                579.3516430000001,
                581.1890030000002,
                583.0263630000002
              ],
              [
                573.9524700000002,
                575.9538800000001,
                577.5287600000001,
                579.4317400000002,
                581.4659600000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_583d50_2d50_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_583d50_2d50_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.5144980000000032,
                0.1299305000000004,
                null,
                null,
                null
              ],
              [
                -3.0289959999998928,
                -1.3517574999999624,
                0.4226015000000416,
                2.1943414999999504,
                null
              ],
              [
                -5.038263000000029,
                -3.359715000000051,
                -1.6483570000000327,
                0.1890030000000706,
                2.0263630000000603
              ],
              [
                -7.047529999999938,
                -5.0461199999999735,
                -3.471239999999966,
                -1.5682599999998956,
                0.4659600000001092
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_583d50_2d50_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_583d50_2d50_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8182050000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1627100000002,
                585.9344500000001,
                null
              ],
              [
                578.8474900000002,
                580.4715850000002,
                582.1284900000002,
                583.9986600000002,
                585.8688300000001
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17771",
      "component_name": "run3",
      "save_point_id": 4997,
      "magnitude_ft": 580.5,
      "elevation_ft": 583.5,
      "runup_ft": 3.0,
      "baseline_ari": 1.0967,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17771_run3_4997",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                1.0967278473278688,
                null,
                null,
                null,
                null
              ],
              [
                1.67948031529807,
                1.0855605224166684,
                null,
                null,
                null
              ],
              [
                9.683183319905636,
                1.5203842876853473,
                1.0631237741835975,
                1.003761424280798,
                null
              ],
              [
                47.72139295178177,
                16.46749467571396,
                1.8549794493781036,
                1.0849434576208363,
                1.0048178870677626
              ],
              [
                1000.5000833333622,
                46.01127048186564,
                15.871469766346411,
                1.5722574858671152,
                1.0761740971372562
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_583d50_3d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_583d50_3d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                580.5000000000001,
                null,
                null,
                null,
                null
              ],
              [
                578.9521686666668,
                580.6215971666668,
                null,
                null,
                null
              ],
              [
                577.4043373333335,
                579.1065758333334,
                580.8976015000002,
                582.6693415000001,
                null
              ],
              [
                575.3450703333334,
                577.0569516666668,
                578.8016430000001,
                580.6390030000001,
                582.4763630000001
              ],
              [
                573.2858033333334,
                575.2872133333334,
                576.8620933333334,
                578.7650733333334,
                580.7992933333334
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_583d50_3d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_583d50_3d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.5478313333333062,
                0.1215971666666746,
                null,
                null,
                null
              ],
              [
                -3.0956626666666125,
                -1.3934241666667049,
                0.3976015000000643,
                2.169341499999973,
                null
              ],
              [
                -5.154929666666703,
                -3.4430483333333086,
                -1.6983569999999872,
                0.1390030000000024,
                1.976362999999992
              ],
              [
                -7.21419666666668,
                -5.212786666666716,
                -3.6379066666667086,
                -1.7349266666667518,
                0.299293333333253
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_583d50_3d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_583d50_3d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8182050000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1627100000002,
                585.9344500000001,
                null
              ],
              [
                578.8474900000002,
                580.4715850000002,
                582.1284900000002,
                583.9986600000002,
                585.8688300000001
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17756",
      "component_name": "base",
      "save_point_id": 4997,
      "magnitude_ft": 583.0,
      "elevation_ft": 583.0,
      "runup_ft": 0.0,
      "baseline_ari": 7.0043,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17756_base_4997",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                7.004270656204618,
                null,
                null,
                null,
                null
              ],
              [
                32.240022805738874,
                5.870627198912554,
                null,
                null,
                null
              ],
              [
                140.0820254487798,
                28.64035873017482,
                3.5800933029902584,
                1.1282037655087171,
                null
              ],
              [
                1000.5000833333622,
                297.654695665757,
                33.43992714832558,
                4.909545769316608,
                1.145316953401041
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                239.55856254906053,
                28.48081881277908,
                2.4477193193060285
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_583d00_0d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_583d00_0d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.0,
                null,
                null,
                null,
                null
              ],
              [
                581.5563599999999,
                583.1640499999999,
                null,
                null,
                null
              ],
              [
                580.11272,
                581.7204099999999,
                583.4921499999999,
                585.26389,
                null
              ],
              [
                578.17693,
                579.81743,
                581.4579299999999,
                583.3050768181818,
                585.1752468181818
              ],
              [
                576.24114,
                578.2425499999999,
                579.81743,
                581.7204099999999,
                583.7546299999999
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_583d00_0d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_583d00_0d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.443640000000073,
                0.164049999999861,
                null,
                null,
                null
              ],
              [
                -2.8872800000000325,
                -1.2795900000000984,
                0.4921499999999241,
                2.2638899999999467,
                null
              ],
              [
                -4.82307000000003,
                -3.182570000000055,
                -1.5420700000000809,
                0.3050768181817602,
                2.1752468181817903
              ],
              [
                -6.758860000000027,
                -4.757450000000063,
                -3.182570000000055,
                -1.2795900000000984,
                0.7546299999999064
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_583d00_0d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_583d00_0d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8182050000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1627100000002,
                585.9344500000001,
                null
              ],
              [
                578.8474900000002,
                580.4715850000002,
                582.1284900000002,
                583.9986600000002,
                585.8688300000001
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17756",
      "component_name": "run2",
      "save_point_id": 4997,
      "magnitude_ft": 581.0,
      "elevation_ft": 583.0,
      "runup_ft": 2.0,
      "baseline_ari": 1.1479,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17756_run2_4997",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                1.1479142800144286,
                null,
                null,
                null,
                null
              ],
              [
                3.3025564235593228,
                1.1342168548843787,
                null,
                null,
                null
              ],
              [
                22.03640130419018,
                2.320422960438825,
                1.1061707056404777,
                1.0057737912533184,
                null
              ],
              [
                107.22637260864352,
                27.329755269116745,
                3.6777254377908135,
                1.1295889874595535,
                1.0080996588001057
              ],
              [
                1000.5000833333622,
                88.52746298841126,
                26.741589611185685,
                2.5157294983892537,
                1.1114224287795926
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_583d00_2d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_583d00_2d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                581.0000000000001,
                null,
                null,
                null,
                null
              ],
              [
                579.4855020000001,
                581.1299305000001,
                null,
                null,
                null
              ],
              [
                577.9710040000002,
                579.6482425000002,
                581.4226015000002,
                583.1943415000001,
                null
              ],
              [
                575.9617370000001,
                577.6402850000001,
                579.3516430000001,
                581.1890030000002,
                583.0263630000002
              ],
              [
                573.9524700000002,
                575.9538800000001,
                577.5287600000001,
                579.4317400000002,
                581.4659600000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_583d00_2d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_583d00_2d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.5144980000000032,
                0.1299305000000004,
                null,
                null,
                null
              ],
              [
                -3.0289959999998928,
                -1.3517574999999624,
                0.4226015000000416,
                2.1943414999999504,
                null
              ],
              [
                -5.038263000000029,
                -3.359715000000051,
                -1.6483570000000327,
                0.1890030000000706,
                2.0263630000000603
              ],
              [
                -7.047529999999938,
                -5.0461199999999735,
                -3.471239999999966,
                -1.5682599999998956,
                0.4659600000001092
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_583d00_2d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_583d00_2d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8182050000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1627100000002,
                585.9344500000001,
                null
              ],
              [
                578.8474900000002,
                580.4715850000002,
                582.1284900000002,
                583.9986600000002,
                585.8688300000001
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17756",
      "component_name": "run25",
      "save_point_id": 4997,
      "magnitude_ft": 580.5,
      "elevation_ft": 583.0,
      "runup_ft": 2.5,
      "baseline_ari": 1.0967,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17756_run25_4997",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                1.0967278473278688,
                null,
                null,
                null,
                null
              ],
              [
                1.67948031529807,
                1.0855605224166684,
                null,
                null,
                null
              ],
              [
                9.683183319905636,
                1.5203842876853473,
                1.0631237741835975,
                1.003761424280798,
                null
              ],
              [
                47.72139295178177,
                16.46749467571396,
                1.8549794493781036,
                1.0849434576208363,
                1.0048178870677626
              ],
              [
                1000.5000833333622,
                46.01127048186564,
                15.871469766346411,
                1.5722574858671152,
                1.0761740971372562
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_583d00_2d50_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_583d00_2d50_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                580.5000000000001,
                null,
                null,
                null,
                null
              ],
              [
                578.9521686666668,
                580.6215971666668,
                null,
                null,
                null
              ],
              [
                577.4043373333335,
                579.1065758333334,
                580.8976015000002,
                582.6693415000001,
                null
              ],
              [
                575.3450703333334,
                577.0569516666668,
                578.8016430000001,
                580.6390030000001,
                582.4763630000001
              ],
              [
                573.2858033333334,
                575.2872133333334,
                576.8620933333334,
                578.7650733333334,
                580.7992933333334
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_583d00_2d50_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_583d00_2d50_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.5478313333333062,
                0.1215971666666746,
                null,
                null,
                null
              ],
              [
                -3.0956626666666125,
                -1.3934241666667049,
                0.3976015000000643,
                2.169341499999973,
                null
              ],
              [
                -5.154929666666703,
                -3.4430483333333086,
                -1.6983569999999872,
                0.1390030000000024,
                1.976362999999992
              ],
              [
                -7.21419666666668,
                -5.212786666666716,
                -3.6379066666667086,
                -1.7349266666667518,
                0.299293333333253
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_583d00_2d50_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_583d00_2d50_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8182050000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1627100000002,
                585.9344500000001,
                null
              ],
              [
                578.8474900000002,
                580.4715850000002,
                582.1284900000002,
                583.9986600000002,
                585.8688300000001
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17756",
      "component_name": "run3",
      "save_point_id": 4997,
      "magnitude_ft": 580.0,
      "elevation_ft": 583.0,
      "runup_ft": 3.0,
      "baseline_ari": 1.0535,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17756_run3_4997",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                1.0535425842324728,
                null,
                null,
                null,
                null
              ],
              [
                1.3519879803671069,
                1.0453272471051946,
                null,
                null,
                null
              ],
              [
                6.225219435900785,
                1.2738257213782045,
                1.029522749854768,
                1.0022703125396928,
                null
              ],
              [
                38.57826294338258,
                8.266830047015304,
                1.4066874220651888,
                1.047518111926582,
                1.0030988366556703
              ],
              [
                945.9245014325082,
                37.04745120317822,
                8.266830047015304,
                1.345411751037138,
                1.0461795280928554
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_583d00_3d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_583d00_3d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                580.0000000000001,
                null,
                null,
                null,
                null
              ],
              [
                578.4188353333335,
                580.1132638333335,
                null,
                null,
                null
              ],
              [
                576.8376706666668,
                578.5649091666668,
                580.3726015000001,
                582.1443415000001,
                null
              ],
              [
                574.7284036666668,
                576.4736183333334,
                578.2516430000002,
                580.0890030000002,
                581.9263630000002
              ],
              [
                572.6191366666668,
                574.6205466666668,
                576.1954266666669,
                578.0984066666668,
                580.1326266666669
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_583d00_3d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_583d00_3d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.5811646666666093,
                0.1132638333333488,
                null,
                null,
                null
              ],
              [
                -3.162329333333332,
                -1.4350908333333336,
                0.3726014999999734,
                2.144341499999996,
                null
              ],
              [
                -5.271596333333264,
                -3.52638166666668,
                -1.7483569999999418,
                0.0890030000000479,
                1.9263630000000376
              ],
              [
                -7.380863333333309,
                -5.379453333333345,
                -3.804573333333224,
                -1.9015933333332669,
                0.1326266666667379
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_583d00_3d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_583d00_3d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8182050000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1627100000002,
                585.9344500000001,
                null
              ],
              [
                578.8474900000002,
                580.4715850000002,
                582.1284900000002,
                583.9986600000002,
                585.8688300000001
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17740",
      "component_name": "base",
      "save_point_id": 4997,
      "magnitude_ft": 582.5,
      "elevation_ft": 582.5,
      "runup_ft": 0.0,
      "baseline_ari": 3.5254,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17740_base_4997",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                3.5253803484545223,
                null,
                null,
                null,
                null
              ],
              [
                23.097531540428896,
                2.424332960614084,
                null,
                null,
                null
              ],
              [
                48.92705745828836,
                18.82762000835909,
                1.8039879581827296,
                1.081783308658708,
                null
              ],
              [
                1000.5000833333622,
                82.11638221741748,
                24.29734554389109,
                2.1726068539727352,
                1.0987833456191751
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                77.11644885167266,
                18.82762000835909,
                1.5563055239274124
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_582d50_0d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_582d50_0d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                582.5,
                null,
                null,
                null,
                null
              ],
              [
                581.0344607692307,
                582.6859492307692,
                null,
                null,
                null
              ],
              [
                579.5908207692307,
                581.2423092307691,
                582.9921499999999,
                584.76389,
                null
              ],
              [
                577.6331315384615,
                579.31743,
                580.9798292307693,
                582.8171892307693,
                584.6435607692307
              ],
              [
                575.6973415384614,
                577.6987515384614,
                579.2736315384615,
                581.1766115384614,
                583.2108315384614
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_582d50_0d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_582d50_0d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.4655392307693091,
                0.1859492307692107,
                null,
                null,
                null
              ],
              [
                -2.9091792307692685,
                -1.2576907692308623,
                0.4921499999999241,
                2.2638899999999467,
                null
              ],
              [
                -4.866868461538502,
                -3.182570000000055,
                -1.520170769230731,
                0.3171892307692587,
                2.143560769230703
              ],
              [
                -6.802658461538613,
                -4.801248461538648,
                -3.2263684615385277,
                -1.3233884615385705,
                0.7108315384614343
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_582d50_0d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_582d50_0d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8182050000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1627100000002,
                585.9344500000001,
                null
              ],
              [
                578.8474900000002,
                580.4715850000002,
                582.1284900000002,
                583.9986600000002,
                585.8688300000001
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17740",
      "component_name": "run2",
      "save_point_id": 4997,
      "magnitude_ft": 580.5,
      "elevation_ft": 582.5,
      "runup_ft": 2.0,
      "baseline_ari": 1.0967,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17740_run2_4997",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                1.0967278473278688,
                null,
                null,
                null,
                null
              ],
              [
                1.67948031529807,
                1.0855605224166684,
                null,
                null,
                null
              ],
              [
                9.683183319905636,
                1.5203842876853473,
                1.0631237741835975,
                1.003761424280798,
                null
              ],
              [
                47.72139295178177,
                16.46749467571396,
                1.8549794493781036,
                1.0849434576208363,
                1.0048178870677626
              ],
              [
                1000.5000833333622,
                46.01127048186564,
                15.871469766346411,
                1.5722574858671152,
                1.0761740971372562
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_582d50_2d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_582d50_2d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                580.5000000000001,
                null,
                null,
                null,
                null
              ],
              [
                578.9521686666668,
                580.6215971666668,
                null,
                null,
                null
              ],
              [
                577.4043373333335,
                579.1065758333334,
                580.8976015000002,
                582.6693415000001,
                null
              ],
              [
                575.3450703333334,
                577.0569516666668,
                578.8016430000001,
                580.6390030000001,
                582.4763630000001
              ],
              [
                573.2858033333334,
                575.2872133333334,
                576.8620933333334,
                578.7650733333334,
                580.7992933333334
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_582d50_2d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_582d50_2d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.5478313333333062,
                0.1215971666666746,
                null,
                null,
                null
              ],
              [
                -3.0956626666666125,
                -1.3934241666667049,
                0.3976015000000643,
                2.169341499999973,
                null
              ],
              [
                -5.154929666666703,
                -3.4430483333333086,
                -1.6983569999999872,
                0.1390030000000024,
                1.976362999999992
              ],
              [
                -7.21419666666668,
                -5.212786666666716,
                -3.6379066666667086,
                -1.7349266666667518,
                0.299293333333253
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_582d50_2d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_582d50_2d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8182050000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1627100000002,
                585.9344500000001,
                null
              ],
              [
                578.8474900000002,
                580.4715850000002,
                582.1284900000002,
                583.9986600000002,
                585.8688300000001
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17740",
      "component_name": "run25",
      "save_point_id": 4997,
      "magnitude_ft": 580.0,
      "elevation_ft": 582.5,
      "runup_ft": 2.5,
      "baseline_ari": 1.0535,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17740_run25_4997",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                1.0535425842324728,
                null,
                null,
                null,
                null
              ],
              [
                1.3519879803671069,
                1.0453272471051946,
                null,
                null,
                null
              ],
              [
                6.225219435900785,
                1.2738257213782045,
                1.029522749854768,
                1.0022703125396928,
                null
              ],
              [
                38.57826294338258,
                8.266830047015304,
                1.4066874220651888,
                1.047518111926582,
                1.0030988366556703
              ],
              [
                945.9245014325082,
                37.04745120317822,
                8.266830047015304,
                1.345411751037138,
                1.0461795280928554
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_582d50_2d50_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_582d50_2d50_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                580.0000000000001,
                null,
                null,
                null,
                null
              ],
              [
                578.4188353333335,
                580.1132638333335,
                null,
                null,
                null
              ],
              [
                576.8376706666668,
                578.5649091666668,
                580.3726015000001,
                582.1443415000001,
                null
              ],
              [
                574.7284036666668,
                576.4736183333334,
                578.2516430000002,
                580.0890030000002,
                581.9263630000002
              ],
              [
                572.6191366666668,
                574.6205466666668,
                576.1954266666669,
                578.0984066666668,
                580.1326266666669
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_582d50_2d50_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_582d50_2d50_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.5811646666666093,
                0.1132638333333488,
                null,
                null,
                null
              ],
              [
                -3.162329333333332,
                -1.4350908333333336,
                0.3726014999999734,
                2.144341499999996,
                null
              ],
              [
                -5.271596333333264,
                -3.52638166666668,
                -1.7483569999999418,
                0.0890030000000479,
                1.9263630000000376
              ],
              [
                -7.380863333333309,
                -5.379453333333345,
                -3.804573333333224,
                -1.9015933333332669,
                0.1326266666667379
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_582d50_2d50_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_582d50_2d50_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8182050000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1627100000002,
                585.9344500000001,
                null
              ],
              [
                578.8474900000002,
                580.4715850000002,
                582.1284900000002,
                583.9986600000002,
                585.8688300000001
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17740",
      "component_name": "run3",
      "save_point_id": 4997,
      "magnitude_ft": 579.5,
      "elevation_ft": 582.5,
      "runup_ft": 3.0,
      "baseline_ari": 1.0216,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17740_run3_4997",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                1.0216428888237494,
                null,
                null,
                null,
                null
              ],
              [
                1.149392971074503,
                1.016796338958725,
                null,
                null,
                null
              ],
              [
                2.9390297817581468,
                1.133262721625904,
                1.0084248615122589,
                1.0012408487828015,
                null
              ],
              [
                29.43540078088775,
                4.801183510294776,
                1.1814128698785666,
                1.0199053388012278,
                1.0018428477617327
              ],
              [
                297.6886376137681,
                28.083923870646924,
                4.896527032093121,
                1.1535049800994888,
                1.0229402907895715
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_582d50_3d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_582d50_3d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                579.4999999999999,
                null,
                null,
                null,
                null
              ],
              [
                577.8855019999999,
                579.6049304999999,
                null,
                null,
                null
              ],
              [
                576.271004,
                578.0232424999998,
                579.8476015,
                581.6193414999999,
                null
              ],
              [
                574.1117369999998,
                575.8902849999998,
                577.7016429999999,
                579.5390029999999,
                581.3763629999999
              ],
              [
                571.9524699999998,
                573.9538799999998,
                575.5287599999999,
                577.4317399999999,
                579.4659599999999
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_582d50_3d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_582d50_3d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.614498000000026,
                0.1049305000000231,
                null,
                null,
                null
              ],
              [
                -3.2289959999999382,
                -1.476757500000076,
                0.3476015000001098,
                2.119341500000018,
                null
              ],
              [
                -5.388263000000052,
                -3.609715000000051,
                -1.79835700000001,
                0.0390029999999796,
                1.8763629999999691
              ],
              [
                -7.547530000000052,
                -5.546120000000087,
                -3.971239999999966,
                -2.0682600000000093,
                -0.0340400000000045
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_582d50_3d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_582d50_3d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8182050000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1627100000002,
                585.9344500000001,
                null
              ],
              [
                578.8474900000002,
                580.4715850000002,
                582.1284900000002,
                583.9986600000002,
                585.8688300000001
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17725",
      "component_name": "base",
      "save_point_id": 4997,
      "magnitude_ft": 582.0,
      "elevation_ft": 582.0,
      "runup_ft": 0.0,
      "baseline_ari": 1.7312,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17725_base_4997",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                1.7312407488633237,
                null,
                null,
                null,
                null
              ],
              [
                10.073214800271067,
                1.532488990247557,
                null,
                null,
                null
              ],
              [
                39.963179945672486,
                8.938025172137348,
                1.3834355825570457,
                1.0434905682635494,
                null
              ],
              [
                1000.5000833333622,
                45.25704779540806,
                11.591333359612012,
                1.4856455270204394,
                1.0587503214713525
              ],
              [
                1000.5000833333622,
                943.2385827562924,
                44.66883729937153,
                8.938025172137348,
                1.3305303988619317
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_582d00_0d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_582d00_0d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                582.0,
                null,
                null,
                null,
                null
              ],
              [
                580.5235500000001,
                582.1693092307693,
                null,
                null,
                null
              ],
              [
                579.0523592307694,
                580.6981184615386,
                582.4645992307693,
                584.2363392307693,
                null
              ],
              [
                577.0837592307693,
                578.7623284615386,
                580.4356384615386,
                582.2729984615386,
                584.1050992307694
              ],
              [
                575.1204184615385,
                577.1218284615386,
                578.6967084615385,
                580.5996884615386,
                582.6339084615385
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_582d00_0d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_582d00_0d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.476449999999886,
                0.1693092307692723,
                null,
                null,
                null
              ],
              [
                -2.9476407692305884,
                -1.30188153846143,
                0.464599230769295,
                2.236339230769317,
                null
              ],
              [
                -4.91624076923074,
                -3.237671538461427,
                -1.5643615384614122,
                0.2729984615385774,
                2.105099230769383
              ],
              [
                -6.87958153846148,
                -4.878171538461402,
                -3.303291538461508,
                -1.4003115384614375,
                0.6339084615384536
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_582d00_0d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_582d00_0d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8182050000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1627100000002,
                585.9344500000001,
                null
              ],
              [
                578.8474900000002,
                580.4715850000002,
                582.1284900000002,
                583.9986600000002,
                585.8688300000001
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17725",
      "component_name": "run2",
      "save_point_id": 4997,
      "magnitude_ft": 580.0,
      "elevation_ft": 582.0,
      "runup_ft": 2.0,
      "baseline_ari": 1.0535,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17725_run2_4997",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                1.0535425842324728,
                null,
                null,
                null,
                null
              ],
              [
                1.3519879803671069,
                1.0453272471051946,
                null,
                null,
                null
              ],
              [
                6.225219435900785,
                1.2738257213782045,
                1.029522749854768,
                1.0022703125396928,
                null
              ],
              [
                38.57826294338258,
                8.266830047015304,
                1.4066874220651888,
                1.047518111926582,
                1.0030988366556703
              ],
              [
                945.9245014325082,
                37.04745120317822,
                8.266830047015304,
                1.345411751037138,
                1.0461795280928554
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_582d00_2d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_582d00_2d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                580.0000000000001,
                null,
                null,
                null,
                null
              ],
              [
                578.4188353333335,
                580.1132638333335,
                null,
                null,
                null
              ],
              [
                576.8376706666668,
                578.5649091666668,
                580.3726015000001,
                582.1443415000001,
                null
              ],
              [
                574.7284036666668,
                576.4736183333334,
                578.2516430000002,
                580.0890030000002,
                581.9263630000002
              ],
              [
                572.6191366666668,
                574.6205466666668,
                576.1954266666669,
                578.0984066666668,
                580.1326266666669
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_582d00_2d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_582d00_2d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.5811646666666093,
                0.1132638333333488,
                null,
                null,
                null
              ],
              [
                -3.162329333333332,
                -1.4350908333333336,
                0.3726014999999734,
                2.144341499999996,
                null
              ],
              [
                -5.271596333333264,
                -3.52638166666668,
                -1.7483569999999418,
                0.0890030000000479,
                1.9263630000000376
              ],
              [
                -7.380863333333309,
                -5.379453333333345,
                -3.804573333333224,
                -1.9015933333332669,
                0.1326266666667379
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_582d00_2d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_582d00_2d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8182050000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1627100000002,
                585.9344500000001,
                null
              ],
              [
                578.8474900000002,
                580.4715850000002,
                582.1284900000002,
                583.9986600000002,
                585.8688300000001
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17725",
      "component_name": "run25",
      "save_point_id": 4997,
      "magnitude_ft": 579.5,
      "elevation_ft": 582.0,
      "runup_ft": 2.5,
      "baseline_ari": 1.0216,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17725_run25_4997",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                1.0216428888237494,
                null,
                null,
                null,
                null
              ],
              [
                1.149392971074503,
                1.016796338958725,
                null,
                null,
                null
              ],
              [
                2.9390297817581468,
                1.133262721625904,
                1.0084248615122589,
                1.0012408487828015,
                null
              ],
              [
                29.43540078088775,
                4.801183510294776,
                1.1814128698785666,
                1.0199053388012278,
                1.0018428477617327
              ],
              [
                297.6886376137681,
                28.083923870646924,
                4.896527032093121,
                1.1535049800994888,
                1.0229402907895715
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_582d00_2d50_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_582d00_2d50_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                579.4999999999999,
                null,
                null,
                null,
                null
              ],
              [
                577.8855019999999,
                579.6049304999999,
                null,
                null,
                null
              ],
              [
                576.271004,
                578.0232424999998,
                579.8476015,
                581.6193414999999,
                null
              ],
              [
                574.1117369999998,
                575.8902849999998,
                577.7016429999999,
                579.5390029999999,
                581.3763629999999
              ],
              [
                571.9524699999998,
                573.9538799999998,
                575.5287599999999,
                577.4317399999999,
                579.4659599999999
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_582d00_2d50_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_582d00_2d50_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.614498000000026,
                0.1049305000000231,
                null,
                null,
                null
              ],
              [
                -3.2289959999999382,
                -1.476757500000076,
                0.3476015000001098,
                2.119341500000018,
                null
              ],
              [
                -5.388263000000052,
                -3.609715000000051,
                -1.79835700000001,
                0.0390029999999796,
                1.8763629999999691
              ],
              [
                -7.547530000000052,
                -5.546120000000087,
                -3.971239999999966,
                -2.0682600000000093,
                -0.0340400000000045
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_582d00_2d50_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_582d00_2d50_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8182050000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1627100000002,
                585.9344500000001,
                null
              ],
              [
                578.8474900000002,
                580.4715850000002,
                582.1284900000002,
                583.9986600000002,
                585.8688300000001
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17725",
      "component_name": "run3",
      "save_point_id": 4997,
      "magnitude_ft": 579.0,
      "elevation_ft": 582.0,
      "runup_ft": 3.0,
      "baseline_ari": 1.0062,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17725_run3_4997",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                1.006203442283098,
                null,
                null,
                null,
                null
              ],
              [
                1.101033616627462,
                1.0057417706202705,
                null,
                null,
                null
              ],
              [
                1.624764134695066,
                1.0875075472203748,
                1.004787461276928,
                1.0005942112100783,
                null
              ],
              [
                20.15251903472671,
                2.193621720980642,
                1.1144095950898651,
                1.0062616271182336,
                1.000989870258096
              ],
              [
                88.74233419732991,
                18.152999607386924,
                2.3232133599714206,
                1.1139940844426224,
                1.0078892982255854
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_582d00_3d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_582d00_3d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                579.0,
                null,
                null,
                null,
                null
              ],
              [
                577.3503358333332,
                579.0949934375,
                null,
                null,
                null
              ],
              [
                575.6995261458333,
                577.4792847916666,
                579.3200813541665,
                581.0918213541665,
                null
              ],
              [
                573.4898009374999,
                575.3035151041666,
                577.1511847916665,
                578.9873992708333,
                580.8247592708333
              ],
              [
                571.2789302083332,
                573.2803402083332,
                574.8552202083332,
                576.7582002083332,
                578.7924202083332
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_582d00_3d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_582d00_3d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.6496641666667529,
                0.0949934374999657,
                null,
                null,
                null
              ],
              [
                -3.3004738541667398,
                -1.5207152083333997,
                0.3200813541665184,
                2.091821354166541,
                null
              ],
              [
                -5.510199062500078,
                -3.6964848958333514,
                -1.8488152083334624,
                -0.0126007291667065,
                1.8247592708332832
              ],
              [
                -7.721069791666764,
                -5.7196597916668,
                -4.144779791666792,
                -2.2417997916668355,
                -0.2075797916668307
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4997_582d00_3d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4997_582d00_3d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8182050000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1627100000002,
                585.9344500000001,
                null
              ],
              [
                578.8474900000002,
                580.4715850000002,
                582.1284900000002,
                583.9986600000002,
                585.8688300000001
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4997_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17877",
      "component_name": "base",
      "save_point_id": 4999,
      "magnitude_ft": 587.0,
      "elevation_ft": 587.0,
      "runup_ft": 0.0,
      "baseline_ari": 1000.5001,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17877_base_4999",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                1000.5000833333622,
                null,
                null,
                null,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                null,
                null,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                956.8650165263784,
                36.98811145488898,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                38.18803873018834
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                262.4097969932772
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_587d00_0d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_587d00_0d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                586.55784,
                null,
                null,
                null,
                null
              ],
              [
                585.1798200000002,
                586.7547000000001,
                null,
                null,
                null
              ],
              [
                583.8018000000002,
                585.3438700000002,
                587.0171800000002,
                588.7889200000001,
                null
              ],
              [
                581.9316300000002,
                583.4737000000001,
                585.0157700000001,
                586.7875100000001,
                588.5920600000001
              ],
              [
                580.09427,
                582.0956800000001,
                583.6705600000001,
                585.5735400000001,
                587.6077600000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_587d00_0d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_587d00_0d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                -0.4421599999998307,
                null,
                null,
                null,
                null
              ],
              [
                -1.8201799999997093,
                -0.2452999999998155,
                null,
                null,
                null
              ],
              [
                -3.198199999999701,
                -1.6561299999997343,
                0.0171800000002804,
                1.7889200000001892,
                null
              ],
              [
                -5.068369999999732,
                -3.5262999999997646,
                -1.9842299999997977,
                -0.2124899999997751,
                1.592060000000174
              ],
              [
                -6.905729999999835,
                -4.904319999999757,
                -3.329439999999749,
                -1.426459999999793,
                0.6077600000003258
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_587d00_0d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_587d00_0d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1791150000003,
                585.950855,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1284900000002,
                584.0150650000002,
                585.8852350000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17877",
      "component_name": "run2",
      "save_point_id": 4999,
      "magnitude_ft": 585.0,
      "elevation_ft": 587.0,
      "runup_ft": 2.0,
      "baseline_ari": 41.984,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17877_run2_4999",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                41.983981741510334,
                null,
                null,
                null,
                null
              ],
              [
                657.9597427211031,
                38.81378743417575,
                null,
                null,
                null
              ],
              [
                1000.5000833333622,
                396.08082632666645,
                32.814191324300545,
                5.176187871354827,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                966.1682188338898,
                35.513764766706764,
                5.629191264046476
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                288.4841357562431,
                27.725765248874385
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_587d00_2d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_587d00_2d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                585.0,
                null,
                null,
                null,
                null
              ],
              [
                583.55636,
                585.173365882353,
                null,
                null,
                null
              ],
              [
                582.1362141176471,
                583.75322,
                585.5014658823529,
                587.273205882353,
                null
              ],
              [
                580.20974,
                581.85024,
                583.49074,
                585.36091,
                587.2075858823529
              ],
              [
                578.2974441176472,
                580.2988541176471,
                581.8737341176471,
                583.7767141176471,
                585.8109341176471
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_587d00_2d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_587d00_2d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.4436399999999594,
                0.1733658823529822,
                null,
                null,
                null
              ],
              [
                -2.863785882352886,
                -1.2467799999999445,
                0.5014658823529317,
                2.273205882352954,
                null
              ],
              [
                -4.790259999999989,
                -3.1497600000000148,
                -1.5092600000000402,
                0.3609099999999898,
                2.2075858823528733
              ],
              [
                -6.70255588235284,
                -4.701145882352876,
                -3.126265882352868,
                -1.2232858823529114,
                0.8109341176470934
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_587d00_2d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_587d00_2d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1791150000003,
                585.950855,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1284900000002,
                584.0150650000002,
                585.8852350000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17877",
      "component_name": "run25",
      "save_point_id": 4999,
      "magnitude_ft": 584.5,
      "elevation_ft": 587.0,
      "runup_ft": 2.5,
      "baseline_ari": 33.0203,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17877_run25_4999",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                33.0202670962731,
                null,
                null,
                null,
                null
              ],
              [
                159.168275553235,
                29.67091546929427,
                null,
                null,
                null
              ],
              [
                1000.5000833333622,
                96.50140988929604,
                23.67165531326204,
                2.28207884322574,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                209.83698245749267,
                26.55031544675762,
                2.5963919900858308
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                86.90145215477288,
                17.78491976573462
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_587d00_2d50_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_587d00_2d50_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                584.5000000000001,
                null,
                null,
                null,
                null
              ],
              [
                583.05636,
                584.6831698039216,
                null,
                null,
                null
              ],
              [
                581.6264101960785,
                583.2532199999999,
                585.0112698039216,
                586.7830098039216,
                null
              ],
              [
                579.70974,
                581.3502400000001,
                582.9907400000001,
                584.86091,
                586.7173898039215
              ],
              [
                577.7876401960785,
                579.7890501960785,
                581.3639301960785,
                583.2669101960785,
                585.3011301960785
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_587d00_2d50_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_587d00_2d50_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.443640000000073,
                0.183169803921487,
                null,
                null,
                null
              ],
              [
                -2.873589803921618,
                -1.2467800000001716,
                0.5112698039214365,
                2.283009803921459,
                null
              ],
              [
                -4.790260000000103,
                -3.1497600000000148,
                -1.5092600000000402,
                0.3609099999998761,
                2.217389803921378
              ],
              [
                -6.712359803921572,
                -4.710949803921608,
                -3.1360698039216004,
                -1.2330898039216436,
                0.8011301960783612
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_587d00_2d50_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_587d00_2d50_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1791150000003,
                585.950855,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1284900000002,
                584.0150650000002,
                585.8852350000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17877",
      "component_name": "run3",
      "save_point_id": 4999,
      "magnitude_ft": 584.0,
      "elevation_ft": 587.0,
      "runup_ft": 3.0,
      "baseline_ari": 24.057,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17877_run3_4999",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                24.056973952005094,
                null,
                null,
                null,
                null
              ],
              [
                49.93747462211457,
                20.528666118967458,
                null,
                null,
                null
              ],
              [
                1000.5000833333622,
                46.40819245502311,
                10.2999965340185,
                1.4981216558913604,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                57.006732324753855,
                14.995574269525928,
                1.5667722890280522
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                45.91001280997219,
                8.701271391407191
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_587d00_3d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_587d00_3d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                584.0000000000001,
                null,
                null,
                null,
                null
              ],
              [
                582.5563600000002,
                584.1929737254903,
                null,
                null,
                null
              ],
              [
                581.1166062745099,
                582.75322,
                584.5210737254903,
                586.2928137254903,
                null
              ],
              [
                579.2097400000001,
                580.8502400000001,
                582.4907400000001,
                584.3609100000001,
                586.2271937254902
              ],
              [
                577.2778362745099,
                579.2792462745099,
                580.8541262745099,
                582.7571062745099,
                584.7913262745099
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_587d00_3d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_587d00_3d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.4436399999999594,
                0.1929737254902193,
                null,
                null,
                null
              ],
              [
                -2.8833937254902366,
                -1.246780000000058,
                0.5210737254901687,
                2.2928137254901912,
                null
              ],
              [
                -4.790259999999989,
                -3.1497600000000148,
                -1.5092600000000402,
                0.3609099999999898,
                2.2271937254901104
              ],
              [
                -6.722163725490191,
                -4.720753725490226,
                -3.145873725490219,
                -1.242893725490262,
                0.7913262745097427
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_587d00_3d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_587d00_3d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1791150000003,
                585.950855,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1284900000002,
                584.0150650000002,
                585.8852350000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17862",
      "component_name": "base",
      "save_point_id": 4999,
      "magnitude_ft": 586.5,
      "elevation_ft": 586.5,
      "runup_ft": 0.0,
      "baseline_ari": 874.5803,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17862_base_4999",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                874.5802973670694,
                null,
                null,
                null,
                null
              ],
              [
                1000.5000833333622,
                477.6138595134185,
                null,
                null,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                190.9644728827347,
                27.84532141269581,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                375.0709834235708,
                29.045193283245226
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                81.6866405938406
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_586d50_0d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_586d50_0d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                586.5,
                null,
                null,
                null,
                null
              ],
              [
                585.1137171428571,
                586.69686,
                null,
                null,
                null
              ],
              [
                583.7356971428571,
                585.2860300000001,
                586.9676028571429,
                588.7393428571428,
                null
              ],
              [
                581.8655271428571,
                583.41586,
                584.9579299999999,
                586.7461957142858,
                588.5507457142858
              ],
              [
                580.0199042857142,
                582.0213142857143,
                583.5961942857142,
                585.4991742857143,
                587.5333942857143
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_586d50_0d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_586d50_0d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.3862828571428736,
                0.1968600000000151,
                null,
                null,
                null
              ],
              [
                -2.764302857142866,
                -1.2139699999999038,
                0.4676028571428787,
                2.239342857142788,
                null
              ],
              [
                -4.634472857142896,
                -3.084140000000048,
                -1.5420700000000809,
                0.2461957142858182,
                2.0507457142857675
              ],
              [
                -6.480095714285767,
                -4.478685714285689,
                -2.903805714285795,
                -1.0008257142857246,
                1.0333942857142802
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_586d50_0d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_586d50_0d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1791150000003,
                585.950855,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1284900000002,
                584.0150650000002,
                585.8852350000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17862",
      "component_name": "run2",
      "save_point_id": 4999,
      "magnitude_ft": 584.5,
      "elevation_ft": 586.5,
      "runup_ft": 2.0,
      "baseline_ari": 33.0203,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17862_run2_4999",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                33.0202670962731,
                null,
                null,
                null,
                null
              ],
              [
                159.168275553235,
                29.67091546929427,
                null,
                null,
                null
              ],
              [
                1000.5000833333622,
                96.50140988929604,
                23.67165531326204,
                2.28207884322574,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                209.83698245749267,
                26.55031544675762,
                2.5963919900858308
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                86.90145215477288,
                17.78491976573462
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_586d50_2d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_586d50_2d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                584.5000000000001,
                null,
                null,
                null,
                null
              ],
              [
                583.05636,
                584.6831698039216,
                null,
                null,
                null
              ],
              [
                581.6264101960785,
                583.2532199999999,
                585.0112698039216,
                586.7830098039216,
                null
              ],
              [
                579.70974,
                581.3502400000001,
                582.9907400000001,
                584.86091,
                586.7173898039215
              ],
              [
                577.7876401960785,
                579.7890501960785,
                581.3639301960785,
                583.2669101960785,
                585.3011301960785
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_586d50_2d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_586d50_2d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.443640000000073,
                0.183169803921487,
                null,
                null,
                null
              ],
              [
                -2.873589803921618,
                -1.2467800000001716,
                0.5112698039214365,
                2.283009803921459,
                null
              ],
              [
                -4.790260000000103,
                -3.1497600000000148,
                -1.5092600000000402,
                0.3609099999998761,
                2.217389803921378
              ],
              [
                -6.712359803921572,
                -4.710949803921608,
                -3.1360698039216004,
                -1.2330898039216436,
                0.8011301960783612
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_586d50_2d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_586d50_2d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1791150000003,
                585.950855,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1284900000002,
                584.0150650000002,
                585.8852350000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17862",
      "component_name": "run25",
      "save_point_id": 4999,
      "magnitude_ft": 584.0,
      "elevation_ft": 586.5,
      "runup_ft": 2.5,
      "baseline_ari": 24.057,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17862_run25_4999",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                24.056973952005094,
                null,
                null,
                null,
                null
              ],
              [
                49.93747462211457,
                20.528666118967458,
                null,
                null,
                null
              ],
              [
                1000.5000833333622,
                46.40819245502311,
                10.2999965340185,
                1.4981216558913604,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                57.006732324753855,
                14.995574269525928,
                1.5667722890280522
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                45.91001280997219,
                8.701271391407191
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_586d50_2d50_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_586d50_2d50_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                584.0000000000001,
                null,
                null,
                null,
                null
              ],
              [
                582.5563600000002,
                584.1929737254903,
                null,
                null,
                null
              ],
              [
                581.1166062745099,
                582.75322,
                584.5210737254903,
                586.2928137254903,
                null
              ],
              [
                579.2097400000001,
                580.8502400000001,
                582.4907400000001,
                584.3609100000001,
                586.2271937254902
              ],
              [
                577.2778362745099,
                579.2792462745099,
                580.8541262745099,
                582.7571062745099,
                584.7913262745099
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_586d50_2d50_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_586d50_2d50_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.4436399999999594,
                0.1929737254902193,
                null,
                null,
                null
              ],
              [
                -2.8833937254902366,
                -1.246780000000058,
                0.5210737254901687,
                2.2928137254901912,
                null
              ],
              [
                -4.790259999999989,
                -3.1497600000000148,
                -1.5092600000000402,
                0.3609099999999898,
                2.2271937254901104
              ],
              [
                -6.722163725490191,
                -4.720753725490226,
                -3.145873725490219,
                -1.242893725490262,
                0.7913262745097427
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_586d50_2d50_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_586d50_2d50_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1791150000003,
                585.950855,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1284900000002,
                584.0150650000002,
                585.8852350000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17862",
      "component_name": "run3",
      "save_point_id": 4999,
      "magnitude_ft": 583.5,
      "elevation_ft": 586.5,
      "runup_ft": 3.0,
      "baseline_ari": 10.4633,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17862_run3_4999",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                10.46327532981882,
                null,
                null,
                null,
                null
              ],
              [
                40.97357955935377,
                9.327989779984494,
                null,
                null,
                null
              ],
              [
                467.8161296685657,
                37.444364508669175,
                6.991463155076583,
                1.2537457313683718,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                42.149991985050015,
                8.076573549041086,
                1.332794838112259
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                711.6992773207871,
                37.118574796006754,
                5.277809951727623
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_586d50_3d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_586d50_3d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.5000000000002,
                null,
                null,
                null,
                null
              ],
              [
                582.0563600000002,
                583.6640500000001,
                null,
                null,
                null
              ],
              [
                580.6127200000002,
                582.2204100000001,
                584.0246640909093,
                585.7964040909092,
                null
              ],
              [
                578.6769300000002,
                580.3174300000002,
                581.9579300000001,
                583.8606140909092,
                585.7307840909092
              ],
              [
                576.7411400000002,
                578.7425500000002,
                580.3174300000002,
                582.2204100000001,
                584.2546300000001
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_586d50_3d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_586d50_3d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.443640000000073,
                0.164049999999861,
                null,
                null,
                null
              ],
              [
                -2.8872800000000325,
                -1.2795900000000984,
                0.5246640909090274,
                2.2964040909089363,
                null
              ],
              [
                -4.82307000000003,
                -3.182570000000055,
                -1.5420700000000809,
                0.360614090908939,
                2.230784090908969
              ],
              [
                -6.758860000000027,
                -4.757450000000063,
                -3.182570000000055,
                -1.2795900000000984,
                0.7546299999999064
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_586d50_3d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_586d50_3d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1791150000003,
                585.950855,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1284900000002,
                584.0150650000002,
                585.8852350000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17847",
      "component_name": "base",
      "save_point_id": 4999,
      "magnitude_ft": 586.0,
      "elevation_ft": 586.0,
      "runup_ft": 0.0,
      "baseline_ari": 187.9738,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17847_base_4999",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                187.9737758088555,
                null,
                null,
                null,
                null
              ],
              [
                1000.5000833333622,
                125.47399810961852,
                null,
                null,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                56.04520311260036,
                17.169296526843304,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                81.73769145748334,
                19.390930450203456
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                45.30832128004341
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_586d00_0d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_586d00_0d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                586.0,
                null,
                null,
                null,
                null
              ],
              [
                584.58506,
                586.1640500000001,
                null,
                null,
                null
              ],
              [
                583.1455300000001,
                584.75322,
                586.49215,
                588.2638900000001,
                null
              ],
              [
                581.27125,
                582.8502400000001,
                584.45793,
                586.2994,
                588.13676
              ],
              [
                579.36827,
                581.36968,
                582.94456,
                584.84754,
                586.88176
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_586d00_0d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_586d00_0d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.4149400000000014,
                0.1640500000000884,
                null,
                null,
                null
              ],
              [
                -2.8544699999998784,
                -1.2467799999999445,
                0.4921500000000378,
                2.2638900000000604,
                null
              ],
              [
                -4.728749999999991,
                -3.149759999999901,
                -1.542069999999967,
                0.2993999999999914,
                2.136759999999981
              ],
              [
                -6.631729999999948,
                -4.630319999999983,
                -3.055439999999976,
                -1.1524600000000191,
                0.8817599999999857
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_586d00_0d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_586d00_0d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1791150000003,
                585.950855,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1284900000002,
                584.0150650000002,
                585.8852350000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17847",
      "component_name": "run2",
      "save_point_id": 4999,
      "magnitude_ft": 584.0,
      "elevation_ft": 586.0,
      "runup_ft": 2.0,
      "baseline_ari": 24.057,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17847_run2_4999",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                24.056973952005094,
                null,
                null,
                null,
                null
              ],
              [
                49.93747462211457,
                20.528666118967458,
                null,
                null,
                null
              ],
              [
                1000.5000833333622,
                46.40819245502311,
                10.2999965340185,
                1.4981216558913604,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                57.006732324753855,
                14.995574269525928,
                1.5667722890280522
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                45.91001280997219,
                8.701271391407191
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_586d00_2d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_586d00_2d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                584.0000000000001,
                null,
                null,
                null,
                null
              ],
              [
                582.5563600000002,
                584.1929737254903,
                null,
                null,
                null
              ],
              [
                581.1166062745099,
                582.75322,
                584.5210737254903,
                586.2928137254903,
                null
              ],
              [
                579.2097400000001,
                580.8502400000001,
                582.4907400000001,
                584.3609100000001,
                586.2271937254902
              ],
              [
                577.2778362745099,
                579.2792462745099,
                580.8541262745099,
                582.7571062745099,
                584.7913262745099
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_586d00_2d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_586d00_2d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.4436399999999594,
                0.1929737254902193,
                null,
                null,
                null
              ],
              [
                -2.8833937254902366,
                -1.246780000000058,
                0.5210737254901687,
                2.2928137254901912,
                null
              ],
              [
                -4.790259999999989,
                -3.1497600000000148,
                -1.5092600000000402,
                0.3609099999999898,
                2.2271937254901104
              ],
              [
                -6.722163725490191,
                -4.720753725490226,
                -3.145873725490219,
                -1.242893725490262,
                0.7913262745097427
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_586d00_2d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_586d00_2d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1791150000003,
                585.950855,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1284900000002,
                584.0150650000002,
                585.8852350000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17847",
      "component_name": "run25",
      "save_point_id": 4999,
      "magnitude_ft": 583.5,
      "elevation_ft": 586.0,
      "runup_ft": 2.5,
      "baseline_ari": 10.4633,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17847_run25_4999",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                10.46327532981882,
                null,
                null,
                null,
                null
              ],
              [
                40.97357955935377,
                9.327989779984494,
                null,
                null,
                null
              ],
              [
                467.8161296685657,
                37.444364508669175,
                6.991463155076583,
                1.2537457313683718,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                42.149991985050015,
                8.076573549041086,
                1.332794838112259
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                711.6992773207871,
                37.118574796006754,
                5.277809951727623
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_586d00_2d50_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_586d00_2d50_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.5000000000002,
                null,
                null,
                null,
                null
              ],
              [
                582.0563600000002,
                583.6640500000001,
                null,
                null,
                null
              ],
              [
                580.6127200000002,
                582.2204100000001,
                584.0246640909093,
                585.7964040909092,
                null
              ],
              [
                578.6769300000002,
                580.3174300000002,
                581.9579300000001,
                583.8606140909092,
                585.7307840909092
              ],
              [
                576.7411400000002,
                578.7425500000002,
                580.3174300000002,
                582.2204100000001,
                584.2546300000001
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_586d00_2d50_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_586d00_2d50_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.443640000000073,
                0.164049999999861,
                null,
                null,
                null
              ],
              [
                -2.8872800000000325,
                -1.2795900000000984,
                0.5246640909090274,
                2.2964040909089363,
                null
              ],
              [
                -4.82307000000003,
                -3.182570000000055,
                -1.5420700000000809,
                0.360614090908939,
                2.230784090908969
              ],
              [
                -6.758860000000027,
                -4.757450000000063,
                -3.182570000000055,
                -1.2795900000000984,
                0.7546299999999064
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_586d00_2d50_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_586d00_2d50_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1791150000003,
                585.950855,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1284900000002,
                584.0150650000002,
                585.8852350000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17847",
      "component_name": "run3",
      "save_point_id": 4999,
      "magnitude_ft": 583.0,
      "elevation_ft": 586.0,
      "runup_ft": 3.0,
      "baseline_ari": 7.0043,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17847_run3_4999",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                7.004270656204618,
                null,
                null,
                null,
                null
              ],
              [
                32.009896942472764,
                5.870627198912554,
                null,
                null,
                null
              ],
              [
                132.52973815285142,
                28.48081881277908,
                3.5800933029902584,
                1.1282037655087171,
                null
              ],
              [
                1000.5000833333622,
                297.654695665757,
                33.18627233076584,
                4.726482283795404,
                1.1484297420032183
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                214.55860326104963,
                28.3274152287085,
                2.4477193193060285
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_586d00_3d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_586d00_3d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.0,
                null,
                null,
                null,
                null
              ],
              [
                581.5563599999999,
                583.1640499999999,
                null,
                null,
                null
              ],
              [
                580.11272,
                581.7204099999999,
                583.5019368181817,
                585.2736768181818,
                null
              ],
              [
                578.17693,
                579.81743,
                581.4579299999999,
                583.3378868181817,
                585.2080568181817
              ],
              [
                576.24114,
                578.2425499999999,
                579.81743,
                581.7204099999999,
                583.7546299999999
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_586d00_3d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_586d00_3d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.443640000000073,
                0.164049999999861,
                null,
                null,
                null
              ],
              [
                -2.8872800000000325,
                -1.2795900000000984,
                0.5019368181816617,
                2.273676818181798,
                null
              ],
              [
                -4.82307000000003,
                -3.182570000000055,
                -1.5420700000000809,
                0.337886818181687,
                2.208056818181717
              ],
              [
                -6.758860000000027,
                -4.757450000000063,
                -3.182570000000055,
                -1.2795900000000984,
                0.7546299999999064
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_586d00_3d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_586d00_3d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1791150000003,
                585.950855,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1284900000002,
                584.0150650000002,
                585.8852350000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17832",
      "component_name": "base",
      "save_point_id": 4999,
      "magnitude_ft": 585.5,
      "elevation_ft": 585.5,
      "runup_ft": 0.0,
      "baseline_ari": 54.716,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17832_base_4999",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                54.71603809441864,
                null,
                null,
                null,
                null
              ],
              [
                1000.5000833333622,
                47.95692213833989,
                null,
                null,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                41.95717629221885,
                8.501427887898926,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                44.47754801858904,
                8.935672776133856
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                875.9784385094621,
                36.51689664383365
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_585d50_0d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_585d50_0d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                585.5000000000001,
                null,
                null,
                null,
                null
              ],
              [
                584.05636,
                585.6640500000001,
                null,
                null,
                null
              ],
              [
                582.64553,
                584.25322,
                585.99215,
                587.7638900000001,
                null
              ],
              [
                580.7125055555556,
                582.3502400000001,
                583.9879744444445,
                585.8581444444444,
                587.6955044444444
              ],
              [
                578.8095255555556,
                580.8109355555556,
                582.3858155555557,
                584.2887955555557,
                586.3230155555557
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_585d50_0d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_585d50_0d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.443640000000073,
                0.1640499999999747,
                null,
                null,
                null
              ],
              [
                -2.8544700000001058,
                -1.246780000000058,
                0.4921499999999241,
                2.2638899999999467,
                null
              ],
              [
                -4.787494444444519,
                -3.1497600000000148,
                -1.512025555555624,
                0.3581444444442923,
                2.195504444444282
              ],
              [
                -6.690474444444476,
                -4.689064444444512,
                -3.1141844444443905,
                -1.2112044444444336,
                0.8230155555555712
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_585d50_0d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_585d50_0d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1791150000003,
                585.950855,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1284900000002,
                584.0150650000002,
                585.8852350000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17832",
      "component_name": "run2",
      "save_point_id": 4999,
      "magnitude_ft": 583.5,
      "elevation_ft": 585.5,
      "runup_ft": 2.0,
      "baseline_ari": 10.4633,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17832_run2_4999",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                10.46327532981882,
                null,
                null,
                null,
                null
              ],
              [
                40.97357955935377,
                9.327989779984494,
                null,
                null,
                null
              ],
              [
                467.8161296685657,
                37.444364508669175,
                6.991463155076583,
                1.2537457313683718,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                42.149991985050015,
                8.076573549041086,
                1.332794838112259
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                711.6992773207871,
                37.118574796006754,
                5.277809951727623
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_585d50_2d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_585d50_2d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.5000000000002,
                null,
                null,
                null,
                null
              ],
              [
                582.0563600000002,
                583.6640500000001,
                null,
                null,
                null
              ],
              [
                580.6127200000002,
                582.2204100000001,
                584.0246640909093,
                585.7964040909092,
                null
              ],
              [
                578.6769300000002,
                580.3174300000002,
                581.9579300000001,
                583.8606140909092,
                585.7307840909092
              ],
              [
                576.7411400000002,
                578.7425500000002,
                580.3174300000002,
                582.2204100000001,
                584.2546300000001
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_585d50_2d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_585d50_2d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.443640000000073,
                0.164049999999861,
                null,
                null,
                null
              ],
              [
                -2.8872800000000325,
                -1.2795900000000984,
                0.5246640909090274,
                2.2964040909089363,
                null
              ],
              [
                -4.82307000000003,
                -3.182570000000055,
                -1.5420700000000809,
                0.360614090908939,
                2.230784090908969
              ],
              [
                -6.758860000000027,
                -4.757450000000063,
                -3.182570000000055,
                -1.2795900000000984,
                0.7546299999999064
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_585d50_2d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_585d50_2d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1791150000003,
                585.950855,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1284900000002,
                584.0150650000002,
                585.8852350000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17832",
      "component_name": "run25",
      "save_point_id": 4999,
      "magnitude_ft": 583.0,
      "elevation_ft": 585.5,
      "runup_ft": 2.5,
      "baseline_ari": 7.0043,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17832_run25_4999",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                7.004270656204618,
                null,
                null,
                null,
                null
              ],
              [
                32.009896942472764,
                5.870627198912554,
                null,
                null,
                null
              ],
              [
                132.52973815285142,
                28.48081881277908,
                3.5800933029902584,
                1.1282037655087171,
                null
              ],
              [
                1000.5000833333622,
                297.654695665757,
                33.18627233076584,
                4.726482283795404,
                1.1484297420032183
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                214.55860326104963,
                28.3274152287085,
                2.4477193193060285
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_585d50_2d50_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_585d50_2d50_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.0,
                null,
                null,
                null,
                null
              ],
              [
                581.5563599999999,
                583.1640499999999,
                null,
                null,
                null
              ],
              [
                580.11272,
                581.7204099999999,
                583.5019368181817,
                585.2736768181818,
                null
              ],
              [
                578.17693,
                579.81743,
                581.4579299999999,
                583.3378868181817,
                585.2080568181817
              ],
              [
                576.24114,
                578.2425499999999,
                579.81743,
                581.7204099999999,
                583.7546299999999
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_585d50_2d50_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_585d50_2d50_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.443640000000073,
                0.164049999999861,
                null,
                null,
                null
              ],
              [
                -2.8872800000000325,
                -1.2795900000000984,
                0.5019368181816617,
                2.273676818181798,
                null
              ],
              [
                -4.82307000000003,
                -3.182570000000055,
                -1.5420700000000809,
                0.337886818181687,
                2.208056818181717
              ],
              [
                -6.758860000000027,
                -4.757450000000063,
                -3.182570000000055,
                -1.2795900000000984,
                0.7546299999999064
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_585d50_2d50_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_585d50_2d50_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1791150000003,
                585.950855,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1284900000002,
                584.0150650000002,
                585.8852350000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17832",
      "component_name": "run3",
      "save_point_id": 4999,
      "magnitude_ft": 582.5,
      "elevation_ft": 585.5,
      "runup_ft": 3.0,
      "baseline_ari": 3.5254,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17832_run3_4999",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                3.5253803484545223,
                null,
                null,
                null,
                null
              ],
              [
                23.04668018756305,
                2.490522381281896,
                null,
                null,
                null
              ],
              [
                48.38043601668874,
                18.82762000835909,
                1.8039879581827296,
                1.081783308658708,
                null
              ],
              [
                1000.5000833333622,
                80.07367078121361,
                24.22296744176476,
                2.1726068539727352,
                1.1008752337913468
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                72.1165247902927,
                18.82762000835909,
                1.5563055239274124
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_585d50_3d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_585d50_3d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                582.5,
                null,
                null,
                null,
                null
              ],
              [
                581.0344607692307,
                582.66405,
                null,
                null,
                null
              ],
              [
                579.5908207692307,
                581.2204099999999,
                582.9921499999999,
                584.76389,
                null
              ],
              [
                577.6331315384615,
                579.2955307692307,
                580.9798292307693,
                582.8281,
                584.6544715384614
              ],
              [
                575.6973415384614,
                577.6987515384614,
                579.2736315384615,
                581.1766115384614,
                583.2108315384614
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_585d50_3d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_585d50_3d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.4655392307693091,
                0.1640499999999747,
                null,
                null,
                null
              ],
              [
                -2.9091792307692685,
                -1.2795900000000984,
                0.4921499999999241,
                2.2638899999999467,
                null
              ],
              [
                -4.866868461538502,
                -3.2044692307692912,
                -1.520170769230731,
                0.3280999999999494,
                2.1544715384613937
              ],
              [
                -6.802658461538613,
                -4.801248461538648,
                -3.2263684615385277,
                -1.3233884615385705,
                0.7108315384614343
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_585d50_3d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_585d50_3d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1791150000003,
                585.950855,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1284900000002,
                584.0150650000002,
                585.8852350000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17817",
      "component_name": "base",
      "save_point_id": 4999,
      "magnitude_ft": 585.0,
      "elevation_ft": 585.0,
      "runup_ft": 0.0,
      "baseline_ari": 41.984,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17817_base_4999",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                41.983981741510334,
                null,
                null,
                null,
                null
              ],
              [
                657.9597427211031,
                38.81378743417575,
                null,
                null,
                null
              ],
              [
                1000.5000833333622,
                396.08082632666645,
                32.814191324300545,
                5.176187871354827,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                966.1682188338898,
                35.513764766706764,
                5.629191264046476
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                288.4841357562431,
                27.725765248874385
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_585d00_0d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_585d00_0d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                585.0,
                null,
                null,
                null,
                null
              ],
              [
                583.55636,
                585.173365882353,
                null,
                null,
                null
              ],
              [
                582.1362141176471,
                583.75322,
                585.5014658823529,
                587.273205882353,
                null
              ],
              [
                580.20974,
                581.85024,
                583.49074,
                585.36091,
                587.2075858823529
              ],
              [
                578.2974441176472,
                580.2988541176471,
                581.8737341176471,
                583.7767141176471,
                585.8109341176471
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_585d00_0d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_585d00_0d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.4436399999999594,
                0.1733658823529822,
                null,
                null,
                null
              ],
              [
                -2.863785882352886,
                -1.2467799999999445,
                0.5014658823529317,
                2.273205882352954,
                null
              ],
              [
                -4.790259999999989,
                -3.1497600000000148,
                -1.5092600000000402,
                0.3609099999999898,
                2.2075858823528733
              ],
              [
                -6.70255588235284,
                -4.701145882352876,
                -3.126265882352868,
                -1.2232858823529114,
                0.8109341176470934
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_585d00_0d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_585d00_0d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1791150000003,
                585.950855,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1284900000002,
                584.0150650000002,
                585.8852350000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17817",
      "component_name": "run2",
      "save_point_id": 4999,
      "magnitude_ft": 583.0,
      "elevation_ft": 585.0,
      "runup_ft": 2.0,
      "baseline_ari": 7.0043,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17817_run2_4999",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                7.004270656204618,
                null,
                null,
                null,
                null
              ],
              [
                32.009896942472764,
                5.870627198912554,
                null,
                null,
                null
              ],
              [
                132.52973815285142,
                28.48081881277908,
                3.5800933029902584,
                1.1282037655087171,
                null
              ],
              [
                1000.5000833333622,
                297.654695665757,
                33.18627233076584,
                4.726482283795404,
                1.1484297420032183
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                214.55860326104963,
                28.3274152287085,
                2.4477193193060285
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_585d00_2d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_585d00_2d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.0,
                null,
                null,
                null,
                null
              ],
              [
                581.5563599999999,
                583.1640499999999,
                null,
                null,
                null
              ],
              [
                580.11272,
                581.7204099999999,
                583.5019368181817,
                585.2736768181818,
                null
              ],
              [
                578.17693,
                579.81743,
                581.4579299999999,
                583.3378868181817,
                585.2080568181817
              ],
              [
                576.24114,
                578.2425499999999,
                579.81743,
                581.7204099999999,
                583.7546299999999
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_585d00_2d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_585d00_2d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.443640000000073,
                0.164049999999861,
                null,
                null,
                null
              ],
              [
                -2.8872800000000325,
                -1.2795900000000984,
                0.5019368181816617,
                2.273676818181798,
                null
              ],
              [
                -4.82307000000003,
                -3.182570000000055,
                -1.5420700000000809,
                0.337886818181687,
                2.208056818181717
              ],
              [
                -6.758860000000027,
                -4.757450000000063,
                -3.182570000000055,
                -1.2795900000000984,
                0.7546299999999064
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_585d00_2d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_585d00_2d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1791150000003,
                585.950855,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1284900000002,
                584.0150650000002,
                585.8852350000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17817",
      "component_name": "run25",
      "save_point_id": 4999,
      "magnitude_ft": 582.5,
      "elevation_ft": 585.0,
      "runup_ft": 2.5,
      "baseline_ari": 3.5254,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17817_run25_4999",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                3.5253803484545223,
                null,
                null,
                null,
                null
              ],
              [
                23.04668018756305,
                2.490522381281896,
                null,
                null,
                null
              ],
              [
                48.38043601668874,
                18.82762000835909,
                1.8039879581827296,
                1.081783308658708,
                null
              ],
              [
                1000.5000833333622,
                80.07367078121361,
                24.22296744176476,
                2.1726068539727352,
                1.1008752337913468
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                72.1165247902927,
                18.82762000835909,
                1.5563055239274124
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_585d00_2d50_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_585d00_2d50_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                582.5,
                null,
                null,
                null,
                null
              ],
              [
                581.0344607692307,
                582.66405,
                null,
                null,
                null
              ],
              [
                579.5908207692307,
                581.2204099999999,
                582.9921499999999,
                584.76389,
                null
              ],
              [
                577.6331315384615,
                579.2955307692307,
                580.9798292307693,
                582.8281,
                584.6544715384614
              ],
              [
                575.6973415384614,
                577.6987515384614,
                579.2736315384615,
                581.1766115384614,
                583.2108315384614
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_585d00_2d50_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_585d00_2d50_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.4655392307693091,
                0.1640499999999747,
                null,
                null,
                null
              ],
              [
                -2.9091792307692685,
                -1.2795900000000984,
                0.4921499999999241,
                2.2638899999999467,
                null
              ],
              [
                -4.866868461538502,
                -3.2044692307692912,
                -1.520170769230731,
                0.3280999999999494,
                2.1544715384613937
              ],
              [
                -6.802658461538613,
                -4.801248461538648,
                -3.2263684615385277,
                -1.3233884615385705,
                0.7108315384614343
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_585d00_2d50_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_585d00_2d50_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1791150000003,
                585.950855,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1284900000002,
                584.0150650000002,
                585.8852350000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17817",
      "component_name": "run3",
      "save_point_id": 4999,
      "magnitude_ft": 582.0,
      "elevation_ft": 585.0,
      "runup_ft": 3.0,
      "baseline_ari": 1.7312,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17817_run3_4999",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                1.7312407488633237,
                null,
                null,
                null,
                null
              ],
              [
                10.073214800271067,
                1.532488990247557,
                null,
                null,
                null
              ],
              [
                39.588948853904206,
                8.938025172137348,
                1.3834355825570457,
                1.0434905682635494,
                null
              ],
              [
                1000.5000833333622,
                44.66883729937153,
                11.591333359612012,
                1.4889329178729296,
                1.0599218151400236
              ],
              [
                1000.5000833333622,
                838.4898722099401,
                44.20410831497598,
                8.938025172137348,
                1.3305303988619317
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_585d00_3d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_585d00_3d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                582.0,
                null,
                null,
                null,
                null
              ],
              [
                580.5235500000001,
                582.1640500000001,
                null,
                null,
                null
              ],
              [
                579.0523592307694,
                580.6928592307694,
                582.4645992307693,
                584.2363392307693,
                null
              ],
              [
                577.0837592307693,
                578.7570692307694,
                580.4356384615386,
                582.2729984615386,
                584.1050992307694
              ],
              [
                575.1204184615385,
                577.1218284615386,
                578.6967084615385,
                580.5996884615386,
                582.6339084615385
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_585d00_3d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_585d00_3d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.476449999999886,
                0.1640500000000884,
                null,
                null,
                null
              ],
              [
                -2.9476407692305884,
                -1.3071407692306138,
                0.464599230769295,
                2.236339230769317,
                null
              ],
              [
                -4.91624076923074,
                -3.242930769230611,
                -1.5643615384614122,
                0.2729984615385774,
                2.105099230769383
              ],
              [
                -6.87958153846148,
                -4.878171538461402,
                -3.303291538461508,
                -1.4003115384614375,
                0.6339084615384536
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_585d00_3d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_585d00_3d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1791150000003,
                585.950855,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1284900000002,
                584.0150650000002,
                585.8852350000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17801",
      "component_name": "base",
      "save_point_id": 4999,
      "magnitude_ft": 584.5,
      "elevation_ft": 584.5,
      "runup_ft": 0.0,
      "baseline_ari": 33.0203,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17801_base_4999",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                33.0202670962731,
                null,
                null,
                null,
                null
              ],
              [
                159.168275553235,
                29.67091546929427,
                null,
                null,
                null
              ],
              [
                1000.5000833333622,
                96.50140988929604,
                23.67165531326204,
                2.28207884322574,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                209.83698245749267,
                26.55031544675762,
                2.5963919900858308
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                86.90145215477288,
                17.78491976573462
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_584d50_0d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_584d50_0d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                584.5000000000001,
                null,
                null,
                null,
                null
              ],
              [
                583.05636,
                584.6831698039216,
                null,
                null,
                null
              ],
              [
                581.6264101960785,
                583.2532199999999,
                585.0112698039216,
                586.7830098039216,
                null
              ],
              [
                579.70974,
                581.3502400000001,
                582.9907400000001,
                584.86091,
                586.7173898039215
              ],
              [
                577.7876401960785,
                579.7890501960785,
                581.3639301960785,
                583.2669101960785,
                585.3011301960785
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_584d50_0d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_584d50_0d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.443640000000073,
                0.183169803921487,
                null,
                null,
                null
              ],
              [
                -2.873589803921618,
                -1.2467800000001716,
                0.5112698039214365,
                2.283009803921459,
                null
              ],
              [
                -4.790260000000103,
                -3.1497600000000148,
                -1.5092600000000402,
                0.3609099999998761,
                2.217389803921378
              ],
              [
                -6.712359803921572,
                -4.710949803921608,
                -3.1360698039216004,
                -1.2330898039216436,
                0.8011301960783612
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_584d50_0d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_584d50_0d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1791150000003,
                585.950855,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1284900000002,
                584.0150650000002,
                585.8852350000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17801",
      "component_name": "run2",
      "save_point_id": 4999,
      "magnitude_ft": 582.5,
      "elevation_ft": 584.5,
      "runup_ft": 2.0,
      "baseline_ari": 3.5254,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17801_run2_4999",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                3.5253803484545223,
                null,
                null,
                null,
                null
              ],
              [
                23.04668018756305,
                2.490522381281896,
                null,
                null,
                null
              ],
              [
                48.38043601668874,
                18.82762000835909,
                1.8039879581827296,
                1.081783308658708,
                null
              ],
              [
                1000.5000833333622,
                80.07367078121361,
                24.22296744176476,
                2.1726068539727352,
                1.1008752337913468
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                72.1165247902927,
                18.82762000835909,
                1.5563055239274124
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_584d50_2d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_584d50_2d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                582.5,
                null,
                null,
                null,
                null
              ],
              [
                581.0344607692307,
                582.66405,
                null,
                null,
                null
              ],
              [
                579.5908207692307,
                581.2204099999999,
                582.9921499999999,
                584.76389,
                null
              ],
              [
                577.6331315384615,
                579.2955307692307,
                580.9798292307693,
                582.8281,
                584.6544715384614
              ],
              [
                575.6973415384614,
                577.6987515384614,
                579.2736315384615,
                581.1766115384614,
                583.2108315384614
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_584d50_2d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_584d50_2d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.4655392307693091,
                0.1640499999999747,
                null,
                null,
                null
              ],
              [
                -2.9091792307692685,
                -1.2795900000000984,
                0.4921499999999241,
                2.2638899999999467,
                null
              ],
              [
                -4.866868461538502,
                -3.2044692307692912,
                -1.520170769230731,
                0.3280999999999494,
                2.1544715384613937
              ],
              [
                -6.802658461538613,
                -4.801248461538648,
                -3.2263684615385277,
                -1.3233884615385705,
                0.7108315384614343
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_584d50_2d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_584d50_2d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1791150000003,
                585.950855,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1284900000002,
                584.0150650000002,
                585.8852350000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17801",
      "component_name": "run25",
      "save_point_id": 4999,
      "magnitude_ft": 582.0,
      "elevation_ft": 584.5,
      "runup_ft": 2.5,
      "baseline_ari": 1.7312,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17801_run25_4999",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                1.7312407488633237,
                null,
                null,
                null,
                null
              ],
              [
                10.073214800271067,
                1.532488990247557,
                null,
                null,
                null
              ],
              [
                39.588948853904206,
                8.938025172137348,
                1.3834355825570457,
                1.0434905682635494,
                null
              ],
              [
                1000.5000833333622,
                44.66883729937153,
                11.591333359612012,
                1.4889329178729296,
                1.0599218151400236
              ],
              [
                1000.5000833333622,
                838.4898722099401,
                44.20410831497598,
                8.938025172137348,
                1.3305303988619317
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_584d50_2d50_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_584d50_2d50_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                582.0,
                null,
                null,
                null,
                null
              ],
              [
                580.5235500000001,
                582.1640500000001,
                null,
                null,
                null
              ],
              [
                579.0523592307694,
                580.6928592307694,
                582.4645992307693,
                584.2363392307693,
                null
              ],
              [
                577.0837592307693,
                578.7570692307694,
                580.4356384615386,
                582.2729984615386,
                584.1050992307694
              ],
              [
                575.1204184615385,
                577.1218284615386,
                578.6967084615385,
                580.5996884615386,
                582.6339084615385
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_584d50_2d50_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_584d50_2d50_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.476449999999886,
                0.1640500000000884,
                null,
                null,
                null
              ],
              [
                -2.9476407692305884,
                -1.3071407692306138,
                0.464599230769295,
                2.236339230769317,
                null
              ],
              [
                -4.91624076923074,
                -3.242930769230611,
                -1.5643615384614122,
                0.2729984615385774,
                2.105099230769383
              ],
              [
                -6.87958153846148,
                -4.878171538461402,
                -3.303291538461508,
                -1.4003115384614375,
                0.6339084615384536
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_584d50_2d50_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_584d50_2d50_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1791150000003,
                585.950855,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1284900000002,
                584.0150650000002,
                585.8852350000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17801",
      "component_name": "run3",
      "save_point_id": 4999,
      "magnitude_ft": 581.5,
      "elevation_ft": 584.5,
      "runup_ft": 3.0,
      "baseline_ari": 1.3554,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17801_run3_4999",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                1.3553707021079415,
                null,
                null,
                null,
                null
              ],
              [
                6.614689039302702,
                1.284824295376844,
                null,
                null,
                null
              ],
              [
                30.79768890700058,
                5.480904892576822,
                1.155981946415259,
                1.0163418555464894,
                null
              ],
              [
                359.89731147408975,
                35.70504932114278,
                7.295135882462185,
                1.2613158845765444,
                1.0280786848488543
              ],
              [
                1000.5000833333622,
                271.61429701100866,
                35.412709873678416,
                5.485671548988741,
                1.150621789973548
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_584d50_3d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_584d50_3d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                581.5000000000001,
                null,
                null,
                null,
                null
              ],
              [
                580.0069488461539,
                581.6474488461539,
                null,
                null,
                null
              ],
              [
                578.5138976923079,
                580.1709988461539,
                581.9427388461539,
                583.714478846154,
                null
              ],
              [
                576.5286965384616,
                578.2020065384617,
                579.8919176923077,
                581.7126765384617,
                583.5500365384617
              ],
              [
                574.5434953846155,
                576.5449053846155,
                578.1197853846155,
                580.0227653846155,
                582.0569853846155
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_584d50_3d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_584d50_3d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.4930511538461817,
                0.147448846153793,
                null,
                null,
                null
              ],
              [
                -2.9861023076922493,
                -1.3290011538462068,
                0.4427388461538157,
                2.2144788461538383,
                null
              ],
              [
                -4.971303461538469,
                -3.2979934615384536,
                -1.6080823076923707,
                0.212676538461551,
                2.0500365384615407
              ],
              [
                -6.956504615384574,
                -4.95509461538461,
                -3.3802146153846024,
                -1.4772346153846456,
                0.5569853846153592
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_584d50_3d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_584d50_3d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1791150000003,
                585.950855,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1284900000002,
                584.0150650000002,
                585.8852350000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17786",
      "component_name": "base",
      "save_point_id": 4999,
      "magnitude_ft": 584.0,
      "elevation_ft": 584.0,
      "runup_ft": 0.0,
      "baseline_ari": 24.057,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17786_base_4999",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                24.056973952005094,
                null,
                null,
                null,
                null
              ],
              [
                49.93747462211457,
                20.528666118967458,
                null,
                null,
                null
              ],
              [
                1000.5000833333622,
                46.40819245502311,
                10.2999965340185,
                1.4981216558913604,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                57.006732324753855,
                14.995574269525928,
                1.5667722890280522
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                1000.5000833333622,
                45.91001280997219,
                8.701271391407191
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_584d00_0d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_584d00_0d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                584.0000000000001,
                null,
                null,
                null,
                null
              ],
              [
                582.5563600000002,
                584.1929737254903,
                null,
                null,
                null
              ],
              [
                581.1166062745099,
                582.75322,
                584.5210737254903,
                586.2928137254903,
                null
              ],
              [
                579.2097400000001,
                580.8502400000001,
                582.4907400000001,
                584.3609100000001,
                586.2271937254902
              ],
              [
                577.2778362745099,
                579.2792462745099,
                580.8541262745099,
                582.7571062745099,
                584.7913262745099
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_584d00_0d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_584d00_0d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.4436399999999594,
                0.1929737254902193,
                null,
                null,
                null
              ],
              [
                -2.8833937254902366,
                -1.246780000000058,
                0.5210737254901687,
                2.2928137254901912,
                null
              ],
              [
                -4.790259999999989,
                -3.1497600000000148,
                -1.5092600000000402,
                0.3609099999999898,
                2.2271937254901104
              ],
              [
                -6.722163725490191,
                -4.720753725490226,
                -3.145873725490219,
                -1.242893725490262,
                0.7913262745097427
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_584d00_0d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_584d00_0d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1791150000003,
                585.950855,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1284900000002,
                584.0150650000002,
                585.8852350000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17786",
      "component_name": "run2",
      "save_point_id": 4999,
      "magnitude_ft": 582.0,
      "elevation_ft": 584.0,
      "runup_ft": 2.0,
      "baseline_ari": 1.7312,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17786_run2_4999",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                1.7312407488633237,
                null,
                null,
                null,
                null
              ],
              [
                10.073214800271067,
                1.532488990247557,
                null,
                null,
                null
              ],
              [
                39.588948853904206,
                8.938025172137348,
                1.3834355825570457,
                1.0434905682635494,
                null
              ],
              [
                1000.5000833333622,
                44.66883729937153,
                11.591333359612012,
                1.4889329178729296,
                1.0599218151400236
              ],
              [
                1000.5000833333622,
                838.4898722099401,
                44.20410831497598,
                8.938025172137348,
                1.3305303988619317
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_584d00_2d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_584d00_2d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                582.0,
                null,
                null,
                null,
                null
              ],
              [
                580.5235500000001,
                582.1640500000001,
                null,
                null,
                null
              ],
              [
                579.0523592307694,
                580.6928592307694,
                582.4645992307693,
                584.2363392307693,
                null
              ],
              [
                577.0837592307693,
                578.7570692307694,
                580.4356384615386,
                582.2729984615386,
                584.1050992307694
              ],
              [
                575.1204184615385,
                577.1218284615386,
                578.6967084615385,
                580.5996884615386,
                582.6339084615385
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_584d00_2d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_584d00_2d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.476449999999886,
                0.1640500000000884,
                null,
                null,
                null
              ],
              [
                -2.9476407692305884,
                -1.3071407692306138,
                0.464599230769295,
                2.236339230769317,
                null
              ],
              [
                -4.91624076923074,
                -3.242930769230611,
                -1.5643615384614122,
                0.2729984615385774,
                2.105099230769383
              ],
              [
                -6.87958153846148,
                -4.878171538461402,
                -3.303291538461508,
                -1.4003115384614375,
                0.6339084615384536
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_584d00_2d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_584d00_2d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1791150000003,
                585.950855,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1284900000002,
                584.0150650000002,
                585.8852350000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17786",
      "component_name": "run25",
      "save_point_id": 4999,
      "magnitude_ft": 581.5,
      "elevation_ft": 584.0,
      "runup_ft": 2.5,
      "baseline_ari": 1.3554,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17786_run25_4999",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                1.3553707021079415,
                null,
                null,
                null,
                null
              ],
              [
                6.614689039302702,
                1.284824295376844,
                null,
                null,
                null
              ],
              [
                30.79768890700058,
                5.480904892576822,
                1.155981946415259,
                1.0163418555464894,
                null
              ],
              [
                359.89731147408975,
                35.70504932114278,
                7.295135882462185,
                1.2613158845765444,
                1.0280786848488543
              ],
              [
                1000.5000833333622,
                271.61429701100866,
                35.412709873678416,
                5.485671548988741,
                1.150621789973548
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_584d00_2d50_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_584d00_2d50_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                581.5000000000001,
                null,
                null,
                null,
                null
              ],
              [
                580.0069488461539,
                581.6474488461539,
                null,
                null,
                null
              ],
              [
                578.5138976923079,
                580.1709988461539,
                581.9427388461539,
                583.714478846154,
                null
              ],
              [
                576.5286965384616,
                578.2020065384617,
                579.8919176923077,
                581.7126765384617,
                583.5500365384617
              ],
              [
                574.5434953846155,
                576.5449053846155,
                578.1197853846155,
                580.0227653846155,
                582.0569853846155
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_584d00_2d50_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_584d00_2d50_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.4930511538461817,
                0.147448846153793,
                null,
                null,
                null
              ],
              [
                -2.9861023076922493,
                -1.3290011538462068,
                0.4427388461538157,
                2.2144788461538383,
                null
              ],
              [
                -4.971303461538469,
                -3.2979934615384536,
                -1.6080823076923707,
                0.212676538461551,
                2.0500365384615407
              ],
              [
                -6.956504615384574,
                -4.95509461538461,
                -3.3802146153846024,
                -1.4772346153846456,
                0.5569853846153592
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_584d00_2d50_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_584d00_2d50_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1791150000003,
                585.950855,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1284900000002,
                584.0150650000002,
                585.8852350000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17786",
      "component_name": "run3",
      "save_point_id": 4999,
      "magnitude_ft": 581.0,
      "elevation_ft": 584.0,
      "runup_ft": 3.0,
      "baseline_ari": 1.1479,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17786_run3_4999",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                1.1479142800144286,
                null,
                null,
                null,
                null
              ],
              [
                3.3025564235593228,
                1.1342168548843787,
                null,
                null,
                null
              ],
              [
                22.00693485158549,
                2.374288295826097,
                1.1061707056404777,
                1.005764384178229,
                null
              ],
              [
                98.527366414656,
                26.741589611185685,
                3.6777254377908135,
                1.1323622615948237,
                1.0081210063023822
              ],
              [
                1000.5000833333622,
                83.5275199989944,
                26.621634704516676,
                2.5157294983892537,
                1.11088190075482
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_584d00_3d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_584d00_3d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                581.0000000000001,
                null,
                null,
                null,
                null
              ],
              [
                579.4855020000001,
                581.1299305000001,
                null,
                null,
                null
              ],
              [
                577.9710040000002,
                579.6482425000002,
                581.4226015000002,
                583.1943415000001,
                null
              ],
              [
                575.9630465000001,
                577.6402850000001,
                579.3516430000001,
                581.1575025000002,
                582.9948625000002
              ],
              [
                573.9537795000002,
                575.9551895000002,
                577.5300695000002,
                579.4330495000002,
                581.4672695000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_584d00_3d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_584d00_3d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.5144980000000032,
                0.1299305000000004,
                null,
                null,
                null
              ],
              [
                -3.0289959999998928,
                -1.3517574999999624,
                0.4226015000000416,
                2.1943414999999504,
                null
              ],
              [
                -5.036953499999981,
                -3.359715000000051,
                -1.6483570000000327,
                0.1575025000000778,
                1.9948625000000677
              ],
              [
                -7.04622049999989,
                -5.044810499999926,
                -3.4699304999999185,
                -1.5669504999999615,
                0.4672695000000431
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_584d00_3d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_584d00_3d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1791150000003,
                585.950855,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1284900000002,
                584.0150650000002,
                585.8852350000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17771",
      "component_name": "base",
      "save_point_id": 4999,
      "magnitude_ft": 583.5,
      "elevation_ft": 583.5,
      "runup_ft": 0.0,
      "baseline_ari": 10.4633,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17771_base_4999",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                10.46327532981882,
                null,
                null,
                null,
                null
              ],
              [
                40.97357955935377,
                9.327989779984494,
                null,
                null,
                null
              ],
              [
                467.8161296685657,
                37.444364508669175,
                6.991463155076583,
                1.2537457313683718,
                null
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                42.149991985050015,
                8.076573549041086,
                1.332794838112259
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                711.6992773207871,
                37.118574796006754,
                5.277809951727623
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_583d50_0d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_583d50_0d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.5000000000002,
                null,
                null,
                null,
                null
              ],
              [
                582.0563600000002,
                583.6640500000001,
                null,
                null,
                null
              ],
              [
                580.6127200000002,
                582.2204100000001,
                584.0246640909093,
                585.7964040909092,
                null
              ],
              [
                578.6769300000002,
                580.3174300000002,
                581.9579300000001,
                583.8606140909092,
                585.7307840909092
              ],
              [
                576.7411400000002,
                578.7425500000002,
                580.3174300000002,
                582.2204100000001,
                584.2546300000001
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_583d50_0d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_583d50_0d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.443640000000073,
                0.164049999999861,
                null,
                null,
                null
              ],
              [
                -2.8872800000000325,
                -1.2795900000000984,
                0.5246640909090274,
                2.2964040909089363,
                null
              ],
              [
                -4.82307000000003,
                -3.182570000000055,
                -1.5420700000000809,
                0.360614090908939,
                2.230784090908969
              ],
              [
                -6.758860000000027,
                -4.757450000000063,
                -3.182570000000055,
                -1.2795900000000984,
                0.7546299999999064
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_583d50_0d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_583d50_0d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1791150000003,
                585.950855,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1284900000002,
                584.0150650000002,
                585.8852350000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17771",
      "component_name": "run2",
      "save_point_id": 4999,
      "magnitude_ft": 581.5,
      "elevation_ft": 583.5,
      "runup_ft": 2.0,
      "baseline_ari": 1.3554,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17771_run2_4999",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                1.3553707021079415,
                null,
                null,
                null,
                null
              ],
              [
                6.614689039302702,
                1.284824295376844,
                null,
                null,
                null
              ],
              [
                30.79768890700058,
                5.480904892576822,
                1.155981946415259,
                1.0163418555464894,
                null
              ],
              [
                359.89731147408975,
                35.70504932114278,
                7.295135882462185,
                1.2613158845765444,
                1.0280786848488543
              ],
              [
                1000.5000833333622,
                271.61429701100866,
                35.412709873678416,
                5.485671548988741,
                1.150621789973548
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_583d50_2d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_583d50_2d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                581.5000000000001,
                null,
                null,
                null,
                null
              ],
              [
                580.0069488461539,
                581.6474488461539,
                null,
                null,
                null
              ],
              [
                578.5138976923079,
                580.1709988461539,
                581.9427388461539,
                583.714478846154,
                null
              ],
              [
                576.5286965384616,
                578.2020065384617,
                579.8919176923077,
                581.7126765384617,
                583.5500365384617
              ],
              [
                574.5434953846155,
                576.5449053846155,
                578.1197853846155,
                580.0227653846155,
                582.0569853846155
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_583d50_2d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_583d50_2d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.4930511538461817,
                0.147448846153793,
                null,
                null,
                null
              ],
              [
                -2.9861023076922493,
                -1.3290011538462068,
                0.4427388461538157,
                2.2144788461538383,
                null
              ],
              [
                -4.971303461538469,
                -3.2979934615384536,
                -1.6080823076923707,
                0.212676538461551,
                2.0500365384615407
              ],
              [
                -6.956504615384574,
                -4.95509461538461,
                -3.3802146153846024,
                -1.4772346153846456,
                0.5569853846153592
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_583d50_2d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_583d50_2d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1791150000003,
                585.950855,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1284900000002,
                584.0150650000002,
                585.8852350000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17771",
      "component_name": "run25",
      "save_point_id": 4999,
      "magnitude_ft": 581.0,
      "elevation_ft": 583.5,
      "runup_ft": 2.5,
      "baseline_ari": 1.1479,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17771_run25_4999",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                1.1479142800144286,
                null,
                null,
                null,
                null
              ],
              [
                3.3025564235593228,
                1.1342168548843787,
                null,
                null,
                null
              ],
              [
                22.00693485158549,
                2.374288295826097,
                1.1061707056404777,
                1.005764384178229,
                null
              ],
              [
                98.527366414656,
                26.741589611185685,
                3.6777254377908135,
                1.1323622615948237,
                1.0081210063023822
              ],
              [
                1000.5000833333622,
                83.5275199989944,
                26.621634704516676,
                2.5157294983892537,
                1.11088190075482
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_583d50_2d50_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_583d50_2d50_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                581.0000000000001,
                null,
                null,
                null,
                null
              ],
              [
                579.4855020000001,
                581.1299305000001,
                null,
                null,
                null
              ],
              [
                577.9710040000002,
                579.6482425000002,
                581.4226015000002,
                583.1943415000001,
                null
              ],
              [
                575.9630465000001,
                577.6402850000001,
                579.3516430000001,
                581.1575025000002,
                582.9948625000002
              ],
              [
                573.9537795000002,
                575.9551895000002,
                577.5300695000002,
                579.4330495000002,
                581.4672695000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_583d50_2d50_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_583d50_2d50_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.5144980000000032,
                0.1299305000000004,
                null,
                null,
                null
              ],
              [
                -3.0289959999998928,
                -1.3517574999999624,
                0.4226015000000416,
                2.1943414999999504,
                null
              ],
              [
                -5.036953499999981,
                -3.359715000000051,
                -1.6483570000000327,
                0.1575025000000778,
                1.9948625000000677
              ],
              [
                -7.04622049999989,
                -5.044810499999926,
                -3.4699304999999185,
                -1.5669504999999615,
                0.4672695000000431
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_583d50_2d50_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_583d50_2d50_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1791150000003,
                585.950855,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1284900000002,
                584.0150650000002,
                585.8852350000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17771",
      "component_name": "run3",
      "save_point_id": 4999,
      "magnitude_ft": 580.5,
      "elevation_ft": 583.5,
      "runup_ft": 3.0,
      "baseline_ari": 1.0967,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17771_run3_4999",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                1.0967278473278688,
                null,
                null,
                null,
                null
              ],
              [
                1.67948031529807,
                1.0855605224166684,
                null,
                null,
                null
              ],
              [
                9.683183319905636,
                1.5203842876853473,
                1.0631237741835975,
                1.0037372091493786,
                null
              ],
              [
                47.187694927477104,
                15.871469766346411,
                1.8549794493781036,
                1.0867216303497027,
                1.0048013094367123
              ],
              [
                1000.5000833333622,
                45.52072429311094,
                15.871469766346411,
                1.5722574858671152,
                1.0752854945401964
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_583d50_3d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_583d50_3d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                580.5000000000001,
                null,
                null,
                null,
                null
              ],
              [
                578.9521686666668,
                580.6215971666668,
                null,
                null,
                null
              ],
              [
                577.4043373333335,
                579.1065758333334,
                580.8976015000002,
                582.6693415000001,
                null
              ],
              [
                575.3547131666668,
                577.0569516666668,
                578.8016430000001,
                580.6158358333334,
                582.4531958333334
              ],
              [
                573.2954461666668,
                575.2968561666668,
                576.8717361666667,
                578.7747161666667,
                580.8089361666667
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_583d50_3d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_583d50_3d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.5478313333333062,
                0.1215971666666746,
                null,
                null,
                null
              ],
              [
                -3.0956626666666125,
                -1.3934241666667049,
                0.3976015000000643,
                2.169341499999973,
                null
              ],
              [
                -5.14528683333333,
                -3.4430483333333086,
                -1.6983569999999872,
                0.1158358333333353,
                1.953195833333325
              ],
              [
                -7.204553833333307,
                -5.203143833333343,
                -3.628263833333449,
                -1.7252838333333784,
                0.3089361666666264
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_583d50_3d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_583d50_3d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1791150000003,
                585.950855,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1284900000002,
                584.0150650000002,
                585.8852350000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17756",
      "component_name": "base",
      "save_point_id": 4999,
      "magnitude_ft": 583.0,
      "elevation_ft": 583.0,
      "runup_ft": 0.0,
      "baseline_ari": 7.0043,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17756_base_4999",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                7.004270656204618,
                null,
                null,
                null,
                null
              ],
              [
                32.009896942472764,
                5.870627198912554,
                null,
                null,
                null
              ],
              [
                132.52973815285142,
                28.48081881277908,
                3.5800933029902584,
                1.1282037655087171,
                null
              ],
              [
                1000.5000833333622,
                297.654695665757,
                33.18627233076584,
                4.726482283795404,
                1.1484297420032183
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                214.55860326104963,
                28.3274152287085,
                2.4477193193060285
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_583d00_0d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_583d00_0d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.0,
                null,
                null,
                null,
                null
              ],
              [
                581.5563599999999,
                583.1640499999999,
                null,
                null,
                null
              ],
              [
                580.11272,
                581.7204099999999,
                583.5019368181817,
                585.2736768181818,
                null
              ],
              [
                578.17693,
                579.81743,
                581.4579299999999,
                583.3378868181817,
                585.2080568181817
              ],
              [
                576.24114,
                578.2425499999999,
                579.81743,
                581.7204099999999,
                583.7546299999999
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_583d00_0d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_583d00_0d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.443640000000073,
                0.164049999999861,
                null,
                null,
                null
              ],
              [
                -2.8872800000000325,
                -1.2795900000000984,
                0.5019368181816617,
                2.273676818181798,
                null
              ],
              [
                -4.82307000000003,
                -3.182570000000055,
                -1.5420700000000809,
                0.337886818181687,
                2.208056818181717
              ],
              [
                -6.758860000000027,
                -4.757450000000063,
                -3.182570000000055,
                -1.2795900000000984,
                0.7546299999999064
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_583d00_0d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_583d00_0d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1791150000003,
                585.950855,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1284900000002,
                584.0150650000002,
                585.8852350000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17756",
      "component_name": "run2",
      "save_point_id": 4999,
      "magnitude_ft": 581.0,
      "elevation_ft": 583.0,
      "runup_ft": 2.0,
      "baseline_ari": 1.1479,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17756_run2_4999",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                1.1479142800144286,
                null,
                null,
                null,
                null
              ],
              [
                3.3025564235593228,
                1.1342168548843787,
                null,
                null,
                null
              ],
              [
                22.00693485158549,
                2.374288295826097,
                1.1061707056404777,
                1.005764384178229,
                null
              ],
              [
                98.527366414656,
                26.741589611185685,
                3.6777254377908135,
                1.1323622615948237,
                1.0081210063023822
              ],
              [
                1000.5000833333622,
                83.5275199989944,
                26.621634704516676,
                2.5157294983892537,
                1.11088190075482
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_583d00_2d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_583d00_2d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                581.0000000000001,
                null,
                null,
                null,
                null
              ],
              [
                579.4855020000001,
                581.1299305000001,
                null,
                null,
                null
              ],
              [
                577.9710040000002,
                579.6482425000002,
                581.4226015000002,
                583.1943415000001,
                null
              ],
              [
                575.9630465000001,
                577.6402850000001,
                579.3516430000001,
                581.1575025000002,
                582.9948625000002
              ],
              [
                573.9537795000002,
                575.9551895000002,
                577.5300695000002,
                579.4330495000002,
                581.4672695000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_583d00_2d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_583d00_2d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.5144980000000032,
                0.1299305000000004,
                null,
                null,
                null
              ],
              [
                -3.0289959999998928,
                -1.3517574999999624,
                0.4226015000000416,
                2.1943414999999504,
                null
              ],
              [
                -5.036953499999981,
                -3.359715000000051,
                -1.6483570000000327,
                0.1575025000000778,
                1.9948625000000677
              ],
              [
                -7.04622049999989,
                -5.044810499999926,
                -3.4699304999999185,
                -1.5669504999999615,
                0.4672695000000431
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_583d00_2d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_583d00_2d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1791150000003,
                585.950855,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1284900000002,
                584.0150650000002,
                585.8852350000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17756",
      "component_name": "run25",
      "save_point_id": 4999,
      "magnitude_ft": 580.5,
      "elevation_ft": 583.0,
      "runup_ft": 2.5,
      "baseline_ari": 1.0967,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17756_run25_4999",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                1.0967278473278688,
                null,
                null,
                null,
                null
              ],
              [
                1.67948031529807,
                1.0855605224166684,
                null,
                null,
                null
              ],
              [
                9.683183319905636,
                1.5203842876853473,
                1.0631237741835975,
                1.0037372091493786,
                null
              ],
              [
                47.187694927477104,
                15.871469766346411,
                1.8549794493781036,
                1.0867216303497027,
                1.0048013094367123
              ],
              [
                1000.5000833333622,
                45.52072429311094,
                15.871469766346411,
                1.5722574858671152,
                1.0752854945401964
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_583d00_2d50_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_583d00_2d50_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                580.5000000000001,
                null,
                null,
                null,
                null
              ],
              [
                578.9521686666668,
                580.6215971666668,
                null,
                null,
                null
              ],
              [
                577.4043373333335,
                579.1065758333334,
                580.8976015000002,
                582.6693415000001,
                null
              ],
              [
                575.3547131666668,
                577.0569516666668,
                578.8016430000001,
                580.6158358333334,
                582.4531958333334
              ],
              [
                573.2954461666668,
                575.2968561666668,
                576.8717361666667,
                578.7747161666667,
                580.8089361666667
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_583d00_2d50_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_583d00_2d50_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.5478313333333062,
                0.1215971666666746,
                null,
                null,
                null
              ],
              [
                -3.0956626666666125,
                -1.3934241666667049,
                0.3976015000000643,
                2.169341499999973,
                null
              ],
              [
                -5.14528683333333,
                -3.4430483333333086,
                -1.6983569999999872,
                0.1158358333333353,
                1.953195833333325
              ],
              [
                -7.204553833333307,
                -5.203143833333343,
                -3.628263833333449,
                -1.7252838333333784,
                0.3089361666666264
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_583d00_2d50_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_583d00_2d50_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1791150000003,
                585.950855,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1284900000002,
                584.0150650000002,
                585.8852350000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17756",
      "component_name": "run3",
      "save_point_id": 4999,
      "magnitude_ft": 580.0,
      "elevation_ft": 583.0,
      "runup_ft": 3.0,
      "baseline_ari": 1.0535,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17756_run3_4999",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                1.0535425842324728,
                null,
                null,
                null,
                null
              ],
              [
                1.3519879803671069,
                1.0453272471051946,
                null,
                null,
                null
              ],
              [
                6.225219435900785,
                1.2738257213782045,
                1.029522749854768,
                1.0022408221485035,
                null
              ],
              [
                38.22385067604155,
                8.266830047015304,
                1.4066874220651888,
                1.0484251404650913,
                1.0030724759625147
              ],
              [
                840.8773554184243,
                36.72929486541654,
                8.266830047015304,
                1.345411751037138,
                1.045115919980597
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_583d00_3d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_583d00_3d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                580.0000000000001,
                null,
                null,
                null,
                null
              ],
              [
                578.4188353333335,
                580.1132638333335,
                null,
                null,
                null
              ],
              [
                576.8376706666668,
                578.5649091666668,
                580.3726015000001,
                582.1443415000001,
                null
              ],
              [
                574.7463798333334,
                576.4736183333334,
                578.2516430000002,
                580.0741691666668,
                581.9115291666668
              ],
              [
                572.6371128333335,
                574.6385228333336,
                576.2134028333335,
                578.1163828333335,
                580.1506028333336
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_583d00_3d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_583d00_3d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.5811646666666093,
                0.1132638333333488,
                null,
                null,
                null
              ],
              [
                -3.162329333333332,
                -1.4350908333333336,
                0.3726014999999734,
                2.144341499999996,
                null
              ],
              [
                -5.253620166666678,
                -3.52638166666668,
                -1.7483569999999418,
                0.0741691666667065,
                1.9115291666666965
              ],
              [
                -7.36288716666661,
                -5.361477166666532,
                -3.7865971666666383,
                -1.883617166666568,
                0.150602833333437
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_583d00_3d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_583d00_3d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1791150000003,
                585.950855,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1284900000002,
                584.0150650000002,
                585.8852350000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17740",
      "component_name": "base",
      "save_point_id": 4999,
      "magnitude_ft": 582.5,
      "elevation_ft": 582.5,
      "runup_ft": 0.0,
      "baseline_ari": 3.5254,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17740_base_4999",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                3.5253803484545223,
                null,
                null,
                null,
                null
              ],
              [
                23.04668018756305,
                2.490522381281896,
                null,
                null,
                null
              ],
              [
                48.38043601668874,
                18.82762000835909,
                1.8039879581827296,
                1.081783308658708,
                null
              ],
              [
                1000.5000833333622,
                80.07367078121361,
                24.22296744176476,
                2.1726068539727352,
                1.1008752337913468
              ],
              [
                1000.5000833333622,
                1000.5000833333622,
                72.1165247902927,
                18.82762000835909,
                1.5563055239274124
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_582d50_0d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_582d50_0d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                582.5,
                null,
                null,
                null,
                null
              ],
              [
                581.0344607692307,
                582.66405,
                null,
                null,
                null
              ],
              [
                579.5908207692307,
                581.2204099999999,
                582.9921499999999,
                584.76389,
                null
              ],
              [
                577.6331315384615,
                579.2955307692307,
                580.9798292307693,
                582.8281,
                584.6544715384614
              ],
              [
                575.6973415384614,
                577.6987515384614,
                579.2736315384615,
                581.1766115384614,
                583.2108315384614
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_582d50_0d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_582d50_0d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.4655392307693091,
                0.1640499999999747,
                null,
                null,
                null
              ],
              [
                -2.9091792307692685,
                -1.2795900000000984,
                0.4921499999999241,
                2.2638899999999467,
                null
              ],
              [
                -4.866868461538502,
                -3.2044692307692912,
                -1.520170769230731,
                0.3280999999999494,
                2.1544715384613937
              ],
              [
                -6.802658461538613,
                -4.801248461538648,
                -3.2263684615385277,
                -1.3233884615385705,
                0.7108315384614343
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_582d50_0d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_582d50_0d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1791150000003,
                585.950855,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1284900000002,
                584.0150650000002,
                585.8852350000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17740",
      "component_name": "run2",
      "save_point_id": 4999,
      "magnitude_ft": 580.5,
      "elevation_ft": 582.5,
      "runup_ft": 2.0,
      "baseline_ari": 1.0967,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17740_run2_4999",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                1.0967278473278688,
                null,
                null,
                null,
                null
              ],
              [
                1.67948031529807,
                1.0855605224166684,
                null,
                null,
                null
              ],
              [
                9.683183319905636,
                1.5203842876853473,
                1.0631237741835975,
                1.0037372091493786,
                null
              ],
              [
                47.187694927477104,
                15.871469766346411,
                1.8549794493781036,
                1.0867216303497027,
                1.0048013094367123
              ],
              [
                1000.5000833333622,
                45.52072429311094,
                15.871469766346411,
                1.5722574858671152,
                1.0752854945401964
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_582d50_2d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_582d50_2d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                580.5000000000001,
                null,
                null,
                null,
                null
              ],
              [
                578.9521686666668,
                580.6215971666668,
                null,
                null,
                null
              ],
              [
                577.4043373333335,
                579.1065758333334,
                580.8976015000002,
                582.6693415000001,
                null
              ],
              [
                575.3547131666668,
                577.0569516666668,
                578.8016430000001,
                580.6158358333334,
                582.4531958333334
              ],
              [
                573.2954461666668,
                575.2968561666668,
                576.8717361666667,
                578.7747161666667,
                580.8089361666667
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_582d50_2d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_582d50_2d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.5478313333333062,
                0.1215971666666746,
                null,
                null,
                null
              ],
              [
                -3.0956626666666125,
                -1.3934241666667049,
                0.3976015000000643,
                2.169341499999973,
                null
              ],
              [
                -5.14528683333333,
                -3.4430483333333086,
                -1.6983569999999872,
                0.1158358333333353,
                1.953195833333325
              ],
              [
                -7.204553833333307,
                -5.203143833333343,
                -3.628263833333449,
                -1.7252838333333784,
                0.3089361666666264
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_582d50_2d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_582d50_2d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1791150000003,
                585.950855,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1284900000002,
                584.0150650000002,
                585.8852350000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17740",
      "component_name": "run25",
      "save_point_id": 4999,
      "magnitude_ft": 580.0,
      "elevation_ft": 582.5,
      "runup_ft": 2.5,
      "baseline_ari": 1.0535,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17740_run25_4999",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                1.0535425842324728,
                null,
                null,
                null,
                null
              ],
              [
                1.3519879803671069,
                1.0453272471051946,
                null,
                null,
                null
              ],
              [
                6.225219435900785,
                1.2738257213782045,
                1.029522749854768,
                1.0022408221485035,
                null
              ],
              [
                38.22385067604155,
                8.266830047015304,
                1.4066874220651888,
                1.0484251404650913,
                1.0030724759625147
              ],
              [
                840.8773554184243,
                36.72929486541654,
                8.266830047015304,
                1.345411751037138,
                1.045115919980597
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_582d50_2d50_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_582d50_2d50_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                580.0000000000001,
                null,
                null,
                null,
                null
              ],
              [
                578.4188353333335,
                580.1132638333335,
                null,
                null,
                null
              ],
              [
                576.8376706666668,
                578.5649091666668,
                580.3726015000001,
                582.1443415000001,
                null
              ],
              [
                574.7463798333334,
                576.4736183333334,
                578.2516430000002,
                580.0741691666668,
                581.9115291666668
              ],
              [
                572.6371128333335,
                574.6385228333336,
                576.2134028333335,
                578.1163828333335,
                580.1506028333336
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_582d50_2d50_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_582d50_2d50_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.5811646666666093,
                0.1132638333333488,
                null,
                null,
                null
              ],
              [
                -3.162329333333332,
                -1.4350908333333336,
                0.3726014999999734,
                2.144341499999996,
                null
              ],
              [
                -5.253620166666678,
                -3.52638166666668,
                -1.7483569999999418,
                0.0741691666667065,
                1.9115291666666965
              ],
              [
                -7.36288716666661,
                -5.361477166666532,
                -3.7865971666666383,
                -1.883617166666568,
                0.150602833333437
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_582d50_2d50_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_582d50_2d50_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1791150000003,
                585.950855,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1284900000002,
                584.0150650000002,
                585.8852350000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17740",
      "component_name": "run3",
      "save_point_id": 4999,
      "magnitude_ft": 579.5,
      "elevation_ft": 582.5,
      "runup_ft": 3.0,
      "baseline_ari": 1.0216,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17740_run3_4999",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                1.0216428888237494,
                null,
                null,
                null,
                null
              ],
              [
                1.149392971074503,
                1.016796338958725,
                null,
                null,
                null
              ],
              [
                2.9390297817581468,
                1.133262721625904,
                1.0084248615122589,
                1.0012134564393638,
                null
              ],
              [
                29.260270859941897,
                4.852258068747572,
                1.1814128698785666,
                1.0201677513441765,
                1.001814514012106
              ],
              [
                272.6886633684599,
                27.938153338011308,
                4.896527032093121,
                1.1534669475443988,
                1.0219378424833805
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_582d50_3d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_582d50_3d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                579.4999999999999,
                null,
                null,
                null,
                null
              ],
              [
                577.8855019999999,
                579.6049304999999,
                null,
                null,
                null
              ],
              [
                576.271004,
                578.0232424999998,
                579.8476015,
                581.6193414999999,
                null
              ],
              [
                574.1380464999999,
                575.8902849999998,
                577.7016429999999,
                579.5325024999999,
                581.3698625
              ],
              [
                571.9787794999999,
                573.9801894999998,
                575.5550694999998,
                577.4580494999999,
                579.4922694999999
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_582d50_3d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_582d50_3d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.614498000000026,
                0.1049305000000231,
                null,
                null,
                null
              ],
              [
                -3.2289959999999382,
                -1.476757500000076,
                0.3476015000001098,
                2.119341500000018,
                null
              ],
              [
                -5.361953500000027,
                -3.609715000000051,
                -1.79835700000001,
                0.0325024999999641,
                1.8698625000000677
              ],
              [
                -7.521220500000027,
                -5.519810500000062,
                -3.944930500000055,
                -2.0419504999999845,
                -0.0077304999999796
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_582d50_3d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_582d50_3d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1791150000003,
                585.950855,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1284900000002,
                584.0150650000002,
                585.8852350000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17725",
      "component_name": "base",
      "save_point_id": 4999,
      "magnitude_ft": 582.0,
      "elevation_ft": 582.0,
      "runup_ft": 0.0,
      "baseline_ari": 1.7312,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17725_base_4999",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                1.7312407488633237,
                null,
                null,
                null,
                null
              ],
              [
                10.073214800271067,
                1.532488990247557,
                null,
                null,
                null
              ],
              [
                39.588948853904206,
                8.938025172137348,
                1.3834355825570457,
                1.0434905682635494,
                null
              ],
              [
                1000.5000833333622,
                44.66883729937153,
                11.591333359612012,
                1.4889329178729296,
                1.0599218151400236
              ],
              [
                1000.5000833333622,
                838.4898722099401,
                44.20410831497598,
                8.938025172137348,
                1.3305303988619317
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_582d00_0d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_582d00_0d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                582.0,
                null,
                null,
                null,
                null
              ],
              [
                580.5235500000001,
                582.1640500000001,
                null,
                null,
                null
              ],
              [
                579.0523592307694,
                580.6928592307694,
                582.4645992307693,
                584.2363392307693,
                null
              ],
              [
                577.0837592307693,
                578.7570692307694,
                580.4356384615386,
                582.2729984615386,
                584.1050992307694
              ],
              [
                575.1204184615385,
                577.1218284615386,
                578.6967084615385,
                580.5996884615386,
                582.6339084615385
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_582d00_0d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_582d00_0d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.476449999999886,
                0.1640500000000884,
                null,
                null,
                null
              ],
              [
                -2.9476407692305884,
                -1.3071407692306138,
                0.464599230769295,
                2.236339230769317,
                null
              ],
              [
                -4.91624076923074,
                -3.242930769230611,
                -1.5643615384614122,
                0.2729984615385774,
                2.105099230769383
              ],
              [
                -6.87958153846148,
                -4.878171538461402,
                -3.303291538461508,
                -1.4003115384614375,
                0.6339084615384536
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_582d00_0d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_582d00_0d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1791150000003,
                585.950855,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1284900000002,
                584.0150650000002,
                585.8852350000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17725",
      "component_name": "run2",
      "save_point_id": 4999,
      "magnitude_ft": 580.0,
      "elevation_ft": 582.0,
      "runup_ft": 2.0,
      "baseline_ari": 1.0535,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17725_run2_4999",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                1.0535425842324728,
                null,
                null,
                null,
                null
              ],
              [
                1.3519879803671069,
                1.0453272471051946,
                null,
                null,
                null
              ],
              [
                6.225219435900785,
                1.2738257213782045,
                1.029522749854768,
                1.0022408221485035,
                null
              ],
              [
                38.22385067604155,
                8.266830047015304,
                1.4066874220651888,
                1.0484251404650913,
                1.0030724759625147
              ],
              [
                840.8773554184243,
                36.72929486541654,
                8.266830047015304,
                1.345411751037138,
                1.045115919980597
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_582d00_2d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_582d00_2d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                580.0000000000001,
                null,
                null,
                null,
                null
              ],
              [
                578.4188353333335,
                580.1132638333335,
                null,
                null,
                null
              ],
              [
                576.8376706666668,
                578.5649091666668,
                580.3726015000001,
                582.1443415000001,
                null
              ],
              [
                574.7463798333334,
                576.4736183333334,
                578.2516430000002,
                580.0741691666668,
                581.9115291666668
              ],
              [
                572.6371128333335,
                574.6385228333336,
                576.2134028333335,
                578.1163828333335,
                580.1506028333336
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_582d00_2d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_582d00_2d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.5811646666666093,
                0.1132638333333488,
                null,
                null,
                null
              ],
              [
                -3.162329333333332,
                -1.4350908333333336,
                0.3726014999999734,
                2.144341499999996,
                null
              ],
              [
                -5.253620166666678,
                -3.52638166666668,
                -1.7483569999999418,
                0.0741691666667065,
                1.9115291666666965
              ],
              [
                -7.36288716666661,
                -5.361477166666532,
                -3.7865971666666383,
                -1.883617166666568,
                0.150602833333437
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_582d00_2d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_582d00_2d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1791150000003,
                585.950855,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1284900000002,
                584.0150650000002,
                585.8852350000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17725",
      "component_name": "run25",
      "save_point_id": 4999,
      "magnitude_ft": 579.5,
      "elevation_ft": 582.0,
      "runup_ft": 2.5,
      "baseline_ari": 1.0216,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17725_run25_4999",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                1.0216428888237494,
                null,
                null,
                null,
                null
              ],
              [
                1.149392971074503,
                1.016796338958725,
                null,
                null,
                null
              ],
              [
                2.9390297817581468,
                1.133262721625904,
                1.0084248615122589,
                1.0012134564393638,
                null
              ],
              [
                29.260270859941897,
                4.852258068747572,
                1.1814128698785666,
                1.0201677513441765,
                1.001814514012106
              ],
              [
                272.6886633684599,
                27.938153338011308,
                4.896527032093121,
                1.1534669475443988,
                1.0219378424833805
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_582d00_2d50_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_582d00_2d50_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                579.4999999999999,
                null,
                null,
                null,
                null
              ],
              [
                577.8855019999999,
                579.6049304999999,
                null,
                null,
                null
              ],
              [
                576.271004,
                578.0232424999998,
                579.8476015,
                581.6193414999999,
                null
              ],
              [
                574.1380464999999,
                575.8902849999998,
                577.7016429999999,
                579.5325024999999,
                581.3698625
              ],
              [
                571.9787794999999,
                573.9801894999998,
                575.5550694999998,
                577.4580494999999,
                579.4922694999999
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_582d00_2d50_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_582d00_2d50_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.614498000000026,
                0.1049305000000231,
                null,
                null,
                null
              ],
              [
                -3.2289959999999382,
                -1.476757500000076,
                0.3476015000001098,
                2.119341500000018,
                null
              ],
              [
                -5.361953500000027,
                -3.609715000000051,
                -1.79835700000001,
                0.0325024999999641,
                1.8698625000000677
              ],
              [
                -7.521220500000027,
                -5.519810500000062,
                -3.944930500000055,
                -2.0419504999999845,
                -0.0077304999999796
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_582d00_2d50_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_582d00_2d50_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1791150000003,
                585.950855,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1284900000002,
                584.0150650000002,
                585.8852350000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_plot.png"
        }
      }
    },
    {
      "analysis_type": "twl",
      "resource_name": "longtail_17725",
      "component_name": "run3",
      "save_point_id": 4999,
      "magnitude_ft": 579.0,
      "elevation_ft": 582.0,
      "runup_ft": 3.0,
      "baseline_ari": 1.0062,
      "equivalent_elevation_basis": "baseline_magnitude",
      "qualified_name": "longtail_17725_run3_4999",
      "files": {
        "grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                1.006197503459065,
                null,
                null,
                null,
                null
              ],
              [
                1.101033616627462,
                1.0057316877029878,
                null,
                null,
                null
              ],
              [
                1.624764134695066,
                1.0875075472203748,
                1.0047700061887823,
                1.0005734466216036,
                null
              ],
              [
                20.15251903472671,
                2.238211029320133,
                1.1144095950898651,
                1.0062519316706875,
                1.0009652696650173
              ],
              [
                83.74239092228282,
                18.152999607386924,
                2.3232133599714206,
                1.1134822522884826,
                1.0072119427071973
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_582d00_3d00_grid.csv"
        },
        "plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_582d00_3d00_plot.png"
        },
        "equivalent_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                579.0,
                null,
                null,
                null,
                null
              ],
              [
                577.350239368421,
                579.0949572631579,
                null,
                null,
                null
              ],
              [
                575.6993211578947,
                577.4791642105262,
                579.3199969473684,
                581.0917369473683,
                null
              ],
              [
                573.5211277894737,
                575.303286,
                577.1510642105262,
                578.9884242105262,
                580.8246266315789
              ],
              [
                571.3101244210525,
                573.3115344210526,
                574.8864144210526,
                576.7893944210525,
                578.8236144210525
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_582d00_3d00_equivalent_elevation_grid.csv"
        },
        "equivalent_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_582d00_3d00_equivalent_elevation_plot.png"
        },
        "elevation_delta_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                0.0,
                null,
                null,
                null,
                null
              ],
              [
                -1.6497606315790565,
                0.0949572631578803,
                null,
                null,
                null
              ],
              [
                -3.300678842105299,
                -1.5208357894738356,
                0.319996947368395,
                2.091736947368304,
                null
              ],
              [
                -5.478872210526333,
                -3.6967140000000422,
                -1.848935789473785,
                -0.0115757894737953,
                1.8246266315788944
              ],
              [
                -7.689875578947522,
                -5.688465578947444,
                -4.113585578947436,
                -2.2106055789474794,
                -0.1763855789474746
              ]
            ]
          },
          "path": "batch_twl_output/baseline/4999_582d00_3d00_elevation_delta_grid.csv"
        },
        "elevation_delta_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/4999_582d00_3d00_elevation_delta_plot.png"
        },
        "threshold_ari_elevation_grid": {
          "type": "grid",
          "data": {
            "row_labels": [
              "0.0",
              "1.5",
              "3.0",
              "5.0",
              "7.0"
            ],
            "col_labels": [
              "0.0",
              "5.0",
              "10.0",
              "15.0",
              "20.0"
            ],
            "values": [
              [
                583.6541550000002,
                null,
                null,
                null,
                null
              ],
              [
                582.2105150000001,
                583.8346100000001,
                null,
                null,
                null
              ],
              [
                580.7668750000001,
                582.3909700000002,
                584.1791150000003,
                585.950855,
                null
              ],
              [
                578.8474900000002,
                580.4879900000002,
                582.1284900000002,
                584.0150650000002,
                585.8852350000002
              ],
              [
                576.9117000000001,
                578.9131100000002,
                580.4879900000002,
                582.3909700000002,
                584.4251900000002
              ]
            ]
          },
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_grid.csv"
        },
        "threshold_ari_elevation_plot": {
          "type": "image",
          "path": "batch_twl_output/baseline/savepoint4999_ari15_elevation_plot.png"
        }
      }
    }
  ]
};
